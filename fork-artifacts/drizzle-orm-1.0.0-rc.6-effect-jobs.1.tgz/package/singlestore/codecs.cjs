Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __singlestore_core_codecs_ts = require("../singlestore-core/codecs.cjs");
//#region src/singlestore/codecs.ts
const singleStoreCodecs = (0, __singlestore_core_codecs_ts.refineGenericSingleStoreCodecs)({
	serial: { normalize: Number },
	bigint: { normalize: BigInt },
	"bigint:number": { normalize: Number },
	"bigint:string": { normalize: String },
	boolean: { normalize: (value) => value === 1 },
	date: { normalize: (value) => new Date(value) },
	datetime: { normalize: (value) => /* @__PURE__ */ new Date(value.replace(" ", "T") + "Z") },
	timestamp: { normalize: (value) => /* @__PURE__ */ new Date(value + "+0000") },
	"decimal:number": { normalize: Number },
	"decimal:bigint": { normalize: BigInt },
	binary: { normalize: (value) => value.toString() },
	varbinary: { normalize: (value) => value.toString() },
	vector_i8: { normalize: (0, __singlestore_core_codecs_ts.vectorNormalizer)("I8") },
	vector_i16: { normalize: (0, __singlestore_core_codecs_ts.vectorNormalizer)("I16") },
	vector_i32: { normalize: (0, __singlestore_core_codecs_ts.vectorNormalizer)("I32") },
	vector_i64: { normalize: (0, __singlestore_core_codecs_ts.vectorNormalizer)("I64") },
	vector_f32: { normalize: (0, __singlestore_core_codecs_ts.vectorNormalizer)("F32") },
	vector_f64: { normalize: (0, __singlestore_core_codecs_ts.vectorNormalizer)("F64") }
});
//#endregion
exports.singleStoreCodecs = singleStoreCodecs;

//# sourceMappingURL=codecs.cjs.map