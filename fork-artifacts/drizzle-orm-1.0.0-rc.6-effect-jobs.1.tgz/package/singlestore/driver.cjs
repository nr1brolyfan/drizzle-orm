Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_singlestore_codecs = require("./codecs.cjs");
const require_singlestore_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __version_ts = require("../version.cjs");
let __singlestore_core_dialect_ts = require("../singlestore-core/dialect.cjs");
let __logger_ts = require("../logger.cjs");
let mysql2 = require("mysql2");
let __singlestore_core_db_ts = require("../singlestore-core/db.cjs");
//#region src/singlestore/driver.ts
var SingleStoreDriverDriver = class {
	client;
	dialect;
	options;
	static [__entity_ts.entityKind] = "SingleStoreDriverDriver";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(client, dialect, options = {}) {
		this.client = client;
		this.dialect = dialect;
		this.options = options;
	}
	createSession(relations) {
		return new require_singlestore_session.SingleStoreDriverSession(this.client, this.dialect, relations, {
			logger: this.options.logger,
			paramsInErrors: this.options.paramsInErrors
		});
	}
};
var SingleStoreDriverDatabase = class extends __singlestore_core_db_ts.SingleStoreDatabase {
	static [__entity_ts.entityKind] = "SingleStoreDriverDatabase";
};
function construct(client, config = {}) {
	const dialect = new __singlestore_core_dialect_ts.SingleStoreDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_singlestore_codecs.singleStoreCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const clientForInstance = isCallbackClient(client) ? client.promise() : client;
	const relations = config.relations ?? {};
	const db = new SingleStoreDriverDatabase(dialect, new SingleStoreDriverDriver(clientForInstance, dialect, {
		logger,
		paramsInErrors: config.paramsInErrors
	}).createSession(relations), relations);
	db.$client = client;
	return db;
}
function isCallbackClient(client) {
	return typeof client.promise === "function";
}
const CONNECTION_ATTRS = {
	_connector_name: "SingleStore Drizzle ORM Driver",
	_connector_version: __version_ts.npmVersion
};
/**
* Driver quirks:
* - `float` values are rounded to 6 significant digits by MySQL's text protocol
*/
function drizzle(...params) {
	if (typeof params[0] === "string") {
		const connectionString = params[0];
		return construct((0, mysql2.createPool)({
			uri: connectionString,
			connectAttributes: CONNECTION_ATTRS
		}), params[1]);
	}
	const { connection, client, ...drizzleConfig } = params[0];
	if (client) return construct(client, drizzleConfig);
	let opts = {};
	opts = typeof connection === "string" ? {
		uri: connection,
		connectAttributes: CONNECTION_ATTRS
	} : {
		...connection,
		connectAttributes: {
			...connection.connectAttributes,
			...CONNECTION_ATTRS
		}
	};
	return construct((0, mysql2.createPool)(opts), drizzleConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
Object.defineProperty(exports, "SingleStoreDatabase", {
	enumerable: true,
	get: function() {
		return __singlestore_core_db_ts.SingleStoreDatabase;
	}
});
exports.SingleStoreDriverDatabase = SingleStoreDriverDatabase;
exports.SingleStoreDriverDriver = SingleStoreDriverDriver;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map