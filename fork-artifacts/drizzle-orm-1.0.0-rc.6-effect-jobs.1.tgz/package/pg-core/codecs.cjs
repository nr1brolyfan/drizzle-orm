Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_array = require("./array.cjs");
const require_pg_core_columns_postgis_extension_utils = require("./columns/postgis_extension/utils.cjs");
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __temporal_text_ts = require("../temporal-text.cjs");
//#region src/pg-core/codecs.ts
const PG_ALIAS_TO_TYPE_MAP = {
	int2: "smallint",
	integer: "int",
	int4: "int",
	int8: "bigint",
	decimal: "numeric",
	real: "float4",
	double: "float8",
	"double precision": "float8",
	serial2: "smallserial",
	serial4: "serial",
	serial8: "bigserial",
	character: "char",
	"character varying": "varchar",
	"time with time zone": "timetz",
	"time without time zone": "time",
	"timestamp with time zone": "timestamptz",
	"timestamp without time zone": "timestamp",
	boolean: "bool",
	"bit varying": "varbit"
};
function resolvePgTypeAlias(type) {
	return PG_ALIAS_TO_TYPE_MAP[type] ?? type;
}
const unionsTypeTable = {
	smallint: {
		smallint: "smallint",
		int: "int",
		bigint: "bigint:number",
		"bigint:number": "bigint:number",
		"bigint:string": "bigint:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number",
		float4: "float4",
		float8: "float8",
		smallserial: "smallint",
		serial: "int",
		bigserial: "bigint:number",
		"bigserial:number": "bigint:number",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	int: {
		smallint: "int",
		int: "int",
		bigint: "bigint:number",
		"bigint:number": "bigint:number",
		"bigint:string": "bigint:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number",
		float4: "float4",
		float8: "float8",
		smallserial: "int",
		serial: "int",
		bigserial: "bigint:number",
		"bigserial:number": "bigint:number",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	bigint: {
		smallint: "bigint",
		int: "bigint",
		bigint: "bigint",
		"bigint:number": "bigint",
		"bigint:string": "bigint",
		numeric: "numeric:bigint",
		"numeric:number": "numeric:bigint",
		"numeric:bigint": "numeric:bigint",
		float4: "float4",
		float8: "float8",
		smallserial: "bigint",
		serial: "bigint",
		bigserial: "bigint",
		"bigserial:number": "bigint",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	"bigint:number": {
		smallint: "bigint:number",
		int: "bigint:number",
		bigint: "bigint:number",
		"bigint:number": "bigint:number",
		"bigint:string": "bigint:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number",
		float4: "float4",
		float8: "float8",
		smallserial: "bigint:number",
		serial: "bigint:number",
		bigserial: "bigint:number",
		"bigserial:number": "bigint:number",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	"bigint:string": {
		smallint: "bigint:string",
		int: "bigint:string",
		bigint: "bigint:string",
		"bigint:number": "bigint:string",
		"bigint:string": "bigint:string",
		numeric: "numeric",
		"numeric:number": "numeric",
		"numeric:bigint": "numeric",
		float4: "float4",
		float8: "float8",
		smallserial: "bigint:string",
		serial: "bigint:string",
		bigserial: "bigint:string",
		"bigserial:number": "bigint:string",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	numeric: {
		smallint: "numeric",
		int: "numeric",
		bigint: "numeric",
		"bigint:number": "numeric",
		"bigint:string": "numeric",
		numeric: "numeric",
		"numeric:number": "numeric",
		"numeric:bigint": "numeric",
		float4: "float4",
		float8: "float8",
		smallserial: "numeric",
		serial: "numeric",
		bigserial: "numeric",
		"bigserial:number": "numeric"
	},
	"numeric:number": {
		smallint: "numeric:number",
		int: "numeric:number",
		bigint: "numeric:number",
		"bigint:number": "numeric:number",
		"bigint:string": "numeric:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number",
		float4: "float4",
		float8: "float8",
		smallserial: "numeric:number",
		serial: "numeric:number",
		bigserial: "numeric:number",
		"bigserial:number": "numeric:number"
	},
	"numeric:bigint": {
		smallint: "numeric:bigint",
		int: "numeric:bigint",
		bigint: "numeric:bigint",
		"bigint:number": "numeric:bigint",
		"bigint:string": "numeric:bigint",
		numeric: "numeric:bigint",
		"numeric:number": "numeric:bigint",
		"numeric:bigint": "numeric:bigint",
		float4: "float4",
		float8: "float8",
		smallserial: "numeric:bigint",
		serial: "numeric:bigint",
		bigserial: "numeric:bigint",
		"bigserial:number": "numeric:bigint"
	},
	float4: {
		smallint: "float4",
		int: "float4",
		bigint: "float4",
		"bigint:number": "float4",
		"bigint:string": "float4",
		numeric: "float4",
		"numeric:number": "float4",
		"numeric:bigint": "float4",
		float4: "float4",
		float8: "float8",
		smallserial: "float4",
		serial: "float4",
		bigserial: "float4",
		"bigserial:number": "float4"
	},
	float8: {
		smallint: "float8",
		int: "float8",
		bigint: "float8",
		"bigint:number": "float8",
		"bigint:string": "float8",
		numeric: "float8",
		"numeric:number": "float8",
		"numeric:bigint": "float8",
		float4: "float8",
		float8: "float8",
		smallserial: "float8",
		serial: "float8",
		bigserial: "float8",
		"bigserial:number": "float8"
	},
	money: { money: "money" },
	smallserial: {
		smallint: "smallint",
		int: "int",
		bigint: "bigint:number",
		"bigint:number": "bigint:number",
		"bigint:string": "bigint:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number",
		float4: "float4",
		float8: "float8",
		smallserial: "smallint",
		serial: "int",
		bigserial: "bigint:number",
		"bigserial:number": "bigint:number",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	serial: {
		smallint: "int",
		int: "int",
		bigint: "bigint:number",
		"bigint:number": "bigint:number",
		"bigint:string": "bigint:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number",
		float4: "float4",
		float8: "float8",
		smallserial: "int",
		serial: "int",
		bigserial: "bigint:number",
		"bigserial:number": "bigint:number",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	bigserial: {
		smallint: "bigint",
		int: "bigint",
		bigint: "bigint",
		"bigint:number": "bigint",
		"bigint:string": "bigint",
		numeric: "numeric:bigint",
		"numeric:number": "numeric:bigint",
		"numeric:bigint": "numeric:bigint",
		float4: "float4",
		float8: "float8",
		smallserial: "bigint",
		serial: "bigint",
		bigserial: "bigint",
		"bigserial:number": "bigint",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	"bigserial:number": {
		smallint: "bigint:number",
		int: "bigint:number",
		bigint: "bigint:number",
		"bigint:number": "bigint:number",
		"bigint:string": "bigint:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number",
		float4: "float4",
		float8: "float8",
		smallserial: "bigint:number",
		serial: "bigint:number",
		bigserial: "bigint:number",
		"bigserial:number": "bigint:number",
		oid: "oid",
		regproc: "regproc",
		regprocedure: "regprocedure",
		regoper: "regoper",
		regoperator: "regoperator",
		regclass: "regclass",
		regtype: "regtype",
		regrole: "regrole",
		regnamespace: "regnamespace",
		regconfig: "regconfig",
		regdictionary: "regdictionary"
	},
	char: {
		char: "char",
		varchar: "char",
		text: "char"
	},
	varchar: {
		char: "varchar",
		varchar: "varchar",
		text: "varchar"
	},
	text: {
		char: "text",
		varchar: "text",
		text: "text"
	},
	bytea: { bytea: "bytea" },
	date: {
		date: "date",
		"date:string": "date",
		timestamp: "timestamp",
		"timestamp:string": "timestamp",
		timestamptz: "timestamptz",
		"timestamptz:string": "timestamptz"
	},
	"date:string": {
		date: "date:string",
		"date:string": "date:string",
		timestamp: "timestamp:string",
		"timestamp:string": "timestamp:string",
		timestamptz: "timestamptz:string",
		"timestamptz:string": "timestamptz:string"
	},
	time: {
		time: "time",
		timetz: "timetz"
	},
	timetz: {
		time: "timetz",
		timetz: "timetz"
	},
	timestamp: {
		date: "timestamp",
		"date:string": "timestamp",
		timestamp: "timestamp",
		"timestamp:string": "timestamp",
		timestamptz: "timestamptz",
		"timestamptz:string": "timestamptz"
	},
	"timestamp:string": {
		date: "timestamp:string",
		"date:string": "timestamp:string",
		timestamp: "timestamp:string",
		"timestamp:string": "timestamp:string",
		timestamptz: "timestamptz:string",
		"timestamptz:string": "timestamptz:string"
	},
	timestamptz: {
		date: "timestamptz",
		"date:string": "timestamptz",
		timestamp: "timestamptz",
		"timestamp:string": "timestamptz",
		timestamptz: "timestamptz",
		"timestamptz:string": "timestamptz"
	},
	"timestamptz:string": {
		date: "timestamptz:string",
		"date:string": "timestamptz:string",
		timestamp: "timestamptz:string",
		"timestamp:string": "timestamptz:string",
		timestamptz: "timestamptz:string",
		"timestamptz:string": "timestamptz:string"
	},
	interval: {
		interval: "interval",
		"interval:tuple": "interval"
	},
	"interval:tuple": {
		interval: "interval:tuple",
		"interval:tuple": "interval:tuple"
	},
	bool: { bool: "bool" },
	enum: { enum: "enum" },
	point: {
		point: "point",
		"point:tuple": "point"
	},
	"point:tuple": {
		point: "point:tuple",
		"point:tuple": "point:tuple"
	},
	line: {
		line: "line",
		"line:tuple": "line"
	},
	"line:tuple": {
		line: "line:tuple",
		"line:tuple": "line:tuple"
	},
	lseg: { lseg: "lseg" },
	box: { box: "box" },
	path: { path: "path" },
	polygon: { polygon: "polygon" },
	circle: { circle: "circle" },
	cidr: {
		cidr: "cidr",
		inet: "inet"
	},
	inet: {
		cidr: "inet",
		inet: "inet"
	},
	macaddr: {
		macaddr: "macaddr",
		macaddr8: "macaddr"
	},
	macaddr8: {
		macaddr: "macaddr8",
		macaddr8: "macaddr8"
	},
	bit: {
		bit: "bit",
		varbit: "bit"
	},
	varbit: {
		bit: "varbit",
		varbit: "varbit"
	},
	tsvector: { tsvector: "tsvector" },
	tsquery: { tsquery: "tsquery" },
	uuid: { uuid: "uuid" },
	xml: { xml: "xml" },
	json: { json: "json" },
	jsonb: { jsonb: "jsonb" },
	int4range: { int4range: "int4range" },
	int8range: { int8range: "int8range" },
	numrange: { numrange: "numrange" },
	tsrange: { tsrange: "tsrange" },
	tstzrange: { tstzrange: "tstzrange" },
	daterange: { daterange: "daterange" },
	int4multirange: { int4multirange: "int4multirange" },
	int8multirange: { int8multirange: "int8multirange" },
	nummultirange: { nummultirange: "nummultirange" },
	tsmultirange: { tsmultirange: "tsmultirange" },
	tstzmultirange: { tstzmultirange: "tstzmultirange" },
	datemultirange: { datemultirange: "datemultirange" },
	oid: {
		smallint: "oid",
		int: "oid",
		bigint: "oid",
		"bigint:number": "oid",
		"bigint:string": "oid",
		smallserial: "oid",
		serial: "oid",
		bigserial: "oid",
		"bigserial:number": "oid",
		oid: "oid",
		regproc: "oid",
		regprocedure: "oid",
		regoper: "oid",
		regoperator: "oid",
		regclass: "oid",
		regtype: "oid",
		regrole: "oid",
		regnamespace: "oid",
		regconfig: "oid",
		regdictionary: "oid"
	},
	regproc: {
		smallint: "regproc",
		int: "regproc",
		bigint: "regproc",
		"bigint:number": "regproc",
		"bigint:string": "regproc",
		smallserial: "regproc",
		serial: "regproc",
		bigserial: "regproc",
		"bigserial:number": "regproc",
		oid: "regproc",
		regproc: "regproc",
		regprocedure: "regproc"
	},
	regprocedure: {
		smallint: "regprocedure",
		int: "regprocedure",
		bigint: "regprocedure",
		"bigint:number": "regprocedure",
		"bigint:string": "regprocedure",
		smallserial: "regprocedure",
		serial: "regprocedure",
		bigserial: "regprocedure",
		"bigserial:number": "regprocedure",
		oid: "regprocedure",
		regproc: "regprocedure",
		regprocedure: "regprocedure"
	},
	regoper: {
		smallint: "regoper",
		int: "regoper",
		bigint: "regoper",
		"bigint:number": "regoper",
		"bigint:string": "regoper",
		smallserial: "regoper",
		serial: "regoper",
		bigserial: "regoper",
		"bigserial:number": "regoper",
		oid: "regoper",
		regoper: "regoper",
		regoperator: "regoper"
	},
	regoperator: {
		smallint: "regoperator",
		int: "regoperator",
		bigint: "regoperator",
		"bigint:number": "regoperator",
		"bigint:string": "regoperator",
		smallserial: "regoperator",
		serial: "regoperator",
		bigserial: "regoperator",
		"bigserial:number": "regoperator",
		oid: "regoperator",
		regoper: "regoperator",
		regoperator: "regoperator"
	},
	regclass: {
		smallint: "regclass",
		int: "regclass",
		bigint: "regclass",
		"bigint:number": "regclass",
		"bigint:string": "regclass",
		smallserial: "regclass",
		serial: "regclass",
		bigserial: "regclass",
		"bigserial:number": "regclass",
		oid: "regclass",
		regclass: "regclass"
	},
	regtype: {
		smallint: "regtype",
		int: "regtype",
		bigint: "regtype",
		"bigint:number": "regtype",
		"bigint:string": "regtype",
		smallserial: "regtype",
		serial: "regtype",
		bigserial: "regtype",
		"bigserial:number": "regtype",
		oid: "regtype",
		regtype: "regtype"
	},
	regrole: {
		smallint: "regrole",
		int: "regrole",
		bigint: "regrole",
		"bigint:number": "regrole",
		"bigint:string": "regrole",
		smallserial: "regrole",
		serial: "regrole",
		bigserial: "regrole",
		"bigserial:number": "regrole",
		oid: "regrole",
		regrole: "regrole"
	},
	regnamespace: {
		smallint: "regnamespace",
		int: "regnamespace",
		bigint: "regnamespace",
		"bigint:number": "regnamespace",
		"bigint:string": "regnamespace",
		smallserial: "regnamespace",
		serial: "regnamespace",
		bigserial: "regnamespace",
		"bigserial:number": "regnamespace",
		oid: "regnamespace",
		regnamespace: "regnamespace"
	},
	regconfig: {
		smallint: "regconfig",
		int: "regconfig",
		bigint: "regconfig",
		"bigint:number": "regconfig",
		"bigint:string": "regconfig",
		smallserial: "regconfig",
		serial: "regconfig",
		bigserial: "regconfig",
		"bigserial:number": "regconfig",
		oid: "regconfig",
		regconfig: "regconfig"
	},
	regdictionary: {
		smallint: "regdictionary",
		int: "regdictionary",
		bigint: "regdictionary",
		"bigint:number": "regdictionary",
		"bigint:string": "regdictionary",
		smallserial: "regdictionary",
		serial: "regdictionary",
		bigserial: "regdictionary",
		"bigserial:number": "regdictionary",
		oid: "regdictionary",
		regdictionary: "regdictionary"
	}
};
const castToText = (name) => __sql_sql_ts.sql`${name}::text`;
const castToTextArr = (name, arrayDimensions) => __sql_sql_ts.sql`${name}::text${__sql_sql_ts.sql.raw("[]".repeat(arrayDimensions))}`;
/** Used for cases when casting requires to unwrap and rebuild arrays
*
* @example
* string_mtx::text[][] // can be casted to array directly
*
* encode(bytea_mtx, 'base64')[][] // invalid syntax, cast requires unwrapping and rebuilding array
*/
const arrayCompatCast = (cast) => (name, arrayDimensions) => {
	if (!arrayDimensions) return cast(name);
	const aliases = [];
	for (let i = 0; i < arrayDimensions; i++) aliases.push(__sql_sql_ts.sql.identifier(`s${i}`));
	let indexed = name;
	for (const alias of aliases) indexed = __sql_sql_ts.sql`${indexed}[${alias}]`;
	let expression = __sql_sql_ts.sql`array(\
select ${cast(indexed)} \
from generate_subscripts(${name}, ${__sql_sql_ts.sql.raw(arrayDimensions.toString())}) ${aliases[arrayDimensions - 1]} \
order by ${aliases[arrayDimensions - 1]})`;
	for (let dim = arrayDimensions - 1; dim > 0; dim--) expression = __sql_sql_ts.sql`array(\
select ${expression} \
from generate_subscripts(${name}, ${__sql_sql_ts.sql.raw(dim.toString())}) ${aliases[dim - 1]} \
order by ${aliases[dim - 1]})`;
	return __sql_sql_ts.sql`case when ${name} is null then null else ${expression} end`;
};
const arrayCompatNormalize = (normalize) => {
	const loop = (value, arrayDimensions) => {
		if (value === null) return value;
		const innerDimensions = arrayDimensions - 1;
		if (arrayDimensions > 1) for (let i = 0; i < value.length; ++i) loop(value[i], innerDimensions);
		else for (let i = 0; i < value.length; ++i) value[i] = value[i] === null ? null : normalize(value[i]);
		return value;
	};
	return loop;
};
/** Doesn't mutate original data - used for insertions */
const arrayCompatNormalizeInput = (normalize, transformToPgArray = false) => {
	const loop = (value, arrayDimensions) => {
		const innerDimensions = arrayDimensions - 1;
		const out = new Array(value.length);
		if (arrayDimensions > 1) for (let i = 0; i < value.length; ++i) out[i] = loop(value[i], innerDimensions);
		else for (let i = 0; i < value.length; ++i) {
			const element = value[i];
			out[i] = element === null ? null : normalize(element);
		}
		return out;
	};
	return transformToPgArray ? (v, d) => require_pg_core_array.makePgArray(loop(v, d)) : loop;
};
const parsePgArrayAndNormalize = (normalize, delim) => {
	const codec = arrayCompatNormalize(normalize);
	return (value, arrayDimensions) => codec(require_pg_core_array.parsePgArray(value, delim), arrayDimensions);
};
const parseGeometryArrayAndNormalize = (normalize) => parsePgArrayAndNormalize(normalize, ":");
const makeGeometryArray = (value) => require_pg_core_array.makePgArray(value, ":");
const makeBoxArray = (value) => require_pg_core_array.makePgArray(value, ";");
const parseLineTuple = (v) => {
	const [a, b, c] = v.slice(1, -1).split(",");
	return [
		Number.parseFloat(a),
		Number.parseFloat(b),
		Number.parseFloat(c)
	];
};
const parseLineABC = (v) => {
	const [a, b, c] = v.slice(1, -1).split(",");
	return {
		a: Number.parseFloat(a),
		b: Number.parseFloat(b),
		c: Number.parseFloat(c)
	};
};
const parsePointTuple = (v) => {
	const [x, y] = v.slice(1, -1).split(",");
	return [Number.parseFloat(x), Number.parseFloat(y)];
};
const parsePointXY = (v) => {
	const [x, y] = v.slice(1, -1).split(",");
	return {
		x: Number.parseFloat(x),
		y: Number.parseFloat(y)
	};
};
const parseGeometryTuple = (v) => require_pg_core_columns_postgis_extension_utils.parseEWKB(v).point;
const parseGeometryXY = (v) => {
	const parsed = require_pg_core_columns_postgis_extension_utils.parseEWKB(v);
	return {
		x: parsed.point[0],
		y: parsed.point[1]
	};
};
/** `date`, `timestamptz` array literal (`{2026-10-03,...}`) to `Date[]` */
const textToDatePgArray = parsePgArrayAndNormalize(__temporal_text_ts.textToDate);
/** `timestamp` array literal to `Date[]`, values read as UTC */
const textToDateWithTzPgArray = parsePgArrayAndNormalize(__temporal_text_ts.textToDateWithTz);
/** Array literal to `string[]` */
const parsePgArrayOfStrings = (v) => require_pg_core_array.parsePgArray(v);
/**
* `YYYY-MM-DD` text of a `date` the driver decoded to UTC midnight. Drivers that can't decode BC dates return
* `Invalid Date`s for them (a driver quirk), whose text is `'Invalid Date'`
*/
const pgDateTextFromUtcDate = (value) => {
	const year = value.getUTCFullYear();
	if (Number.isNaN(year)) return String(value);
	const monthDay = `-${String(value.getUTCMonth() + 1).padStart(2, "0")}-${String(value.getUTCDate()).padStart(2, "0")}`;
	return year > 0 ? `${String(year).padStart(4, "0")}${monthDay}` : `${String(1 - year).padStart(4, "0")}${monthDay} BC`;
};
const pad2 = (value) => String(value).padStart(2, "0");
/**
* PostgreSQL's text of a `timestamp` the driver decoded to a `Date` at its UTC wall-clock time (`timestamptz` in UTC with
* `withTz`): fractional seconds are cut to the `Date`'s milliseconds, trailing zeros trimmed as PostgreSQL does.
* `Infinity` / `-Infinity` (`bun`) map to `infinity` / `-infinity`
*/
const pgTimestampTextFromUtcDate = (withTz) => (value) => {
	if (value === Infinity) return "infinity";
	if (value === -Infinity) return "-infinity";
	const date = value;
	const year = date.getUTCFullYear();
	const ms = date.getUTCMilliseconds();
	const text = `${String(year > 0 ? year : 1 - year).padStart(4, "0")}-${pad2(date.getUTCMonth() + 1)}-${pad2(date.getUTCDate())} ${pad2(date.getUTCHours())}:${pad2(date.getUTCMinutes())}:${pad2(date.getUTCSeconds())}${ms ? `.${String(ms).padStart(3, "0").replace(/0+$/, "")}` : ""}${withTz ? "+00" : ""}`;
	return year > 0 ? text : `${text} BC`;
};
/**
* Shortest decimal that rounds to the same `float4` - matches PostgreSQL's text output of `real` values that a driver
* decoded from the binary protocol as the exact single-precision value (`1.2345678` -> `1.2345677614212036`)
*/
const shortestFloat32 = (value) => {
	const exact = Math.fround(value);
	if (exact === 0 || !Number.isFinite(exact)) return exact;
	for (let precision = 1; precision <= 9; ++precision) {
		const candidate = +exact.toPrecision(precision);
		if (Math.fround(candidate) === exact) return candidate;
	}
	return exact;
};
/** `real[]` of any dimensions whose innermost level a driver may hand over as a `Float32Array` */
const shortestFloat32Array = (value, arrayDimensions) => {
	const loop = (level, depth) => {
		if (level instanceof Float32Array) return Array.from(level, (item) => shortestFloat32(item));
		if (depth > 1) {
			for (let i = 0; i < level.length; ++i) level[i] = loop(level[i], depth - 1);
			return level;
		}
		const out = level;
		for (let i = 0; i < out.length; ++i) out[i] = out[i] === null ? null : shortestFloat32(out[i]);
		return out;
	};
	return loop(value, arrayDimensions);
};
const pgRawTextOids = /* @__PURE__ */ new Set([
	1231,
	1082,
	1182,
	1114,
	1115,
	1184,
	1185,
	1186,
	1187
]);
const rawText = (value) => value;
/**
* `getTypeParser` for the clients that take `pg`-style type parsers: `pgRawTextOids` stay text for codecs to
* decode, every other type goes through `clientParser`, the client's own lookup
*/
const pgRawTextTypeParser = (clientParser) => (typeId, format) => pgRawTextOids.has(typeId) ? rawText : clientParser(typeId, format);
const castToEpochMs = (name) => __sql_sql_ts.sql`floor(extract(epoch from ${name}) * 1000)`;
const epochMsToDate = (v) => /* @__PURE__ */ new Date(+v);
const castToJsonText = (name) => __sql_sql_ts.sql`to_json(${name})::text`;
const parseJsonArrayAndNormalize = (normalize) => {
	const codec = arrayCompatNormalize(normalize);
	return (v, arrayDimensions) => codec(JSON.parse(v), arrayDimensions);
};
const textToDateArray = parseJsonArrayAndNormalize(__temporal_text_ts.textToDate);
const textToDateWithTzArray = parseJsonArrayAndNormalize(__temporal_text_ts.textToDateWithTz);
const parsePgVector = (v) => {
	const body = v.slice(1, -1);
	if (body.length === 0) return [];
	return body.split(",").map(Number.parseFloat);
};
const byteaFromPgHex = (v) => Buffer.from(v.slice(2), "hex");
const genericPgCodecs = {
	bytea: {
		normalizeInJson: byteaFromPgHex,
		normalizeArrayInJson: arrayCompatNormalize(byteaFromPgHex)
	},
	bigint: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: BigInt,
		normalizeArrayInJson: arrayCompatNormalize(BigInt)
	},
	"bigint:number": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	"bigint:string": {
		castInJson: castToText,
		castArrayInJson: castToTextArr
	},
	bigserial: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: BigInt,
		normalizeArrayInJson: arrayCompatNormalize(BigInt)
	},
	"bigserial:number": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	date: {
		normalizeInJson: __temporal_text_ts.textToDate,
		normalizeArrayInJson: arrayCompatNormalize(__temporal_text_ts.textToDate)
	},
	"date:string": {},
	"geometry(point)": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parseGeometryXY,
		normalizeArrayInJson: arrayCompatNormalize(parseGeometryXY)
	},
	"geometry(point):tuple": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parseGeometryTuple,
		normalizeArrayInJson: arrayCompatNormalize(parseGeometryTuple)
	},
	interval: { castArrayInJson: castToTextArr },
	line: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parseLineABC,
		normalizeArrayInJson: arrayCompatNormalize(parseLineABC)
	},
	"line:tuple": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parseLineTuple,
		normalizeArrayInJson: arrayCompatNormalize(parseLineTuple)
	},
	numeric: {
		castInJson: castToText,
		castArrayInJson: castToTextArr
	},
	"numeric:number": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	"numeric:bigint": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: BigInt,
		normalizeArrayInJson: arrayCompatNormalize(BigInt)
	},
	point: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parsePointXY,
		normalizeArrayInJson: arrayCompatNormalize(parsePointXY)
	},
	"point:tuple": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parsePointTuple,
		normalizeArrayInJson: arrayCompatNormalize(parsePointTuple)
	},
	timestamp: {
		normalizeInJson: __temporal_text_ts.textToDateWithTz,
		normalizeArrayInJson: arrayCompatNormalize(__temporal_text_ts.textToDateWithTz)
	},
	timestamptz: {
		normalizeInJson: __temporal_text_ts.textToDate,
		normalizeArrayInJson: arrayCompatNormalize(__temporal_text_ts.textToDate)
	},
	"timestamp:string": {
		castInJson: castToText,
		castArrayInJson: castToTextArr
	},
	"timestamptz:string": {
		castInJson: castToText,
		castArrayInJson: castToTextArr
	},
	halfvec: {
		normalizeInJson: parsePgVector,
		normalizeArrayInJson: arrayCompatNormalize(parsePgVector)
	},
	vector: {
		normalizeInJson: parsePgVector,
		normalizeArrayInJson: arrayCompatNormalize(parsePgVector)
	}
};
const refineGenericPgCodecs = (extension) => (0, __codecs_ts.refineCodecs)(genericPgCodecs, extension);
//#endregion
exports.arrayCompatCast = arrayCompatCast;
exports.arrayCompatNormalize = arrayCompatNormalize;
exports.arrayCompatNormalizeInput = arrayCompatNormalizeInput;
exports.byteaFromPgHex = byteaFromPgHex;
exports.castToEpochMs = castToEpochMs;
exports.castToJsonText = castToJsonText;
exports.castToText = castToText;
exports.castToTextArr = castToTextArr;
exports.epochMsToDate = epochMsToDate;
exports.genericPgCodecs = genericPgCodecs;
exports.makeBoxArray = makeBoxArray;
exports.makeGeometryArray = makeGeometryArray;
exports.parseGeometryArrayAndNormalize = parseGeometryArrayAndNormalize;
exports.parseGeometryTuple = parseGeometryTuple;
exports.parseGeometryXY = parseGeometryXY;
exports.parseJsonArrayAndNormalize = parseJsonArrayAndNormalize;
exports.parseLineABC = parseLineABC;
exports.parseLineTuple = parseLineTuple;
exports.parsePgArrayAndNormalize = parsePgArrayAndNormalize;
exports.parsePgArrayOfStrings = parsePgArrayOfStrings;
exports.parsePgVector = parsePgVector;
exports.parsePointTuple = parsePointTuple;
exports.parsePointXY = parsePointXY;
exports.pgDateTextFromUtcDate = pgDateTextFromUtcDate;
exports.pgRawTextOids = pgRawTextOids;
exports.pgRawTextTypeParser = pgRawTextTypeParser;
exports.pgTimestampTextFromUtcDate = pgTimestampTextFromUtcDate;
exports.refineGenericPgCodecs = refineGenericPgCodecs;
exports.resolvePgTypeAlias = resolvePgTypeAlias;
exports.shortestFloat32 = shortestFloat32;
exports.shortestFloat32Array = shortestFloat32Array;
exports.textToDate = __temporal_text_ts.textToDate;
exports.textToDateArray = textToDateArray;
exports.textToDatePgArray = textToDatePgArray;
exports.textToDateWithTz = __temporal_text_ts.textToDateWithTz;
exports.textToDateWithTzArray = textToDateWithTzArray;
exports.textToDateWithTzPgArray = textToDateWithTzPgArray;
exports.unionsTypeTable = unionsTypeTable;

//# sourceMappingURL=codecs.cjs.map