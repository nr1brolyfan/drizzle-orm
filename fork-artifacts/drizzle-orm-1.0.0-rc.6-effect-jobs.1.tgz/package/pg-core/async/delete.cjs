Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_query_builders_delete = require("../query-builders/delete.cjs");
const require_pg_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
//#region src/pg-core/async/delete.ts
var PgAsyncDeleteBase = class extends require_pg_core_query_builders_delete.PgDeleteBase {
	static [__entity_ts.entityKind] = "PgAsyncDelete";
};
(0, __utils_ts.applyMixins)(PgAsyncDeleteBase, [__query_promise_ts.QueryPromise, require_pg_core_query_builders_runnable.PgRunnableQuery]);
//#endregion
exports.PgAsyncDeleteBase = PgAsyncDeleteBase;

//# sourceMappingURL=delete.cjs.map