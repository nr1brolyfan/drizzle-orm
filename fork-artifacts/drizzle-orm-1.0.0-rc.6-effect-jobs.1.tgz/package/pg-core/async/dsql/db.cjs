Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_async_db = require("../db.cjs");
let __entity_ts = require("../../../entity.cjs");
//#region src/pg-core/async/dsql/db.ts
var DsqlAsyncDatabase = class extends require_pg_core_async_db.BasePgAsyncDatabase {
	static [__entity_ts.entityKind] = "DsqlAsyncDatabase";
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.DsqlAsyncDatabase = DsqlAsyncDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map