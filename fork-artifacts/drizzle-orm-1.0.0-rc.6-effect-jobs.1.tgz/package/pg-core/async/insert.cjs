Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_query_builders_insert = require("../query-builders/insert.cjs");
const require_pg_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
//#region src/pg-core/async/insert.ts
var PgAsyncInsertBase = class extends require_pg_core_query_builders_insert.PgInsertBase {
	static [__entity_ts.entityKind] = "PgAsyncInsert";
};
(0, __utils_ts.applyMixins)(PgAsyncInsertBase, [__query_promise_ts.QueryPromise, require_pg_core_query_builders_runnable.PgRunnableQuery]);
//#endregion
exports.PgAsyncInsertBase = PgAsyncInsertBase;

//# sourceMappingURL=insert.cjs.map