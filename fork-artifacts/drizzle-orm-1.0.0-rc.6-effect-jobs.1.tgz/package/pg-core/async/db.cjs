Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_async_count = require("./count.cjs");
const require_pg_core_db = require("../db.cjs");
const require_pg_core_async_delete = require("./delete.cjs");
const require_pg_core_async_insert = require("./insert.cjs");
const require_pg_core_async_query = require("./query.cjs");
const require_pg_core_async_raw = require("./raw.cjs");
const require_pg_core_async_refresh_materialized_view = require("./refresh-materialized-view.cjs");
const require_pg_core_async_select = require("./select.cjs");
const require_pg_core_async_update = require("./update.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/pg-core/async/db.ts
const pgAsyncBuilders = {
	select: require_pg_core_async_select.PgAsyncSelectBase,
	insert: require_pg_core_async_insert.PgAsyncInsertBase,
	update: require_pg_core_async_update.PgAsyncUpdateBase,
	delete: require_pg_core_async_delete.PgAsyncDeleteBase,
	count: require_pg_core_async_count.PgAsyncCountBuilder,
	raw: require_pg_core_async_raw.PgAsyncRaw,
	refreshMaterializedView: require_pg_core_async_refresh_materialized_view.PgAsyncRefreshMaterializedView,
	relationalQuery: require_pg_core_async_query.PgAsyncRelationalQuery
};
/** Transactionless definition -  branches out into `PostgreSQL` & `DSQL` variants */
var BasePgAsyncDatabase = class extends require_pg_core_db.PgDatabase {
	static [__entity_ts.entityKind] = "BasePgAsyncDatabase";
	constructor(dialect, session, relations, parseRqbJson = false, tagged = false) {
		super(pgAsyncBuilders, dialect, session, relations, parseRqbJson, tagged);
	}
};
var PgAsyncDatabase = class extends BasePgAsyncDatabase {
	static [__entity_ts.entityKind] = "PgAsyncDatabase";
	constructor(dialect, session, relations, parseRqbJson = false, tagged = false) {
		super(dialect, session, relations, parseRqbJson, tagged);
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.BasePgAsyncDatabase = BasePgAsyncDatabase;
exports.PgAsyncDatabase = PgAsyncDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map