Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_codecs = require("./codecs.cjs");
let __view_ts = require("../view.cjs");
let __entity_ts = require("../entity.cjs");
let __view_common_ts = require("../view-common.cjs");
let __errors_ts = require("../errors.cjs");
let __table_ts = require("../table.cjs");
let __utils_ts = require("../utils.cjs");
let __column_ts = require("../column.cjs");
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __alias_ts = require("../alias.cjs");
let __relations_ts = require("../relations.cjs");
let __sql_common_chunks_ts = require("../sql/common-chunks.cjs");
let __pg_core_table_ts = require("./table.cjs");
let __pg_core_columns_index_ts = require("./columns/index.cjs");
//#region src/pg-core/dialect.ts
const escapePgName = (0, __utils_ts.memoizeEscape)((name) => `"${name.replace(/"/g, "\"\"")}"`);
const rqbChunks = {
	relationField: new __sql_common_chunks_ts.StringChunk(".\"r\" as "),
	joinOne: new __sql_common_chunks_ts.StringChunk(" left join lateral(select row_to_json(\"t\".*) \"r\" from ("),
	joinMany: new __sql_common_chunks_ts.StringChunk(` left join lateral(select coalesce(json_agg(row_to_json("t".*)), '[]') as "r" from (`),
	joinClose: new __sql_common_chunks_ts.StringChunk(") as \"t\") as "),
	onTrue: new __sql_common_chunks_ts.StringChunk(" on true")
};
var PgDialect = class {
	static [__entity_ts.entityKind] = "PgDialect";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	codecs;
	mapperGenerators;
	shapeGenerator;
	constructor(config) {
		this.codecs = new __codecs_ts.CodecsCollection(require_pg_core_codecs.resolvePgTypeAlias, config?.codecs);
		this.shapeGenerator = config?.shapeGenerator;
		this.mapperGenerators = config?.useJitMappers ? {
			rows: __utils_ts.makeJitQueryMapper,
			relationalRows: __relations_ts.makeJitRqbMapper
		} : {
			rows: __utils_ts.makeDefaultQueryMapper,
			relationalRows: __relations_ts.makeDefaultRqbMapper
		};
	}
	escapeName(name) {
		return escapePgName(name);
	}
	escapeParam(num) {
		return `$${num + 1}`;
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const queriesLen = queries.length;
		const withSqlChunks = new Array(queriesLen + 1);
		let writeIdx = 0;
		withSqlChunks[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["with "];
		for (let i = 0; i < queriesLen; ++i) {
			const w = queries[i];
			withSqlChunks[writeIdx++] = i < queriesLen - 1 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql}), ` : __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql}) `;
		}
		return new __sql_sql_ts.SQL(withSqlChunks);
	}
	buildDeleteQuery({ table, where, returning, withList, comment }) {
		const withSql = this.buildWithCTE(withList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: true,
			table
		})}` : void 0;
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		return __sql_sql_ts.sql`${withSql}delete from ${table}${whereSql}${returningSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[__table_ts.Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setLength = columnNames.length;
		const setArr = new Array(setLength);
		for (let i = 0; i < columnNames.length; ++i) {
			const colName = columnNames[i];
			const col = tableColumns[colName];
			let value;
			if (set[colName] !== void 0) value = set[colName];
			else {
				const updateRes = col.onUpdateFn?.();
				value = (0, __entity_ts.is)(updateRes, __sql_sql_ts.SQL) ? updateRes : __sql_sql_ts.sql.param(updateRes, col);
			}
			setArr[i] = i < setLength - 1 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}, ` : __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}`;
		}
		return new __sql_sql_ts.SQL(setArr);
	}
	buildUpdateQuery({ table, set, where, returning, withList, from, joins, comment }) {
		const withSql = this.buildWithCTE(withList);
		const tableName = table[__pg_core_table_ts.PgTable.Symbol.Name];
		const tableSchema = table[__pg_core_table_ts.PgTable.Symbol.Schema];
		const origTableName = table[__pg_core_table_ts.PgTable.Symbol.OriginalName];
		const alias = tableName === origTableName ? void 0 : tableName;
		const tableSql = __sql_sql_ts.sql`${tableSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(tableSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origTableName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}`;
		const setSql = this.buildUpdateSet(table, set);
		const fromSql = from && new __sql_sql_ts.SQL([__sql_common_chunks_ts.commonStringChunks[" from "], this.buildFromTable(from)]);
		const joinsSql = this.buildJoins(joins);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: !from,
			table
		})}` : void 0;
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		return __sql_sql_ts.sql`${withSql}update ${tableSql} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false, table } = {}) {
		const { length: columnsLen } = fields;
		const chunks = [];
		const tableKind = (0, __sql_sql_ts.chunkKindOf)(table);
		const tableName = table ? (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.sql) || (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.subquery) ? void 0 : table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}` : void 0;
		for (let i = 0; i < columnsLen; ++i) {
			const { field, fieldType } = fields[i];
			switch (fieldType) {
				case "Column": {
					let name;
					if (isSingleTable) name = field.isAlias ? __sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name) : __sql_sql_ts.sql.identifier(field.name);
					else name = field.isAlias ? (0, __alias_ts.getOriginalColumnFromAlias)(field) : field;
					chunks.push(field.isAlias ? __sql_sql_ts.sql`${name} as ${field}` : name);
					break;
				}
				case "SQL.Aliased":
					if (field.isSelectionField) {
						const query = !isSingleTable && field.origin !== void 0 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(field.origin)}.${__sql_sql_ts.sql.identifier(field.fieldAlias)}` : __sql_sql_ts.sql.identifier(field.fieldAlias);
						chunks.push(query);
					} else {
						if (isSingleTable && tableName !== void 0) {
							const { queryChunks } = field.sql;
							const newChunks = new Array(queryChunks.length);
							let abort = false;
							for (let i = 0; i < queryChunks.length; ++i) {
								const c = queryChunks[i];
								if ((0, __entity_ts.is)(c, __column_ts.Column)) {
									const { table } = c;
									if ((table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}`) !== tableName) {
										abort = true;
										break;
									}
									newChunks[i] = __sql_sql_ts.sql.identifier(c.name);
								} else newChunks[i] = c;
							}
							if (abort) chunks.push(field.sql);
							else {
								const newSql = new __sql_sql_ts.SQL(newChunks);
								if (field.sql.shouldInlineParams) newSql.inlineParams();
								chunks.push(newSql);
							}
						} else chunks.push(field.sql);
						chunks.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
					}
					break;
				case "SQL":
					if (isSingleTable && tableName !== void 0) {
						const { queryChunks } = field;
						const newChunks = new Array(queryChunks.length);
						let abort = false;
						for (let i = 0; i < queryChunks.length; ++i) {
							const c = queryChunks[i];
							if ((0, __entity_ts.is)(c, __column_ts.Column)) {
								const { table } = c;
								if ((table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}`) !== tableName) {
									abort = true;
									break;
								}
								newChunks[i] = __sql_sql_ts.sql.identifier(c.name);
							} else newChunks[i] = c;
						}
						if (abort) chunks.push(field);
						else {
							const newSql = new __sql_sql_ts.SQL(newChunks);
							if (field.shouldInlineParams) newSql.inlineParams();
							chunks.push(newSql);
						}
					} else chunks.push(field);
					break;
				case "Subquery": if (!field._.isWith) {
					const inner = __sql_sql_ts.sql`(${field._.sql})`;
					chunks.push(__sql_sql_ts.sql`${inner} ${__sql_sql_ts.sql.identifier(field._.alias)}`);
				} else chunks.push(field);
			}
			if (i < columnsLen - 1) chunks.push(__sql_common_chunks_ts.commonStringChunks[", "]);
		}
		return new __sql_sql_ts.SQL(chunks);
	}
	buildJoins(joins) {
		if (!joins || joins.length === 0) return;
		const joinsArray = [];
		for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(__sql_common_chunks_ts.commonStringChunks[" "]);
			const table = joinMeta.table;
			const lateralSql = joinMeta.lateral ? __sql_sql_ts.sql` lateral` : void 0;
			const onSql = joinMeta.on ? __sql_sql_ts.sql` on ${joinMeta.on}` : void 0;
			if ((0, __entity_ts.is)(table, __pg_core_table_ts.PgTable)) joinsArray.push(__sql_sql_ts.sql`${new __sql_common_chunks_ts.StringChunk(joinMeta.joinType)} join${lateralSql} ${table[__table_ts.Table.Symbol.IsAlias] ? (0, __alias_ts.aliasedTableSQL)(table) : table}${onSql}`);
			else if ((0, __entity_ts.is)(table, __view_ts.View)) {
				const viewName = table[__view_common_ts.ViewBaseConfig].name;
				const viewSchema = table[__view_common_ts.ViewBaseConfig].schema;
				const origViewName = table[__view_common_ts.ViewBaseConfig].originalName;
				const alias = viewName === origViewName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${new __sql_common_chunks_ts.StringChunk(joinMeta.joinType)} join${lateralSql} ${viewSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(viewSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origViewName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}${onSql}`);
			} else joinsArray.push(__sql_sql_ts.sql`${new __sql_common_chunks_ts.StringChunk(joinMeta.joinType)} join${lateralSql} ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(__sql_common_chunks_ts.commonStringChunks[" "]);
		}
		return new __sql_sql_ts.SQL(joinsArray);
	}
	buildFromTable(table) {
		if ((0, __entity_ts.is)(table, __table_ts.Table) && table[__table_ts.Table.Symbol.IsAlias]) return (0, __alias_ts.aliasedTableSQL)(table);
		if ((0, __entity_ts.is)(table, __view_ts.View) && table[__view_common_ts.ViewBaseConfig].isAlias) {
			let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].originalName)}`;
			if (table[__view_common_ts.ViewBaseConfig].schema) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].schema)}.${fullName}`;
			return __sql_sql_ts.sql`${fullName} ${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].name)}`;
		}
		return table;
	}
	buildSelectQuery({ withList, fieldsFlat, where, having, table, joins, orderBy, groupBy, limit, offset, lockingClause, distinct, setOperators, comment }) {
		if (!fieldsFlat) throw new Error("Select query builder must be provided with `fieldsFlat` on `buildSelectQuery` invocation");
		const fieldsList = fieldsFlat;
		const tableKind = (0, __sql_sql_ts.chunkKindOf)(table);
		const ownTableName = (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.subquery) ? table._.alias : (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.view) ? table[__view_common_ts.ViewBaseConfig].name : (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.sql) ? void 0 : (0, __table_ts.getTableName)(table);
		for (const f of fieldsList) if ((0, __entity_ts.is)(f.field, __column_ts.Column) && (0, __table_ts.getTableName)(f.field.table) !== ownTableName && !((table) => joins?.some(({ alias }) => alias === (table[__table_ts.Table.Symbol.IsAlias] ? (0, __table_ts.getTableName)(table) : table[__table_ts.Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = (0, __table_ts.getTableName)(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		let distinctSql;
		if (distinct) distinctSql = distinct === true ? __sql_sql_ts.sql` distinct` : __sql_sql_ts.sql` distinct on (${__sql_sql_ts.sql.join(distinct.on, __sql_common_chunks_ts.commonStringChunks[", "])})`;
		const selection = this.buildSelection(fieldsList, {
			isSingleTable,
			table
		});
		const tableSql = this.buildFromTable(table);
		const joinsSql = this.buildJoins(joins);
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const havingSql = having ? __sql_sql_ts.sql` having ${having}` : void 0;
		let orderBySql;
		if (orderBy && orderBy.length > 0) orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderBy, __sql_common_chunks_ts.commonStringChunks[", "])}`;
		let groupBySql;
		if (groupBy && groupBy.length > 0) groupBySql = __sql_sql_ts.sql` group by ${__sql_sql_ts.sql.join(groupBy, __sql_common_chunks_ts.commonStringChunks[", "])}`;
		const limitSql = limit === void 0 ? void 0 : __sql_sql_ts.sql` limit ${limit}`;
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset}`;
		const lockingClauseSql = __sql_sql_ts.sql.empty();
		if (lockingClause) {
			const clauseSql = __sql_sql_ts.sql` for ${new __sql_common_chunks_ts.StringChunk(lockingClause.strength)}`;
			if (lockingClause.config.of) clauseSql.append(__sql_sql_ts.sql` of ${__sql_sql_ts.sql.join(Array.isArray(lockingClause.config.of) ? lockingClause.config.of.map((it) => __sql_sql_ts.sql.identifier(it[__pg_core_table_ts.PgTable.Symbol.Name])) : [__sql_sql_ts.sql.identifier(lockingClause.config.of[__pg_core_table_ts.PgTable.Symbol.Name])], __sql_common_chunks_ts.commonStringChunks[", "])}`);
			if (lockingClause.config.noWait) clauseSql.append(__sql_sql_ts.sql` nowait`);
			else if (lockingClause.config.skipLocked) clauseSql.append(__sql_sql_ts.sql` skip locked`);
			lockingClauseSql.append(clauseSql);
		}
		const finalQuery = __sql_sql_ts.sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}${lockingClauseSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		for (let i = 0; i < setOperators.length; ++i) leftSelect = this.buildSetOperationQuery({
			leftSelect,
			setOperator: setOperators[i]
		});
		return leftSelect;
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, limit, orderBy, offset } }) {
		const leftChunk = __sql_sql_ts.sql`(${leftSelect.getSQL()}) `;
		const rightChunk = __sql_sql_ts.sql`(${rightSelect.getSQL()})`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const singleOrderBy of orderBy) if ((0, __entity_ts.is)(singleOrderBy, __pg_core_columns_index_ts.PgColumn)) orderByValues.push(__sql_sql_ts.sql.identifier(singleOrderBy.name));
			else if ((0, __entity_ts.is)(singleOrderBy, __sql_sql_ts.SQL)) orderByValues.push(__sql_sql_ts.sql`${(0, __sql_sql_ts.unqualifyColumns)(singleOrderBy)}`);
			else orderByValues.push(__sql_sql_ts.sql`${singleOrderBy}`);
			orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByValues, __sql_common_chunks_ts.commonStringChunks[", "])}`;
		}
		const limitSql = limit === void 0 ? void 0 : __sql_sql_ts.sql` limit ${limit}`;
		const operatorChunk = new __sql_common_chunks_ts.StringChunk(`${type} ${isAll ? "all " : ""}`);
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset}`;
		return __sql_sql_ts.sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select, overridingSystemValue_, comment, columnList }) {
		const columns = table[__table_ts.Table.Symbol.Columns];
		const colEntries = columnList ? columnList.map((name) => [name, columns[name]]) : Object.entries(columns);
		const colFilteredEntries = select && !(0, __entity_ts.is)(valuesOrSelect, __sql_sql_ts.SQL) ? Object.keys(valuesOrSelect.getSelectedFields()).map((key) => [key, columns[key]]) : overridingSystemValue_ ? colEntries : colEntries.filter(([_, col]) => !col.shouldDisableInsert());
		const width = colFilteredEntries.length;
		const insertColumns = new Array(width);
		const insertKeys = new Array(width);
		const insertOrderArr = new Array(width * 2 + 1);
		let writeIdx = 0;
		insertOrderArr[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["("];
		for (let i = 0; i < width; ++i) {
			const [key, column] = colFilteredEntries[i];
			insertKeys[i] = key;
			insertColumns[i] = column;
			insertOrderArr[writeIdx++] = __sql_sql_ts.sql.identifier(column.name);
			if (i < width - 1) insertOrderArr[writeIdx++] = __sql_common_chunks_ts.commonStringChunks[", "];
		}
		insertOrderArr[writeIdx++] = __sql_common_chunks_ts.commonStringChunks[")"];
		const insertOrder = new __sql_sql_ts.SQL(insertOrderArr);
		let valuesSqlList;
		if (select) valuesSqlList = [valuesOrSelect.getSQL()];
		else {
			const values = valuesOrSelect;
			const cells = new Array(values.length * width);
			let writeIdx = 0;
			for (let valueIndex = 0; valueIndex < values.length; ++valueIndex) {
				const value = values[valueIndex];
				for (let i = 0; i < width; ++i) {
					const colValue = value[insertKeys[i]];
					if (colValue !== void 0) {
						cells[writeIdx++] = colValue;
						continue;
					}
					const col = insertColumns[i];
					if (col.defaultFn !== void 0) cells[writeIdx++] = col.defaultFn();
					else if (!col.default && col.onUpdateFn !== void 0) cells[writeIdx++] = col.onUpdateFn();
					else cells[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["default"];
				}
			}
			valuesSqlList = [__sql_common_chunks_ts.commonStringChunks["values "], new __sql_sql_ts.ValueRows(cells, insertColumns)];
		}
		const withSql = this.buildWithCTE(withList);
		const valuesSql = new __sql_sql_ts.SQL(valuesSqlList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: true,
			table
		})}` : void 0;
		const onConflictSql = onConflict ? __sql_sql_ts.sql` on conflict ${onConflict}` : void 0;
		const overridingSql = overridingSystemValue_ === true ? __sql_sql_ts.sql`overriding system value ` : void 0;
		return __sql_sql_ts.sql`${withSql}insert into ${table} ${insertOrder} ${overridingSql}${valuesSql}${onConflictSql}${returningSql}${comment !== void 0 ? __sql_sql_ts.sql` ${comment}` : void 0}`;
	}
	buildRefreshMaterializedViewQuery({ view, concurrently, withNoData }) {
		const concurrentlySql = concurrently ? __sql_sql_ts.sql` concurrently` : void 0;
		const withNoDataSql = withNoData ? __sql_sql_ts.sql` with no data` : void 0;
		return __sql_sql_ts.sql`refresh materialized view${concurrentlySql} ${view}${withNoDataSql}`;
	}
	sqlToQuery(sql, invokeSource) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			codecs: this.codecs,
			invokeSource
		});
	}
	_sqlToQuery(sql) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			codecs: this.codecs,
			tagged: true
		});
	}
	buildRelationalQuery(config) {
		const chunks = [];
		const selection = this.collectRelationalQuery(config, chunks);
		return {
			sql: new __sql_sql_ts.SQL(chunks),
			selection
		};
	}
	collectRelationalQuery({ schema, table, tableConfig, queryConfig: config, relationWhere, mode, errorPath, depth, through, nested, withSubqueries, strategy }, collectTo) {
		const selection = [];
		const isSingle = mode === "first";
		const params = config === true ? void 0 : config;
		const currentPath = errorPath ?? "";
		const currentDepth = depth ?? 0;
		const isOptimized = (currentDepth ? strategy : params?.strategy) !== "basic";
		const collector = withSubqueries ?? { subqueries: /* @__PURE__ */ new Map() };
		if (!currentDepth) {
			(0, __relations_ts.collectSubquery)(collector, table);
			table = (0, __alias_ts.aliasedTable)(table, `d${currentDepth}`);
		}
		const tableRef = table[__table_ts.Qualifier];
		const limit = isSingle ? 1 : params?.limit;
		const offset = params?.offset;
		const { sql: where, hasRelationFilters } = (0, __relations_ts.relationalQueryWhereToSQL)(table, params, tableConfig.relations, schema, collector, relationWhere);
		const order = params?.orderBy ? (0, __relations_ts.relationsOrderToSQL)(table, params.orderBy, tableConfig.relations, schema, collector) : void 0;
		const withParam = params ? params.with : void 0;
		const withKeys = [];
		if (withParam) {
			for (const key of Object.keys(withParam)) if (withParam[key]) withKeys.push(key);
		}
		const withIdx = currentDepth ? -1 : collectTo.length;
		if (!currentDepth) collectTo.push(void 0);
		collectTo.push(__sql_common_chunks_ts.commonStringChunks["select "]);
		let selected = (0, __relations_ts.buildRqbColumns)(tableRef, tableConfig.table[__table_ts.TableColumns], selection, !!nested, tableConfig.name, this.codecs, collectTo, params?.columns) ? 1 : 0;
		if (params?.extras) {
			const mark = collectTo.length;
			if (selected) collectTo.push(__sql_common_chunks_ts.commonStringChunks[", "]);
			const extras = (0, __relations_ts.relationExtrasToSQL)(table, params.extras, this.codecs, nested, collectTo);
			selection.push(...extras.selection);
			if (extras.sql) ++selected;
			else collectTo.length = mark;
		}
		for (const k of withKeys) {
			if (!tableConfig.relations[k]) throw new __errors_ts.DrizzleError({ message: `Unknown relation "${tableConfig.name}" -> "${k}"` });
			const key = __sql_sql_ts.sql.identifier(k);
			if (selected++) collectTo.push(__sql_common_chunks_ts.commonStringChunks[", "]);
			collectTo.push(key, rqbChunks.relationField, key);
		}
		if (!selected) throw new __errors_ts.DrizzleError({ message: `No fields selected for table "${tableConfig.name}"${currentPath ? ` ("${currentPath}")` : ""}` });
		const isPaginatedFirst = offset !== void 0 || limit !== void 0 && !!order;
		const isWrapped = withKeys.length > 0 && isOptimized && (isPaginatedFirst || hasRelationFilters);
		collectTo.push(__sql_common_chunks_ts.commonStringChunks[" from "]);
		if (isWrapped) collectTo.push(__sql_common_chunks_ts.commonStringChunks["(select "], tableRef, __sql_common_chunks_ts.commonStringChunks[".* from "]);
		(0, __relations_ts.getTableAsAliasSQL)(table, collectTo);
		if (through) {
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[" inner join "]);
			(0, __relations_ts.getTableAsAliasSQL)(through.table, collectTo);
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[" on "], ...through.condition);
		}
		if (isWrapped) {
			if (where) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" where "], ...where);
			if (isPaginatedFirst) {
				if (order) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" order by "], ...order);
				if (limit !== void 0) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" limit "], limit);
				if (offset !== void 0) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" offset "], offset);
			}
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[") as "], tableRef);
		}
		for (const k of withKeys) {
			const join = withParam[k];
			const relation = tableConfig.relations[k];
			const isSingle = relation.relationType === "one";
			(0, __relations_ts.collectSubquery)(collector, relation.targetTable);
			(0, __relations_ts.collectSubquery)(collector, relation.throughTable);
			const targetTable = (0, __alias_ts.aliasedTable)(relation.targetTable, `d${currentDepth + 1}`);
			const throughTable = relation.throughTable ? (0, __alias_ts.aliasedTable)(relation.throughTable, `tr${currentDepth}`) : void 0;
			const { filter, joinCondition } = (0, __relations_ts.relationToSQL)(relation, table, targetTable, throughTable);
			collectTo.push(isSingle ? rqbChunks.joinOne : rqbChunks.joinMany);
			const innerSelection = this.collectRelationalQuery({
				table: targetTable,
				mode: isSingle ? "first" : "many",
				schema,
				queryConfig: join,
				tableConfig: schema[relation.targetTableName],
				relationWhere: filter,
				errorPath: `${currentPath.length ? `${currentPath}.` : ""}${k}`,
				depth: currentDepth + 1,
				withSubqueries: collector,
				strategy: currentDepth ? strategy : params?.strategy,
				through: throughTable ? {
					table: throughTable,
					condition: joinCondition
				} : void 0,
				nested: true
			}, collectTo);
			collectTo.push(rqbChunks.joinClose, __sql_sql_ts.sql.identifier(k), rqbChunks.onTrue);
			selection.push({
				field: targetTable,
				fieldType: "Nested",
				key: k,
				selection: innerSelection,
				isArray: !isSingle,
				isOptional: (relation.optional ?? false) || join !== true && !!join.where
			});
		}
		if (where && !isWrapped) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" where "], ...where);
		if (order) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" order by "], ...order);
		if (!isWrapped || !isPaginatedFirst) {
			if (limit !== void 0) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" limit "], limit);
			if (offset !== void 0) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" offset "], offset);
		}
		if (config !== true && config?.comment) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" "], __sql_sql_ts.sql.comment(config.comment));
		if (withIdx !== -1) collectTo[withIdx] = this.buildWithCTE([...collector.subqueries.values()]);
		return selection;
	}
};
//#endregion
exports.PgDialect = PgDialect;

//# sourceMappingURL=dialect.cjs.map