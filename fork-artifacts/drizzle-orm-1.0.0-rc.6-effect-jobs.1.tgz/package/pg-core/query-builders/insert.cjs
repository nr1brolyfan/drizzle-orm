Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_query_builders_query_builder = require("./query-builder.cjs");
const require_pg_core_query_builders_prepare = require("./prepare.cjs");
let __entity_ts = require("../../entity.cjs");
let __table_ts = require("../../table.cjs");
let __utils_ts = require("../../utils.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
let __selection_proxy_ts = require("../../selection-proxy.cjs");
//#region src/pg-core/query-builders/insert.ts
var PgInsertBuilder = class {
	table;
	session;
	dialect;
	withList;
	overridingSystemValue_;
	columnList;
	builder;
	static [__entity_ts.entityKind] = "PgInsertBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(table, session, dialect, withList, overridingSystemValue_, columnList, builder = PgInsertBase) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
		this.overridingSystemValue_ = overridingSystemValue_;
		this.columnList = columnList;
		this.builder = builder;
	}
	overridingSystemValue() {
		this.overridingSystemValue_ = true;
		return this;
	}
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		return new this.builder(this.table, values, this.session, this.dialect, this.withList, false, this.columnList, this.overridingSystemValue_);
	}
	select(selectQuery) {
		const select = typeof selectQuery === "function" ? selectQuery(new require_pg_core_query_builders_query_builder.QueryBuilder()) : selectQuery;
		if (!(0, __entity_ts.is)(select, __sql_sql_ts.SQL)) {
			const insertCols = Object.keys(this.table[__table_ts.Table.Symbol.Columns]);
			const selected = Object.keys(select._.selectedFields);
			for (const col of selected) if (!insertCols.includes(col)) throw new Error(`Insert select error: column "${col}" does not exist in table "${this.table[__table_ts.Table.Symbol.Name]}"`);
		}
		return new this.builder(this.table, select, this.session, this.dialect, this.withList, true, this.columnList, this.overridingSystemValue_);
	}
};
var PgInsertBase = class {
	session;
	dialect;
	static [__entity_ts.entityKind] = "PgInsert";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	config;
	constructor(table, values, session, dialect, withList, select, columnList, overridingSystemValue_) {
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			withList,
			select,
			columnList,
			overridingSystemValue_
		};
	}
	returning(fields = this.config.table[__table_ts.Table.Symbol.Columns]) {
		this.config.returningFields = fields;
		this.config.returning = (0, __utils_ts.orderSelectedFields)(this.config.returningFields, void 0, this.dialect.codecs);
		this.config.shape = void 0;
		return this;
	}
	/**
	* Adds an `on conflict do nothing` clause to the query.
	*
	* Calling this method simply avoids inserting a row as it's alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
	*
	* @param config The `target` and `where` clauses.
	*
	* @example
	* ```ts
	* // Insert one row and cancel the insert if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing();
	*
	* // Explicitly specify conflict target
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing({ target: cars.id });
	* ```
	*/
	onConflictDoNothing(config = {}) {
		if (config.target === void 0) this.config.onConflict = __sql_sql_ts.sql`do nothing`;
		else {
			let targetColumn = "";
			targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(it.name)).join(",") : this.dialect.escapeName(config.target.name);
			const whereSql = config.where ? __sql_sql_ts.sql` where ${config.where}` : void 0;
			this.config.onConflict = __sql_sql_ts.sql`(${__sql_sql_ts.sql.raw(targetColumn)})${whereSql} do nothing`;
		}
		return this;
	}
	/**
	* Adds an `on conflict do update` clause to the query.
	*
	* Calling this method will update the existing row that conflicts with the row proposed for insertion as it's alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
	*
	* @param config The `target`, `set` and `where` clauses.
	*
	* @example
	* ```ts
	* // Update the row if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'Porsche' }
	*   });
	*
	* // Upsert with 'where' clause
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'newBMW' },
	*     targetWhere: sql`${cars.createdAt} > '2023-01-01'::date`,
	*   });
	* ```
	*/
	onConflictDoUpdate(config) {
		if (config.where && (config.targetWhere || config.setWhere)) throw new Error("You cannot use both \"where\" and \"targetWhere\"/\"setWhere\" at the same time - \"where\" is deprecated, use \"targetWhere\" or \"setWhere\" instead.");
		const whereSql = config.where ? __sql_sql_ts.sql` where ${config.where}` : void 0;
		const targetWhereSql = config.targetWhere ? __sql_sql_ts.sql` where ${config.targetWhere}` : void 0;
		const setWhereSql = config.setWhere ? __sql_sql_ts.sql` where ${config.setWhere}` : void 0;
		const setSql = this.dialect.buildUpdateSet(this.config.table, (0, __utils_ts.mapUpdateSet)(this.config.table, config.set));
		let targetColumn = "";
		targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(it.name)).join(",") : this.dialect.escapeName(config.target.name);
		this.config.onConflict = __sql_sql_ts.sql`(${__sql_sql_ts.sql.raw(targetColumn)})${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`;
		return this;
	}
	/**
	* Attach [sqlcommenter](https://google.github.io/sqlcommenter) comment to a query
	*/
	comment(comment) {
		this.config.comment = __sql_sql_ts.sql.comment(comment);
		return this;
	}
	getSQL() {
		return this.dialect.buildInsertQuery(this.config);
	}
	toSQL() {
		return this.dialect.sqlToQuery(this.getSQL());
	}
	/** @internal */
	getSelectedFields() {
		return this.config.returningFields ? new Proxy(this.config.returningFields, new __selection_proxy_ts.SelectionProxyHandler({
			alias: (0, __table_ts.getTableName)(this.config.table),
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		})) : void 0;
	}
	$dynamic() {
		return this;
	}
	/**
	* Prepares the query on the session, for both runtimes. The runtime's builder narrows the return type.
	*
	* @internal
	*/
	_prepare(name, generateName = false) {
		const { session, dialect, config } = this;
		return require_pg_core_query_builders_prepare.prepareMutation(session, dialect, config, () => this.getSQL(), void 0, name ?? generateName);
	}
};
//#endregion
exports.PgInsertBase = PgInsertBase;
exports.PgInsertBuilder = PgInsertBuilder;

//# sourceMappingURL=insert.cjs.map