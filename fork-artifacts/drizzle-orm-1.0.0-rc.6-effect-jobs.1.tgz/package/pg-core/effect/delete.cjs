Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_query_builders_delete = require("../query-builders/delete.cjs");
const require_pg_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
//#region src/pg-core/effect/delete.ts
var PgEffectDeleteBase = class extends require_pg_core_query_builders_delete.PgDeleteBase {
	static [__entity_ts.entityKind] = "PgEffectDelete";
};
(0, __utils_ts.applyMixins)(PgEffectDeleteBase, [require_pg_core_query_builders_runnable.PgRunnableQuery]);
(0, __effect_core_query_effect_ts.applyEffectWrapper)(PgEffectDeleteBase);
//#endregion
exports.PgEffectDeleteBase = PgEffectDeleteBase;

//# sourceMappingURL=delete.cjs.map