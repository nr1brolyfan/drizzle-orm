Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_db = require("../db.cjs");
const require_pg_core_effect_raw = require("./raw.cjs");
const require_pg_core_effect_delete = require("./delete.cjs");
const require_pg_core_effect_query = require("./query.cjs");
const require_pg_core_effect_refresh_materialized_view = require("./refresh-materialized-view.cjs");
const require_pg_core_effect_count = require("./count.cjs");
const require_pg_core_effect_insert = require("./insert.cjs");
const require_pg_core_effect_select = require("./select.cjs");
const require_pg_core_effect_update = require("./update.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/pg-core/effect/db.ts
const pgEffectBuilders = {
	select: require_pg_core_effect_select.PgEffectSelectBase,
	insert: require_pg_core_effect_insert.PgEffectInsertBase,
	update: require_pg_core_effect_update.PgEffectUpdateBase,
	delete: require_pg_core_effect_delete.PgEffectDeleteBase,
	count: require_pg_core_effect_count.PgEffectCountBuilder,
	raw: require_pg_core_effect_raw.PgEffectRaw,
	refreshMaterializedView: require_pg_core_effect_refresh_materialized_view.PgEffectRefreshMaterializedView,
	relationalQuery: require_pg_core_effect_query.PgEffectRelationalQuery
};
var PgEffectDatabase = class extends require_pg_core_db.PgDatabase {
	static [__entity_ts.entityKind] = "EffectPgDatabase";
	constructor(dialect, session, relations, parseRqbJson = false) {
		super(pgEffectBuilders, dialect, session, relations, parseRqbJson);
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.PgEffectDatabase = PgEffectDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map