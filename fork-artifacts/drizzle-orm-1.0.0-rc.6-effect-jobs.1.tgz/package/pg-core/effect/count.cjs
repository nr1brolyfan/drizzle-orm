Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_query_builders_count = require("../query-builders/count.cjs");
let __entity_ts = require("../../entity.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
//#region src/pg-core/effect/count.ts
var PgEffectCountBuilder = class extends require_pg_core_query_builders_count.PgCountBuilder {
	static [__entity_ts.entityKind] = "PgEffectCountBuilder";
};
(0, __effect_core_query_effect_ts.applyEffectWrapper)(PgEffectCountBuilder);
//#endregion
exports.PgEffectCountBuilder = PgEffectCountBuilder;

//# sourceMappingURL=count.cjs.map