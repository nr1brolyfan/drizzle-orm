Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_core_query_builders_insert = require("../query-builders/insert.cjs");
const require_pg_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
//#region src/pg-core/effect/insert.ts
var PgEffectInsertBase = class extends require_pg_core_query_builders_insert.PgInsertBase {
	static [__entity_ts.entityKind] = "PgEffectInsert";
};
(0, __utils_ts.applyMixins)(PgEffectInsertBase, [require_pg_core_query_builders_runnable.PgRunnableQuery]);
(0, __effect_core_query_effect_ts.applyEffectWrapper)(PgEffectInsertBase);
//#endregion
exports.PgEffectInsertBase = PgEffectInsertBase;

//# sourceMappingURL=insert.cjs.map