Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/pg-core/array.ts
const DEFAULT_DELIM = ",";
function parsePgArrayValue(arrayString, startFrom, inQuotes, delim) {
	for (let i = startFrom; i < arrayString.length; i++) {
		const char = arrayString[i];
		if (char === "\\") {
			i++;
			continue;
		}
		if (char === "\"") return [arrayString.slice(startFrom, i).replace(/\\(.)/g, "$1"), i + 1];
		if (inQuotes) continue;
		if (char === delim || char === "}") return [arrayString.slice(startFrom, i).replace(/\\(.)/g, "$1"), i];
	}
	return [arrayString.slice(startFrom).replace(/\\(.)/g, "$1"), arrayString.length];
}
function parsePgNestedArray(arrayString, startFrom = 0, delim = DEFAULT_DELIM) {
	const result = [];
	let i = startFrom;
	let lastCharIsDelim = false;
	while (i < arrayString.length) {
		const char = arrayString[i];
		if (char === delim) {
			if (lastCharIsDelim || i === startFrom) result.push("");
			lastCharIsDelim = true;
			i++;
			continue;
		}
		lastCharIsDelim = false;
		if (char === "\\") {
			i += 2;
			continue;
		}
		if (char === "\"") {
			const [value, startFrom] = parsePgArrayValue(arrayString, i + 1, true, delim);
			result.push(value);
			i = startFrom;
			continue;
		}
		if (char === "}") return [result, i + 1];
		if (char === "{") {
			const [value, startFrom] = parsePgNestedArray(arrayString, i + 1, delim);
			result.push(value);
			i = startFrom;
			continue;
		}
		const [value, newStartFrom] = parsePgArrayValue(arrayString, i, false, delim);
		result.push(value === "NULL" ? null : value);
		i = newStartFrom;
	}
	return [result, i];
}
function parsePgArray(arrayString, delim = DEFAULT_DELIM) {
	const [result] = parsePgNestedArray(arrayString, 1, delim);
	return result;
}
function buildPgArray(array, delim) {
	return `{${array.map((item) => {
		if (Array.isArray(item)) return buildPgArray(item, delim);
		if (typeof item === "string") return `"${item.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"`;
		return `${item}`;
	}).join(delim)}}`;
}
function makePgArray(array, delim = DEFAULT_DELIM) {
	return buildPgArray(array, delim);
}
//#endregion
exports.makePgArray = makePgArray;
exports.parsePgArray = parsePgArray;
exports.parsePgNestedArray = parsePgNestedArray;

//# sourceMappingURL=array.cjs.map