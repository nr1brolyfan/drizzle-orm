Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../entity.cjs");
let __table_utils_ts = require("../table.utils.cjs");
//#region src/pg-core/foreign-keys.ts
var ForeignKeyBuilder = class {
	static [__entity_ts.entityKind] = "PgForeignKeyBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	/** @internal */
	reference;
	/** @internal */
	_onUpdate = "no action";
	/** @internal */
	_onDelete = "no action";
	constructor(config, actions) {
		this.reference = () => {
			const { name, columns, foreignColumns } = config();
			return {
				name,
				columns,
				foreignTable: foreignColumns[0].table,
				foreignColumns
			};
		};
		if (actions) {
			this._onUpdate = actions.onUpdate;
			this._onDelete = actions.onDelete;
		}
	}
	onUpdate(action) {
		this._onUpdate = action === void 0 ? "no action" : action;
		return this;
	}
	onDelete(action) {
		this._onDelete = action === void 0 ? "no action" : action;
		return this;
	}
	/** @internal */
	build(table) {
		return new ForeignKey(table, this);
	}
};
var ForeignKey = class {
	table;
	static [__entity_ts.entityKind] = "PgForeignKey";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	reference;
	onUpdate;
	onDelete;
	name;
	constructor(table, builder) {
		this.table = table;
		this.reference = builder.reference;
		this.onUpdate = builder._onUpdate;
		this.onDelete = builder._onDelete;
	}
	getName() {
		const { name, columns, foreignColumns } = this.reference();
		const columnNames = columns.map((column) => column.name);
		const foreignColumnNames = foreignColumns.map((column) => column.name);
		const chunks = [
			this.table[__table_utils_ts.TableName],
			...columnNames,
			foreignColumns[0].table[__table_utils_ts.TableName],
			...foreignColumnNames
		];
		return name ?? `${chunks.join("_")}_fk`;
	}
	isNameExplicit() {
		return !!this.reference().name;
	}
};
function foreignKey(config) {
	function mappedConfig() {
		const { name, columns, foreignColumns } = config;
		return {
			name,
			columns,
			foreignColumns
		};
	}
	return new ForeignKeyBuilder(mappedConfig);
}
//#endregion
exports.ForeignKey = ForeignKey;
exports.ForeignKeyBuilder = ForeignKeyBuilder;
exports.foreignKey = foreignKey;

//# sourceMappingURL=foreign-keys.cjs.map