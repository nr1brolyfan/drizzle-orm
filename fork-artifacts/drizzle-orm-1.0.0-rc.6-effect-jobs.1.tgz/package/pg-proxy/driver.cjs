Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_pg_proxy_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __pg_core_dialect_ts = require("../pg-core/dialect.cjs");
let __logger_ts = require("../logger.cjs");
let __pg_core_async_db_ts = require("../pg-core/async/db.cjs");
//#region src/pg-proxy/driver.ts
var PgRemoteDatabase = class extends __pg_core_async_db_ts.PgAsyncDatabase {
	static [__entity_ts.entityKind] = "PgRemoteDatabase";
};
function drizzle(callback, config = {}, _dialect = (cfg) => new __pg_core_dialect_ts.PgDialect(cfg)) {
	const dialect = _dialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	return new PgRemoteDatabase(dialect, new require_pg_proxy_session.PgRemoteSession(callback, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
}
//#endregion
exports.PgRemoteDatabase = PgRemoteDatabase;
exports.drizzle = drizzle;

//# sourceMappingURL=driver.cjs.map