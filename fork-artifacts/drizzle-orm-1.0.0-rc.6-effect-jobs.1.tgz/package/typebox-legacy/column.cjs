Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_utils = require("../utils.cjs");
let __table_ts = require("../table.cjs");
let __column_ts = require("../column.cjs");
let __column_builder_ts = require("../column-builder.cjs");
let _sinclair_typebox = require("@sinclair/typebox");
//#region src/typebox-legacy/column.ts
const literalSchema = _sinclair_typebox.Type.Union([
	_sinclair_typebox.Type.String(),
	_sinclair_typebox.Type.Number(),
	_sinclair_typebox.Type.Boolean(),
	_sinclair_typebox.Type.Null()
]);
const jsonSchema = _sinclair_typebox.Type.Union([
	literalSchema,
	_sinclair_typebox.Type.Array(_sinclair_typebox.Type.Any()),
	_sinclair_typebox.Type.Record(_sinclair_typebox.Type.String(), _sinclair_typebox.Type.Any())
]);
_sinclair_typebox.TypeRegistry.Set("Buffer", (_, value) => value instanceof Buffer);
const bufferSchema = {
	[_sinclair_typebox.Kind]: "Buffer",
	type: "buffer"
};
function mapEnumValues(values) {
	return Object.fromEntries(values.map((value) => [value, value]));
}
function columnToSchema(column, t) {
	let schema;
	const dimensions = column.dimensions;
	if (typeof dimensions === "number" && dimensions > 0) return pgArrayColumnToSchema(column, dimensions, t);
	const { type, constraint } = (0, __column_builder_ts.extractExtendedColumnType)(column);
	switch (type) {
		case "array":
			schema = arrayColumnToSchema(column, constraint, t);
			break;
		case "object":
			schema = objectColumnToSchema(column, constraint, t);
			break;
		case "number":
			schema = numberColumnToSchema(column, constraint, t);
			break;
		case "bigint":
			schema = bigintColumnToSchema(column, constraint, t);
			break;
		case "boolean":
			schema = t.Boolean();
			break;
		case "string":
			schema = stringColumnToSchema(column, constraint, t);
			break;
		case "custom":
			schema = t.Any();
			break;
		default: schema = t.Any();
	}
	return schema;
}
function numberColumnToSchema(column, constraint, t) {
	let min;
	let max;
	let integer = false;
	switch (constraint) {
		case "int8":
			min = require_utils.CONSTANTS.INT8_MIN;
			max = require_utils.CONSTANTS.INT8_MAX;
			integer = true;
			break;
		case "uint8":
			min = 0;
			max = require_utils.CONSTANTS.INT8_UNSIGNED_MAX;
			integer = true;
			break;
		case "int16":
			min = require_utils.CONSTANTS.INT16_MIN;
			max = require_utils.CONSTANTS.INT16_MAX;
			integer = true;
			break;
		case "uint16":
			min = 0;
			max = require_utils.CONSTANTS.INT16_UNSIGNED_MAX;
			integer = true;
			break;
		case "int24":
			min = require_utils.CONSTANTS.INT24_MIN;
			max = require_utils.CONSTANTS.INT24_MAX;
			integer = true;
			break;
		case "uint24":
			min = 0;
			max = require_utils.CONSTANTS.INT24_UNSIGNED_MAX;
			integer = true;
			break;
		case "int32":
			min = require_utils.CONSTANTS.INT32_MIN;
			max = require_utils.CONSTANTS.INT32_MAX;
			integer = true;
			break;
		case "uint32":
			min = 0;
			max = require_utils.CONSTANTS.INT32_UNSIGNED_MAX;
			integer = true;
			break;
		case "int53":
			min = Number.MIN_SAFE_INTEGER;
			max = Number.MAX_SAFE_INTEGER;
			integer = true;
			break;
		case "uint53":
			min = 0;
			max = Number.MAX_SAFE_INTEGER;
			integer = true;
			break;
		case "float":
			min = require_utils.CONSTANTS.INT24_MIN;
			max = require_utils.CONSTANTS.INT24_MAX;
			break;
		case "ufloat":
			min = 0;
			max = require_utils.CONSTANTS.INT24_UNSIGNED_MAX;
			break;
		case "double":
			min = require_utils.CONSTANTS.INT48_MIN;
			max = require_utils.CONSTANTS.INT48_MAX;
			break;
		case "udouble":
			min = 0;
			max = require_utils.CONSTANTS.INT48_UNSIGNED_MAX;
			break;
		case "year":
			min = 1901;
			max = 2155;
			integer = true;
			break;
		case "unsigned":
			min = 0;
			max = Number.MAX_SAFE_INTEGER;
			break;
		default:
			min = Number.MIN_SAFE_INTEGER;
			max = Number.MAX_SAFE_INTEGER;
	}
	return t[integer ? "Integer" : "Number"]({
		minimum: min,
		maximum: max
	});
}
_sinclair_typebox.TypeRegistry.Set("BigIntStringMode", (_, value) => {
	if (typeof value !== "string" || !/^-?\d+$/.test(value)) return false;
	const bigint = BigInt(value);
	if (bigint < require_utils.CONSTANTS.INT64_MIN || bigint > require_utils.CONSTANTS.INT64_MAX) return false;
	return true;
});
_sinclair_typebox.TypeRegistry.Set("UnsignedBigIntStringMode", (_, value) => {
	if (typeof value !== "string" || !/^\d+$/.test(value)) return false;
	const bigint = BigInt(value);
	if (bigint < 0 || bigint > require_utils.CONSTANTS.INT64_MAX) return false;
	return true;
});
const bigintStringModeSchema = {
	[_sinclair_typebox.Kind]: "BigIntStringMode",
	type: "string"
};
const unsignedBigintStringModeSchema = {
	[_sinclair_typebox.Kind]: "UnsignedBigIntStringMode",
	type: "string"
};
function pgArrayColumnToSchema(column, dimensions, t) {
	const [baseType, baseConstraint] = column.dataType.split(" ");
	let baseSchema;
	switch (baseType) {
		case "number":
			baseSchema = numberColumnToSchema(column, baseConstraint, t);
			break;
		case "bigint":
			baseSchema = bigintColumnToSchema(column, baseConstraint, t);
			break;
		case "boolean":
			baseSchema = t.Boolean();
			break;
		case "string":
			baseSchema = stringColumnToSchema(column, baseConstraint, t);
			break;
		case "object":
			baseSchema = objectColumnToSchema(column, baseConstraint, t);
			break;
		case "array":
			baseSchema = arrayColumnToSchema(column, baseConstraint, t);
			break;
		default: baseSchema = t.Any();
	}
	let schema = t.Array(baseSchema);
	for (let i = 1; i < dimensions; i++) schema = t.Array(schema);
	return schema;
}
function arrayColumnToSchema(column, constraint, t) {
	switch (constraint) {
		case "geometry":
		case "point": return t.Tuple([t.Number(), t.Number()]);
		case "line": return t.Tuple([
			t.Number(),
			t.Number(),
			t.Number()
		]);
		case "vector":
		case "halfvector": {
			const length = column.length;
			const sizeParam = length ? {
				minItems: length,
				maxItems: length
			} : void 0;
			return t.Array(t.Number(), sizeParam);
		}
		case "int64vector": {
			const length = column.length;
			const sizeParam = length ? {
				minItems: length,
				maxItems: length
			} : void 0;
			return t.Array(t.BigInt({
				minimum: require_utils.CONSTANTS.INT64_MIN,
				maximum: require_utils.CONSTANTS.INT64_MAX
			}), sizeParam);
		}
		default: return t.Array(t.Any());
	}
}
function objectColumnToSchema(column, constraint, t) {
	switch (constraint) {
		case "buffer": return bufferSchema;
		case "date": return t.Date();
		case "geometry":
		case "point": return t.Object({
			x: t.Number(),
			y: t.Number()
		});
		case "json": return jsonSchema;
		case "line": return t.Object({
			a: t.Number(),
			b: t.Number(),
			c: t.Number()
		});
		default: return t.Object({});
	}
}
function bigintColumnToSchema(column, constraint, t) {
	let min;
	let max;
	switch (constraint) {
		case "int64":
			min = require_utils.CONSTANTS.INT64_MIN;
			max = require_utils.CONSTANTS.INT64_MAX;
			break;
		case "uint64":
			min = 0n;
			max = require_utils.CONSTANTS.INT64_UNSIGNED_MAX;
	}
	const options = {};
	if (min !== void 0) options.minimum = min;
	if (max !== void 0) options.maximum = max;
	return t.BigInt(Object.keys(options).length > 0 ? options : void 0);
}
function stringColumnToSchema(column, constraint, t) {
	const { name: columnName, length, isLengthExact } = column;
	let regex;
	if (constraint === "binary") regex = /^[01]*$/;
	if (constraint === "uuid") return t.String({ format: "uuid" });
	if (constraint === "enum") {
		const enumValues = column.enumValues;
		if (!enumValues) throw new Error(`Column "${(0, __table_ts.getTableName)((0, __column_ts.getColumnTable)(column))}"."${columnName}" is of 'enum' type, but lacks enum values`);
		return t.Enum(mapEnumValues(enumValues));
	}
	if (constraint === "int64") return bigintStringModeSchema;
	if (constraint === "uint64") return unsignedBigintStringModeSchema;
	const options = {};
	if (length !== void 0 && isLengthExact) {
		options.minLength = length;
		options.maxLength = length;
	} else if (length !== void 0) options.maxLength = length;
	return regex ? t.RegExp(regex, Object.keys(options).length > 0 ? options : void 0) : t.String(Object.keys(options).length > 0 ? options : void 0);
}
//#endregion
exports.bigintStringModeSchema = bigintStringModeSchema;
exports.bufferSchema = bufferSchema;
exports.columnToSchema = columnToSchema;
exports.jsonSchema = jsonSchema;
exports.literalSchema = literalSchema;
exports.mapEnumValues = mapEnumValues;
exports.unsignedBigintStringModeSchema = unsignedBigintStringModeSchema;

//# sourceMappingURL=column.cjs.map