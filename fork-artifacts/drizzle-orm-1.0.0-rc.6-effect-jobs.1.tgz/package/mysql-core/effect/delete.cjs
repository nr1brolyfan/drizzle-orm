Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
let __mysql_core_query_builders_delete_ts = require("../query-builders/delete.cjs");
//#region src/mysql-core/effect/delete.ts
var MySqlEffectDeleteBase = class extends __mysql_core_query_builders_delete_ts.MySqlDeleteBase {
	static [__entity_ts.entityKind] = "MySqlEffectDelete";
};
(0, __utils_ts.applyMixins)(MySqlEffectDeleteBase, [require_mysql_core_query_builders_runnable.MySqlRunnableQuery]);
(0, __effect_core_query_effect_ts.applyEffectWrapper)(MySqlEffectDeleteBase);
//#endregion
exports.MySqlEffectDeleteBase = MySqlEffectDeleteBase;

//# sourceMappingURL=delete.cjs.map