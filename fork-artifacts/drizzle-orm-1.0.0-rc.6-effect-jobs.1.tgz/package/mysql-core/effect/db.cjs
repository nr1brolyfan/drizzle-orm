Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_db = require("../db.cjs");
const require_mysql_core_effect_raw = require("./raw.cjs");
const require_mysql_core_effect_delete = require("./delete.cjs");
const require_mysql_core_effect_query = require("./query.cjs");
const require_mysql_core_effect_count = require("./count.cjs");
const require_mysql_core_effect_insert = require("./insert.cjs");
const require_mysql_core_effect_select = require("./select.cjs");
const require_mysql_core_effect_update = require("./update.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/mysql-core/effect/db.ts
const mysqlEffectBuilders = {
	select: require_mysql_core_effect_select.MySqlEffectSelectBase,
	insert: require_mysql_core_effect_insert.MySqlEffectInsertBase,
	update: require_mysql_core_effect_update.MySqlEffectUpdateBase,
	delete: require_mysql_core_effect_delete.MySqlEffectDeleteBase,
	count: require_mysql_core_effect_count.MySqlEffectCountBuilder,
	raw: require_mysql_core_effect_raw.MySqlEffectRaw,
	relationalQuery: require_mysql_core_effect_query.MySqlEffectRelationalQuery
};
var MySqlEffectDatabase = class extends require_mysql_core_db.MySqlDatabase {
	static [__entity_ts.entityKind] = "MySqlEffectDatabase";
	constructor(dialect, session, relations) {
		super(mysqlEffectBuilders, dialect, session, relations);
	}
	transaction(transaction) {
		return this.session.transaction(transaction);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.MySqlEffectDatabase = MySqlEffectDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map