Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
let __mysql_core_query_builders_insert_ts = require("../query-builders/insert.cjs");
//#region src/mysql-core/effect/insert.ts
var MySqlEffectInsertBase = class extends __mysql_core_query_builders_insert_ts.MySqlInsertBase {
	static [__entity_ts.entityKind] = "MySqlEffectInsert";
};
(0, __utils_ts.applyMixins)(MySqlEffectInsertBase, [require_mysql_core_query_builders_runnable.MySqlRunnableQuery]);
(0, __effect_core_query_effect_ts.applyEffectWrapper)(MySqlEffectInsertBase);
//#endregion
exports.MySqlEffectInsertBase = MySqlEffectInsertBase;

//# sourceMappingURL=insert.cjs.map