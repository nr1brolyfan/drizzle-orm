Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_query_builders_count = require("../query-builders/count.cjs");
let __entity_ts = require("../../entity.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
//#region src/mysql-core/effect/count.ts
var MySqlEffectCountBuilder = class extends require_mysql_core_query_builders_count.MySqlCountBuilder {
	static [__entity_ts.entityKind] = "MySqlEffectCountBuilder";
};
(0, __effect_core_query_effect_ts.applyEffectWrapper)(MySqlEffectCountBuilder);
//#endregion
exports.MySqlEffectCountBuilder = MySqlEffectCountBuilder;

//# sourceMappingURL=count.cjs.map