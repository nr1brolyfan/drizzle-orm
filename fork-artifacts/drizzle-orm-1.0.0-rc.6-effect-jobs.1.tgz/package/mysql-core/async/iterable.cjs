Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
//#region src/mysql-core/async/iterable.ts
/**
* @internal
* `iterator` of the async runtime's builders, mixed into them (`applyMixins`) next to `QueryPromise`: Effect builders
* have no iterator
*/
var MySqlAsyncIterableQuery = class {
	static [__entity_ts.entityKind] = "MySqlAsyncIterableQuery";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	async *iterator(placeholderValues) {
		yield* this._prepare().iterator(placeholderValues);
	}
};
//#endregion
exports.MySqlAsyncIterableQuery = MySqlAsyncIterableQuery;

//# sourceMappingURL=iterable.cjs.map