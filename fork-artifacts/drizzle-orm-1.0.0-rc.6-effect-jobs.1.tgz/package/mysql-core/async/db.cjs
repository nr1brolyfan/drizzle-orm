Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_async_count = require("./count.cjs");
const require_mysql_core_db = require("../db.cjs");
const require_mysql_core_async_delete = require("./delete.cjs");
const require_mysql_core_async_insert = require("./insert.cjs");
const require_mysql_core_async_query = require("./query.cjs");
const require_mysql_core_async_raw = require("./raw.cjs");
const require_mysql_core_async_select = require("./select.cjs");
const require_mysql_core_async_update = require("./update.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/mysql-core/async/db.ts
const mysqlAsyncBuilders = {
	select: require_mysql_core_async_select.MySqlAsyncSelectBase,
	insert: require_mysql_core_async_insert.MySqlAsyncInsertBase,
	update: require_mysql_core_async_update.MySqlAsyncUpdateBase,
	delete: require_mysql_core_async_delete.MySqlAsyncDeleteBase,
	count: require_mysql_core_async_count.MySqlAsyncCountBuilder,
	raw: require_mysql_core_async_raw.MySqlAsyncRaw,
	relationalQuery: require_mysql_core_async_query.MySqlAsyncRelationalQuery
};
var MySqlAsyncDatabase = class extends require_mysql_core_db.MySqlDatabase {
	static [__entity_ts.entityKind] = "MySqlDatabase";
	constructor(dialect, session, relations) {
		super(mysqlAsyncBuilders, dialect, session, relations);
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.MySqlAsyncDatabase = MySqlAsyncDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map