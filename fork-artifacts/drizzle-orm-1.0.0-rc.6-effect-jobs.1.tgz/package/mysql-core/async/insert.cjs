Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_query_builders_runnable = require("../query-builders/runnable.cjs");
const require_mysql_core_async_iterable = require("./iterable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
let __mysql_core_query_builders_insert_ts = require("../query-builders/insert.cjs");
//#region src/mysql-core/async/insert.ts
var MySqlAsyncInsertBase = class extends __mysql_core_query_builders_insert_ts.MySqlInsertBase {
	static [__entity_ts.entityKind] = "MySqlAsyncInsert";
};
(0, __utils_ts.applyMixins)(MySqlAsyncInsertBase, [
	__query_promise_ts.QueryPromise,
	require_mysql_core_query_builders_runnable.MySqlRunnableQuery,
	require_mysql_core_async_iterable.MySqlAsyncIterableQuery
]);
//#endregion
exports.MySqlAsyncInsertBase = MySqlAsyncInsertBase;

//# sourceMappingURL=insert.cjs.map