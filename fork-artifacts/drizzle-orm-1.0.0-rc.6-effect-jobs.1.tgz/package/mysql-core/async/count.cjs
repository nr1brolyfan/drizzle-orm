Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_query_builders_count = require("../query-builders/count.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
//#region src/mysql-core/async/count.ts
var MySqlAsyncCountBuilder = class extends require_mysql_core_query_builders_count.MySqlCountBuilder {
	static [__entity_ts.entityKind] = "MySqlAsyncCountBuilder";
};
(0, __utils_ts.applyMixins)(MySqlAsyncCountBuilder, [__query_promise_ts.QueryPromise]);
//#endregion
exports.MySqlAsyncCountBuilder = MySqlAsyncCountBuilder;

//# sourceMappingURL=count.cjs.map