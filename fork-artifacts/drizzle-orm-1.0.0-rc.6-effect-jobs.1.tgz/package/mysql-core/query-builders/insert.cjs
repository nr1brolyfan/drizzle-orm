Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_query_builders_query_builder = require("./query-builder.cjs");
let __entity_ts = require("../../entity.cjs");
let __table_ts = require("../../table.cjs");
let __utils_ts = require("../../utils.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
//#region src/mysql-core/query-builders/insert.ts
var MySqlInsertBuilder = class {
	table;
	session;
	dialect;
	columnList;
	builder;
	static [__entity_ts.entityKind] = "MySqlInsertBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	shouldIgnore = false;
	constructor(table, session, dialect, columnList, builder = MySqlInsertBase) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.columnList = columnList;
		this.builder = builder;
	}
	ignore() {
		this.shouldIgnore = true;
		return this;
	}
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		return new this.builder(this.table, values, this.shouldIgnore, this.session, this.dialect, false, this.columnList);
	}
	select(selectQuery) {
		const select = typeof selectQuery === "function" ? selectQuery(new require_mysql_core_query_builders_query_builder.QueryBuilder()) : selectQuery;
		if (!(0, __entity_ts.is)(select, __sql_sql_ts.SQL)) {
			const insertCols = Object.keys(this.table[__table_ts.Table.Symbol.Columns]);
			const selected = Object.keys(select._.selectedFields);
			for (const col of selected) if (!insertCols.includes(col)) throw new Error(`Insert select error: column "${col}" does not exist in table "${this.table[__table_ts.Table.Symbol.Name]}"`);
		}
		return new this.builder(this.table, select, this.shouldIgnore, this.session, this.dialect, true, this.columnList);
	}
};
var MySqlInsertBase = class {
	session;
	dialect;
	static [__entity_ts.entityKind] = "MySqlInsert";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	config;
	constructor(table, values, ignore, session, dialect, select, columnList) {
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			select,
			ignore,
			columnList
		};
	}
	/**
	* Adds an `on duplicate key update` clause to the query.
	*
	* Calling this method will update the row if any unique index conflicts. MySQL will automatically determine the conflict target based on the primary key and unique indexes.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#on-duplicate-key-update}
	*
	* @param config The `set` clause
	*
	* @example
	* ```ts
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW'})
	*   .onDuplicateKeyUpdate({ set: { brand: 'Porsche' }});
	* ```
	*
	* While MySQL does not directly support doing nothing on conflict, you can perform a no-op by setting any column's value to itself and achieve the same effect:
	*
	* ```ts
	* import { sql } from 'drizzle-orm';
	*
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onDuplicateKeyUpdate({ set: { id: sql`id` } });
	* ```
	*/
	onDuplicateKeyUpdate(config) {
		if (this.config.returning) throw new Error("`$returningId` cannot be used with `onDuplicateKeyUpdate`: updated rows' ids are not reported by the database.");
		const setSql = this.dialect.buildUpdateSet(this.config.table, (0, __utils_ts.mapUpdateSet)(this.config.table, config.set));
		this.config.onConflict = __sql_sql_ts.sql`update ${setSql}`;
		return this;
	}
	$returningId() {
		if (this.config.onConflict) throw new Error("`$returningId` cannot be used with `onDuplicateKeyUpdate`: updated rows' ids are not reported by the database.");
		const returning = [];
		for (const [key, value] of Object.entries(this.config.table[__table_ts.Table.Symbol.Columns])) if (value.primary) returning.push({
			field: value,
			fieldType: "Column",
			path: [key]
		});
		this.config.returning = returning;
		return this;
	}
	/**
	* Attach [sqlcommenter](https://google.github.io/sqlcommenter) comment to a query
	*/
	comment(comment) {
		this.config.comment = __sql_sql_ts.sql.comment(comment);
		return this;
	}
	getSQL() {
		return this.dialect.buildInsertQuery(this.config).sql;
	}
	toSQL() {
		return this.dialect.sqlToQuery(this.getSQL());
	}
	$dynamic() {
		return this;
	}
	/** @internal */
	_prepare() {
		const { sql, generatedIds } = this.dialect.buildInsertQuery(this.config);
		return this.session.prepareQuery(this.dialect.sqlToQuery(sql), "raw", this.dialect.mapperGenerators.$returning(this.config.returning, generatedIds));
	}
};
//#endregion
exports.MySqlInsertBase = MySqlInsertBase;
exports.MySqlInsertBuilder = MySqlInsertBuilder;

//# sourceMappingURL=insert.cjs.map