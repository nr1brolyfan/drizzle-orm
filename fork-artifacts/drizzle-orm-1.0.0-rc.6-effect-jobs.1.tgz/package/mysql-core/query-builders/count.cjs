Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
//#region src/mysql-core/query-builders/count.ts
var MySqlCountBuilder = class MySqlCountBuilder extends __sql_sql_ts.SQL {
	countConfig;
	static [__entity_ts.entityKind] = "MySqlCountBuilder";
	dialect;
	session;
	static buildCount(source, filters, parens) {
		const where = __sql_sql_ts.sql` where ${filters}`.if(filters);
		const query = __sql_sql_ts.sql`select count(*) from ${source}${where}`;
		return parens ? __sql_sql_ts.sql`(${query})` : query;
	}
	constructor(countConfig) {
		super(MySqlCountBuilder.buildCount(countConfig.source, countConfig.filters, true).queryChunks);
		this.countConfig = countConfig;
		this.dialect = countConfig.dialect;
		this.session = countConfig.session;
		this.mapWith((e) => {
			if (typeof e === "number") return e;
			return Number(e ?? 0);
		});
	}
	executableSql;
	build() {
		if (!this.executableSql) {
			const { source, filters } = this.countConfig;
			this.executableSql = MySqlCountBuilder.buildCount(source, filters);
		}
		return this.dialect.sqlToQuery(this.executableSql);
	}
	/**
	* Runs the query and returns a Promise of the result, with values for any `sql.placeholder()` it contains.
	*
	* Eager: the query is sent as soon as `execute` is called, whether or not the Promise is awaited. The builder
	* itself is lazy: awaiting it runs it the same way.
	*/
	execute(placeholderValues) {
		return this._prepare().execute(placeholderValues);
	}
	/** @internal */
	_prepare() {
		return this.session.prepareQuery(this.build(), "arrays", (rows) => {
			const v = rows[0]?.[0];
			if (typeof v === "number") return v;
			return v ? Number(v) : 0;
		});
	}
};
//#endregion
exports.MySqlCountBuilder = MySqlCountBuilder;

//# sourceMappingURL=count.cjs.map