Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_columns_string_common = require("./string.common.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/mysql-core/columns/enum.ts
var MySqlEnumColumnBuilder = class extends require_mysql_core_columns_string_common.MySqlStringColumnBaseBuilder {
	static [__entity_ts.entityKind] = "MySqlEnumColumnBuilder";
	constructor(name, values) {
		super(name, "string enum", "MySqlEnumColumn");
		this.config.enumValues = values;
	}
	/** @internal */
	build(table) {
		return new MySqlEnumColumn(table, this.config);
	}
};
var MySqlEnumColumn = class extends require_mysql_core_columns_string_common.MySqlStringBaseColumn {
	static [__entity_ts.entityKind] = "MySqlEnumColumn";
	/** @internal */
	codec = "enum";
	enumValues = this.config.enumValues;
	getSQLType() {
		return `enum(${this.enumValues.map((value) => `'${value}'`).join(",")})`;
	}
};
var MySqlEnumObjectColumnBuilder = class extends require_mysql_core_columns_string_common.MySqlStringColumnBaseBuilder {
	static [__entity_ts.entityKind] = "MySqlEnumObjectColumnBuilder";
	constructor(name, values) {
		super(name, "string enum", "MySqlEnumObjectColumn");
		this.config.enumValues = values;
	}
	/** @internal */
	build(table) {
		return new MySqlEnumObjectColumn(table, this.config);
	}
};
var MySqlEnumObjectColumn = class extends require_mysql_core_columns_string_common.MySqlStringBaseColumn {
	static [__entity_ts.entityKind] = "MySqlEnumObjectColumn";
	/** @internal */
	codec = "enum";
	enumValues = this.config.enumValues;
	getSQLType() {
		return `enum(${this.enumValues.map((value) => `'${value}'`).join(",")})`;
	}
};
function mysqlEnum(a, b) {
	if (typeof a === "string" && Array.isArray(b) || Array.isArray(a)) {
		const name = typeof a === "string" && a.length > 0 ? a : "";
		const values = (typeof a === "string" ? b : a) ?? [];
		if (values.length === 0) throw new Error(`You have an empty array for "${name}" enum values`);
		return new MySqlEnumColumnBuilder(name, values);
	}
	if (typeof a === "string" && typeof b === "object" || typeof a === "object") {
		const name = typeof a === "object" ? "" : a;
		const values = typeof a === "object" ? Object.values(a) : typeof b === "object" ? Object.values(b) : [];
		if (values.length === 0) throw new Error(`You have an empty array for "${name}" enum values`);
		return new MySqlEnumObjectColumnBuilder(name, values);
	}
}
//#endregion
exports.MySqlEnumColumn = MySqlEnumColumn;
exports.MySqlEnumColumnBuilder = MySqlEnumColumnBuilder;
exports.MySqlEnumObjectColumn = MySqlEnumObjectColumn;
exports.MySqlEnumObjectColumnBuilder = MySqlEnumObjectColumnBuilder;
exports.mysqlEnum = mysqlEnum;

//# sourceMappingURL=enum.cjs.map