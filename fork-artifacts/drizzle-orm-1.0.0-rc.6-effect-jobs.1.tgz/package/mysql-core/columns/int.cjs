Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
//#region src/mysql-core/columns/int.ts
var MySqlIntBuilder = class extends require_mysql_core_columns_common.MySqlColumnBuilderWithAutoIncrement {
	static [__entity_ts.entityKind] = "MySqlIntBuilder";
	constructor(name, config) {
		super(name, config?.unsigned ? "number uint32" : "number int32", "MySqlInt");
		this.config.unsigned = config ? config.unsigned : false;
	}
	/** @internal */
	build(table) {
		return new MySqlInt(table, this.config);
	}
};
var MySqlInt = class extends require_mysql_core_columns_common.MySqlColumnWithAutoIncrement {
	static [__entity_ts.entityKind] = "MySqlInt";
	/** @internal */
	codec = "int";
	getSQLType() {
		return `int${this.config.unsigned ? " unsigned" : ""}`;
	}
};
function int(a, b) {
	const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
	return new MySqlIntBuilder(name, config);
}
//#endregion
exports.MySqlInt = MySqlInt;
exports.MySqlIntBuilder = MySqlIntBuilder;
exports.int = int;

//# sourceMappingURL=int.cjs.map