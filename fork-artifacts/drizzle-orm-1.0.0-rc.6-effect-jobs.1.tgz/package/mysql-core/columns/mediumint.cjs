Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
//#region src/mysql-core/columns/mediumint.ts
var MySqlMediumIntBuilder = class extends require_mysql_core_columns_common.MySqlColumnBuilderWithAutoIncrement {
	static [__entity_ts.entityKind] = "MySqlMediumIntBuilder";
	constructor(name, config) {
		super(name, config?.unsigned ? "number uint24" : "number int24", "MySqlMediumInt");
		this.config.unsigned = config ? config.unsigned : false;
	}
	/** @internal */
	build(table) {
		return new MySqlMediumInt(table, this.config);
	}
};
var MySqlMediumInt = class extends require_mysql_core_columns_common.MySqlColumnWithAutoIncrement {
	static [__entity_ts.entityKind] = "MySqlMediumInt";
	/** @internal */
	codec = "mediumint";
	getSQLType() {
		return `mediumint${this.config.unsigned ? " unsigned" : ""}`;
	}
};
function mediumint(a, b) {
	const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
	return new MySqlMediumIntBuilder(name, config);
}
//#endregion
exports.MySqlMediumInt = MySqlMediumInt;
exports.MySqlMediumIntBuilder = MySqlMediumIntBuilder;
exports.mediumint = mediumint;

//# sourceMappingURL=mediumint.cjs.map