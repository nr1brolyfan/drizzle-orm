Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/mysql-core/columns/json.ts
var MySqlJsonBuilder = class extends require_mysql_core_columns_common.MySqlColumnBuilder {
	static [__entity_ts.entityKind] = "MySqlJsonBuilder";
	constructor(name) {
		super(name, "object json", "MySqlJson");
	}
	/** @internal */
	build(table) {
		return new MySqlJson(table, this.config);
	}
};
var MySqlJson = class extends require_mysql_core_columns_common.MySqlColumn {
	static [__entity_ts.entityKind] = "MySqlJson";
	/** @internal */
	codec = "json";
	getSQLType() {
		return "json";
	}
	mapToDriverValue = (value) => {
		return JSON.stringify(value);
	};
};
function json(name) {
	return new MySqlJsonBuilder(name ?? "");
}
//#endregion
exports.MySqlJson = MySqlJson;
exports.MySqlJsonBuilder = MySqlJsonBuilder;
exports.json = json;

//# sourceMappingURL=json.cjs.map