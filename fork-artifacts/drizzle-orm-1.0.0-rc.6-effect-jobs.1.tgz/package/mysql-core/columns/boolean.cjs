Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/mysql-core/columns/boolean.ts
var MySqlBooleanBuilder = class extends require_mysql_core_columns_common.MySqlColumnBuilder {
	static [__entity_ts.entityKind] = "MySqlBooleanBuilder";
	constructor(name) {
		super(name, "boolean", "MySqlBoolean");
	}
	/** @internal */
	build(table) {
		return new MySqlBoolean(table, this.config);
	}
};
var MySqlBoolean = class extends require_mysql_core_columns_common.MySqlColumn {
	static [__entity_ts.entityKind] = "MySqlBoolean";
	/** @internal */
	codec = "boolean";
	getSQLType() {
		return "boolean";
	}
};
function boolean(name) {
	return new MySqlBooleanBuilder(name ?? "");
}
//#endregion
exports.MySqlBoolean = MySqlBoolean;
exports.MySqlBooleanBuilder = MySqlBooleanBuilder;
exports.boolean = boolean;

//# sourceMappingURL=boolean.cjs.map