Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
//#region src/mysql-core/columns/double.ts
var MySqlDoubleBuilder = class extends require_mysql_core_columns_common.MySqlColumnBuilderWithAutoIncrement {
	static [__entity_ts.entityKind] = "MySqlDoubleBuilder";
	constructor(name, config) {
		super(name, config?.unsigned ? "number udouble" : "number double", "MySqlDouble");
		this.config.precision = config?.precision;
		this.config.scale = config?.scale;
		this.config.unsigned = config?.unsigned;
	}
	/** @internal */
	build(table) {
		return new MySqlDouble(table, this.config);
	}
};
var MySqlDouble = class extends require_mysql_core_columns_common.MySqlColumnWithAutoIncrement {
	static [__entity_ts.entityKind] = "MySqlDouble";
	/** @internal */
	codec = "double";
	precision = this.config.precision;
	scale = this.config.scale;
	unsigned = this.config.unsigned;
	getSQLType() {
		let type = "";
		if (this.precision !== void 0 && this.scale !== void 0) type += `double(${this.precision},${this.scale})`;
		else if (this.precision === void 0) type += "double";
		else type += `double(${this.precision})`;
		return this.unsigned ? `${type} unsigned` : type;
	}
};
function double(a, b) {
	const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
	return new MySqlDoubleBuilder(name, config);
}
//#endregion
exports.MySqlDouble = MySqlDouble;
exports.MySqlDoubleBuilder = MySqlDoubleBuilder;
exports.double = double;

//# sourceMappingURL=double.cjs.map