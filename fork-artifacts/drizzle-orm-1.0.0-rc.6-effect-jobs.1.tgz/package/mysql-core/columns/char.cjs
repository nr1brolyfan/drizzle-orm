Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_core_columns_string_common = require("./string.common.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
//#region src/mysql-core/columns/char.ts
var MySqlCharBuilder = class extends require_mysql_core_columns_string_common.MySqlStringColumnBaseBuilder {
	static [__entity_ts.entityKind] = "MySqlCharBuilder";
	constructor(name, config) {
		super(name, config.enum?.length ? "string enum" : "string", "MySqlChar");
		this.config.length = config.length ?? 1;
		this.config.setLength = config.length !== void 0;
		this.config.enum = config.enum;
	}
	/** @internal */
	build(table) {
		return new MySqlChar(table, this.config);
	}
};
var MySqlChar = class extends require_mysql_core_columns_string_common.MySqlStringBaseColumn {
	static [__entity_ts.entityKind] = "MySqlChar";
	/** @internal */
	codec = "char";
	enumValues = this.config.enum;
	getSQLType() {
		return this.config.setLength ? `char(${this.length})` : `char`;
	}
};
function char(a, b = {}) {
	const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
	return new MySqlCharBuilder(name, config);
}
//#endregion
exports.MySqlChar = MySqlChar;
exports.MySqlCharBuilder = MySqlCharBuilder;
exports.char = char;

//# sourceMappingURL=char.cjs.map