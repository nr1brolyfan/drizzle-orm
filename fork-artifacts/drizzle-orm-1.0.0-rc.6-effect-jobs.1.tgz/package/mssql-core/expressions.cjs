Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __sql_sql_ts = require("../sql/sql.cjs");
//#region src/mssql-core/expressions.ts
function concat(...values) {
	return __sql_sql_ts.sql`concat(${__sql_sql_ts.sql.join(values.map((value) => __sql_sql_ts.sql`${value}`), __sql_sql_ts.sql`, `)})`;
}
function substring(column, start, length) {
	return __sql_sql_ts.sql`substring(${column}, ${start}, ${length})`;
}
//#endregion
exports.concat = concat;
exports.substring = substring;
var __sql_expressions_index_ts = require("../sql/expressions/index.cjs");
Object.keys(__sql_expressions_index_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __sql_expressions_index_ts[k];
		}
	});
});

//# sourceMappingURL=expressions.cjs.map