Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
//#region src/mssql-core/codecs.ts
const MSSQL_ALIAS_TO_TYPE_MAP = {
	dec: "decimal",
	"national char": "char",
	nchar: "char",
	"national character": "char",
	"character varying": "varchar",
	"char varying": "varchar",
	character: "char",
	nvarchar: "varchar",
	"national char varying": "varchar",
	"national character varying": "varchar",
	ntext: "text",
	"binary varying": "varbinary",
	rowversion: "varbinary",
	timestamp: "varbinary",
	smalldatetime: "datetime",
	smallmoney: "decimal",
	money: "decimal",
	"double precision": "float"
};
function resolveMsSqlTypeAlias(type) {
	return MSSQL_ALIAS_TO_TYPE_MAP[type] ?? type;
}
const castToText = (name) => __sql_sql_ts.sql`cast(${name} as varchar(max))`;
const bufferFromBase64 = (value) => Buffer.from(value, "base64");
const dateFromZonelessJson = (value) => /* @__PURE__ */ new Date(`${value}Z`);
const genericMsSqlCodecs = {
	decimal: { castInJson: castToText },
	"decimal:number": {
		castInJson: castToText,
		normalizeInJson: Number
	},
	"decimal:bigint": {
		castInJson: castToText,
		normalizeInJson: BigInt
	},
	numeric: { castInJson: castToText },
	"numeric:number": {
		castInJson: castToText,
		normalizeInJson: Number
	},
	"numeric:bigint": {
		castInJson: castToText,
		normalizeInJson: BigInt
	},
	bigint: {
		castInJson: castToText,
		normalizeInJson: BigInt
	},
	"bigint:number": {
		castInJson: castToText,
		normalizeInJson: Number
	},
	"bigint:string": { castInJson: castToText },
	datetime: { normalizeInJson: dateFromZonelessJson },
	"datetime:string": { normalizeInJson: (value) => dateFromZonelessJson(value).toISOString() },
	datetime2: { normalizeInJson: dateFromZonelessJson },
	"datetime2:string": { normalizeInJson: (value) => dateFromZonelessJson(value).toISOString() },
	datetimeoffset: { normalizeInJson: (value) => new Date(value) },
	date: { normalizeInJson: (value) => new Date(value) },
	time: { normalizeInJson: (value) => /* @__PURE__ */ new Date(`1970-01-01T${value}Z`) },
	"time:string": { normalizeInJson: (value) => {
		const [time, fraction] = value.split(".");
		return `${time}.${(fraction ?? "").padEnd(3, "0").slice(0, 3)}`;
	} },
	binary: { normalizeInJson: bufferFromBase64 },
	varbinary: { normalizeInJson: bufferFromBase64 }
};
const refineGenericMsSqlCodecs = (extension) => (0, __codecs_ts.refineCodecs)(genericMsSqlCodecs, extension);
const TYPE_RANK = Object.fromEntries([
	["datetimeoffset", "datetimeoffset:string"],
	["datetime2", "datetime2:string"],
	["datetime", "datetime:string"],
	["date", "date:string"],
	["time", "time:string"],
	["float"],
	["real"],
	[
		"decimal",
		"decimal:number",
		"decimal:bigint",
		"numeric",
		"numeric:number",
		"numeric:bigint"
	],
	[
		"bigint",
		"bigint:number",
		"bigint:string"
	],
	["int"],
	["smallint"],
	["tinyint"],
	["bit"],
	["text"],
	["varchar", "varchar:json"],
	["char"],
	["varbinary"],
	["binary"]
].flatMap((group, rank) => group.map((type) => [type, rank])));
function resolveUnionType(left, right) {
	const l = TYPE_RANK[left];
	const r = TYPE_RANK[right];
	if (l === void 0 || r === void 0) return void 0;
	return r < l ? right : left;
}
//#endregion
exports.bufferFromBase64 = bufferFromBase64;
exports.castToText = castToText;
exports.dateFromZonelessJson = dateFromZonelessJson;
exports.genericMsSqlCodecs = genericMsSqlCodecs;
exports.refineGenericMsSqlCodecs = refineGenericMsSqlCodecs;
exports.resolveMsSqlTypeAlias = resolveMsSqlTypeAlias;
exports.resolveUnionType = resolveUnionType;

//# sourceMappingURL=codecs.cjs.map