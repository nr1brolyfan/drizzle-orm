Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __column_ts = require("../../column.cjs");
let __column_builder_ts = require("../../column-builder.cjs");
let __mssql_core_foreign_keys_ts = require("../foreign-keys.cjs");
//#region src/mssql-core/columns/common.ts
var MsSqlColumnBuilder = class extends __column_builder_ts.ColumnBuilder {
	static [__entity_ts.entityKind] = "MsSqlColumnBuilder";
	foreignKeyConfigs = [];
	references(ref, actions = {}) {
		this.foreignKeyConfigs.push({
			ref,
			actions
		});
		return this;
	}
	unique(name) {
		this.config.isUnique = true;
		this.config.uniqueName = name;
		return this;
	}
	generatedAlwaysAs(as, config) {
		this.config.generated = {
			as,
			type: "always",
			mode: config?.mode ?? "virtual"
		};
		return this;
	}
	/** @internal */
	buildForeignKeys(column, table) {
		return this.foreignKeyConfigs.map(({ ref, actions }) => {
			return ((ref, actions) => {
				const builder = new __mssql_core_foreign_keys_ts.ForeignKeyBuilder(() => {
					const foreignColumn = ref();
					return {
						columns: [column],
						foreignColumns: [foreignColumn]
					};
				});
				if (actions.onUpdate) builder.onUpdate(actions.onUpdate);
				if (actions.onDelete) builder.onDelete(actions.onDelete);
				return builder.build(table);
			})(ref, actions);
		});
	}
};
var MsSqlColumn = class extends __column_ts.Column {
	static [__entity_ts.entityKind] = "MsSqlColumn";
	/** @internal */
	table;
	constructor(table, config) {
		super(table, config);
		this.table = table;
	}
	/** @internal */
	shouldDisableInsert() {
		return !!this.config.generated;
	}
};
var MsSqlColumnBuilderWithIdentity = class extends MsSqlColumnBuilder {
	static [__entity_ts.entityKind] = "MsSqlColumnBuilderWithAutoIncrement";
	constructor(name, dataType, columnType) {
		super(name, dataType, columnType);
	}
	identity(config) {
		this.config.identity = {
			seed: config ? config.seed : 1,
			increment: config ? config.increment : 1
		};
		this.config.hasDefault = true;
		this.config.notNull = true;
		return this;
	}
};
var MsSqlColumnWithIdentity = class extends MsSqlColumn {
	static [__entity_ts.entityKind] = "MsSqlColumnWithAutoIncrement";
	identity = this.config.identity;
	/** @internal */
	shouldDisableInsert() {
		return !!this.identity;
	}
};
//#endregion
exports.MsSqlColumn = MsSqlColumn;
exports.MsSqlColumnBuilder = MsSqlColumnBuilder;
exports.MsSqlColumnBuilderWithIdentity = MsSqlColumnBuilderWithIdentity;
exports.MsSqlColumnWithIdentity = MsSqlColumnWithIdentity;

//# sourceMappingURL=common.cjs.map