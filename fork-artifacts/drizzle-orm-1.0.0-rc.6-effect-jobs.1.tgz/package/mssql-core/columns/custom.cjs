Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mssql_core_columns_common = require("./common.cjs");
const require_mssql_core_codecs = require("../codecs.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
//#region src/mssql-core/columns/custom.ts
var MsSqlCustomColumnBuilder = class extends require_mssql_core_columns_common.MsSqlColumnBuilder {
	static [__entity_ts.entityKind] = "MsSqlCustomColumnBuilder";
	constructor(name, fieldConfig, customTypeParams) {
		super(name, "custom", "MsSqlCustomColumn");
		this.config.fieldConfig = fieldConfig;
		this.config.customTypeParams = customTypeParams;
	}
	/** @internal */
	build(table) {
		return new MsSqlCustomColumn(table, this.config);
	}
};
var MsSqlCustomColumn = class extends require_mssql_core_columns_common.MsSqlColumn {
	static [__entity_ts.entityKind] = "MsSqlCustomColumn";
	/** @internal */
	codec;
	sqlName;
	mapFromJsonValue;
	jsonSelectIdentifier;
	constructor(table, config) {
		super(table, config);
		this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
		this.mapToDriverValue = config.customTypeParams.toDriver ?? this.mapToDriverValue;
		this.mapFromDriverValue = config.customTypeParams.fromDriver ?? this.mapFromDriverValue;
		this.mapFromJsonValue = config.customTypeParams.fromJson;
		this.jsonSelectIdentifier = config.customTypeParams.forJsonSelect;
		const cfgCodec = typeof config.customTypeParams.codec === "string" || typeof config.customTypeParams.codec === "undefined" ? config.customTypeParams.codec : config.customTypeParams.codec(config.fieldConfig);
		this.codec = typeof cfgCodec === "string" ? require_mssql_core_codecs.resolveMsSqlTypeAlias(cfgCodec) : void 0;
	}
	getSQLType() {
		return this.sqlName;
	}
};
/**
* Custom mssql database data type generator
*/
function customType(customTypeParams) {
	return (a, b) => {
		const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
		return new MsSqlCustomColumnBuilder(name, config, customTypeParams);
	};
}
//#endregion
exports.MsSqlCustomColumn = MsSqlCustomColumn;
exports.MsSqlCustomColumnBuilder = MsSqlCustomColumnBuilder;
exports.customType = customType;

//# sourceMappingURL=custom.cjs.map