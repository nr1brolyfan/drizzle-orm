Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_view_common = require("../view-common.cjs");
const require_errors = require("../errors.cjs");
const require_mssql_core_columns_common = require("./columns/common.cjs");
const require_mssql_core_codecs = require("./codecs.cjs");
const require_mssql_core_table = require("./table.cjs");
let __view_ts = require("../view.cjs");
let __entity_ts = require("../entity.cjs");
let __table_ts = require("../table.cjs");
let __utils_ts = require("../utils.cjs");
let __column_ts = require("../column.cjs");
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __alias_ts = require("../alias.cjs");
let __relations_ts = require("../relations.cjs");
let __sql_common_chunks_ts = require("../sql/common-chunks.cjs");
let __migrator_utils_ts = require("../migrator.utils.cjs");
let __up_migrations_mssql_ts = require("../up-migrations/mssql.cjs");
//#region src/mssql-core/dialect.ts
const escapeMsSqlName = (0, __utils_ts.memoizeEscape)((name) => `[${name.replace(/\]/g, "]]")}]`);
const rqbChunks = {
	select: new __sql_common_chunks_ts.StringChunk("select"),
	top: new __sql_common_chunks_ts.StringChunk(" top("),
	offset: new __sql_common_chunks_ts.StringChunk(" offset "),
	rows: new __sql_common_chunks_ts.StringChunk(" rows"),
	fetchNext: new __sql_common_chunks_ts.StringChunk(" fetch next "),
	rowsOnly: new __sql_common_chunks_ts.StringChunk(" rows only"),
	jsonQueryOpen: new __sql_common_chunks_ts.StringChunk("json_query("),
	jsonQueryCoalesceOpen: new __sql_common_chunks_ts.StringChunk("json_query(coalesce("),
	coalesceOpen: new __sql_common_chunks_ts.StringChunk("coalesce("),
	jsonOneClose: new __sql_common_chunks_ts.StringChunk(".[j] as "),
	jsonOneNestedClose: new __sql_common_chunks_ts.StringChunk(".[j]) as "),
	jsonManyClose: new __sql_common_chunks_ts.StringChunk(`.[j], '[]') as `),
	jsonManyNestedClose: new __sql_common_chunks_ts.StringChunk(`.[j], '[]')) as `),
	applyOpen: new __sql_common_chunks_ts.StringChunk(" outer apply ("),
	forJsonOne: new __sql_common_chunks_ts.StringChunk(" for json path, include_null_values, without_array_wrapper) "),
	forJsonMany: new __sql_common_chunks_ts.StringChunk(" for json path, include_null_values) "),
	applyColumn: new __sql_common_chunks_ts.StringChunk("([j])")
};
var MsSqlDialect = class {
	static [__entity_ts.entityKind] = "MsSqlDialect";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	codecs;
	mapperGenerators;
	constructor(config) {
		this.codecs = new __codecs_ts.CodecsCollection(require_mssql_core_codecs.resolveMsSqlTypeAlias, config?.codecs);
		this.mapperGenerators = config?.useJitMappers ? {
			rows: __utils_ts.makeJitQueryMapper,
			relationalRows: __relations_ts.makeJitRqbMapper
		} : {
			rows: __utils_ts.makeDefaultQueryMapper,
			relationalRows: __relations_ts.makeDefaultRqbMapper
		};
	}
	async migrate(migrations, session, config) {
		const migrationsSchema = typeof config === "string" ? "drizzle" : config.migrationsSchema ?? "drizzle";
		const migrationSchemaCreate = __sql_sql_ts.sql`
			IF NOT EXISTS (
				SELECT 1 FROM sys.schemas WHERE name = ${migrationsSchema}
			)
			EXEC(\'CREATE SCHEMA ${__sql_sql_ts.sql.identifier(migrationsSchema)}\')
		`;
		await session.execute(migrationSchemaCreate);
		const migrationsTable = typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const { newDb } = await (0, __up_migrations_mssql_ts.upgradeIfNeeded)(migrationsSchema, migrationsTable, session, migrations);
		if (newDb) {
			const migrationTableCreate = __sql_sql_ts.sql`
			IF NOT EXISTS (
				SELECT 1 FROM INFORMATION_SCHEMA.TABLES 
				WHERE TABLE_NAME = ${migrationsTable} AND TABLE_SCHEMA = ${migrationsSchema}
			)
			CREATE TABLE ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)} (
				id bigint identity PRIMARY KEY,
				hash text NOT NULL,
				created_at bigint,
				name text,
				applied_at datetime2 NOT NULL DEFAULT GETUTCDATE()
			)
		`;
			await session.execute(migrationTableCreate);
		}
		const dbMigrations = (await session.execute(__sql_sql_ts.sql`select id, hash, created_at, name from ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)}`)).recordset;
		if (typeof config === "object" && config.init) {
			if (dbMigrations.length > 0) return { exitCode: "databaseMigrations" };
			if (migrations.length > 1) return { exitCode: "localMigrations" };
			const [migration] = migrations;
			if (!migration) return;
			await session.execute(__sql_sql_ts.sql`insert into ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)} ([hash], [created_at], [name]) values(${migration.hash}, ${migration.folderMillis}, ${migration.name})`);
			return;
		}
		const migrationsToRun = (0, __migrator_utils_ts.getMigrationsToRun)({
			localMigrations: migrations,
			dbMigrations
		});
		await session.transaction(async (tx) => {
			for (const migration of migrationsToRun) {
				for (const stmt of migration.sql) await tx.execute(__sql_sql_ts.sql.raw(stmt));
				await tx.execute(__sql_sql_ts.sql`insert into ${__sql_sql_ts.sql.identifier(migrationsSchema)}.${__sql_sql_ts.sql.identifier(migrationsTable)} ([hash], [created_at], [name]) values(${migration.hash}, ${migration.folderMillis}, ${migration.name})`);
			}
		});
	}
	escapeName(name) {
		return escapeMsSqlName(name);
	}
	escapeParam(_num) {
		return `@par${_num}`;
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const queriesLen = queries.length;
		const withSqlChunks = new Array(queriesLen + 1);
		let writeIdx = 0;
		withSqlChunks[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["with "];
		for (let i = 0; i < queriesLen; ++i) {
			const w = queries[i];
			withSqlChunks[writeIdx++] = i < queriesLen - 1 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql}), ` : __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql}) `;
		}
		return new __sql_sql_ts.SQL(withSqlChunks);
	}
	buildDeleteQuery({ table, where, output }) {
		const outputSql = output ? __sql_sql_ts.sql` output ${this.buildSelectionOutput(output, { type: "DELETED" })}` : void 0;
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		return __sql_sql_ts.sql`delete from ${table}${outputSql}${whereSql}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[__table_ts.Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setLength = columnNames.length;
		const setArr = new Array(setLength);
		for (let i = 0; i < columnNames.length; ++i) {
			const colName = columnNames[i];
			const col = tableColumns[colName];
			let value;
			if (set[colName] !== void 0) value = set[colName];
			else {
				const updateRes = col.onUpdateFn?.();
				value = (0, __entity_ts.is)(updateRes, __sql_sql_ts.SQL) ? updateRes : __sql_sql_ts.sql.param(updateRes, col);
			}
			setArr[i] = i < setLength - 1 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}, ` : __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}`;
		}
		return new __sql_sql_ts.SQL(setArr);
	}
	buildUpdateQuery({ table, set, where, output }) {
		const setSql = this.buildUpdateSet(table, set);
		const outputSql = __sql_sql_ts.sql``;
		if (output) {
			outputSql.append(__sql_sql_ts.sql` output `);
			if (output.inserted) outputSql.append(this.buildSelectionOutput(output.inserted, { type: "INSERTED" }));
			if (output.deleted) {
				if (output.inserted) outputSql.append(__sql_sql_ts.sql`, `);
				outputSql.append(this.buildSelectionOutput(output.deleted, { type: "DELETED" }));
			}
		}
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		return __sql_sql_ts.sql`update ${table} set ${setSql}${outputSql}${whereSql}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false, table } = {}) {
		const { length: columnsLen } = fields;
		const chunks = [];
		const tableKind = (0, __sql_sql_ts.chunkKindOf)(table);
		const tableName = table ? (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.sql) || (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.subquery) ? void 0 : table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}` : void 0;
		for (let i = 0; i < columnsLen; ++i) {
			const { field, fieldType } = fields[i];
			switch (fieldType) {
				case "Column": {
					let name;
					if (isSingleTable) name = field.isAlias ? __sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name) : __sql_sql_ts.sql.identifier(field.name);
					else name = field.isAlias ? (0, __alias_ts.getOriginalColumnFromAlias)(field) : field;
					chunks.push(field.isAlias ? __sql_sql_ts.sql`${name} as ${field}` : name);
					break;
				}
				case "SQL.Aliased":
					if (field.isSelectionField) {
						const query = !isSingleTable && field.origin !== void 0 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(field.origin)}.${__sql_sql_ts.sql.identifier(field.fieldAlias)}` : __sql_sql_ts.sql.identifier(field.fieldAlias);
						chunks.push(query);
					} else {
						if (isSingleTable && tableName !== void 0) {
							const { queryChunks } = field.sql;
							const newChunks = new Array(queryChunks.length);
							let abort = false;
							for (let i = 0; i < queryChunks.length; ++i) {
								const c = queryChunks[i];
								if ((0, __entity_ts.is)(c, __column_ts.Column)) {
									const { table } = c;
									if ((table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}`) !== tableName) {
										abort = true;
										break;
									}
									newChunks[i] = __sql_sql_ts.sql.identifier(c.name);
								} else newChunks[i] = c;
							}
							if (abort) chunks.push(field.sql);
							else {
								const newSql = new __sql_sql_ts.SQL(newChunks);
								if (field.sql.shouldInlineParams) newSql.inlineParams();
								chunks.push(newSql);
							}
						} else chunks.push(field.sql);
						chunks.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
					}
					break;
				case "SQL":
					if (isSingleTable && tableName !== void 0) {
						const { queryChunks } = field;
						const newChunks = new Array(queryChunks.length);
						let abort = false;
						for (let i = 0; i < queryChunks.length; ++i) {
							const c = queryChunks[i];
							if ((0, __entity_ts.is)(c, __column_ts.Column)) {
								const { table } = c;
								if ((table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}`) !== tableName) {
									abort = true;
									break;
								}
								newChunks[i] = __sql_sql_ts.sql.identifier(c.name);
							} else newChunks[i] = c;
						}
						if (abort) chunks.push(field);
						else {
							const newSql = new __sql_sql_ts.SQL(newChunks);
							if (field.shouldInlineParams) newSql.inlineParams();
							chunks.push(newSql);
						}
					} else chunks.push(field);
					break;
				case "Subquery": if (!field._.isWith) {
					const inner = __sql_sql_ts.sql`(${field._.sql})`;
					chunks.push(__sql_sql_ts.sql`${inner} ${__sql_sql_ts.sql.identifier(field._.alias)}`);
				} else chunks.push(field);
			}
			if (i < columnsLen - 1) chunks.push(__sql_common_chunks_ts.commonStringChunks[", "]);
		}
		return new __sql_sql_ts.SQL(chunks);
	}
	buildSelectionOutput(fields, { type }) {
		const { length: columnsLen } = fields;
		const chunks = [];
		for (let i = 0; i < columnsLen; ++i) {
			const { field, fieldType } = fields[i];
			switch (fieldType) {
				case "Column": {
					const name = __sql_sql_ts.sql`${new __sql_common_chunks_ts.StringChunk(`${type}.`)}${__sql_sql_ts.sql.identifier(field.isAlias ? (0, __alias_ts.getOriginalColumnFromAlias)(field).name : field.name)}`;
					chunks.push(field.isAlias ? __sql_sql_ts.sql`${name} as ${field}` : name);
					break;
				}
				case "SQL.Aliased":
					if (field.isSelectionField) {
						const query = __sql_sql_ts.sql`${new __sql_common_chunks_ts.StringChunk(`${type}.`)}${__sql_sql_ts.sql.identifier(field.fieldAlias)}`;
						chunks.push(query);
					} else {
						const query = field.sql;
						chunks.push(new __sql_sql_ts.SQL(query.queryChunks.map((c) => {
							if ((0, __entity_ts.is)(c, require_mssql_core_columns_common.MsSqlColumn)) return __sql_sql_ts.sql.join([new __sql_common_chunks_ts.StringChunk(`${type}.`), __sql_sql_ts.sql.identifier(c.name)]);
							return c;
						})));
						chunks.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
					}
					break;
				case "SQL": {
					const query = field;
					chunks.push(new __sql_sql_ts.SQL(query.queryChunks.map((c) => {
						if ((0, __entity_ts.is)(c, require_mssql_core_columns_common.MsSqlColumn)) return __sql_sql_ts.sql.join([new __sql_common_chunks_ts.StringChunk(`${type}.`), __sql_sql_ts.sql.identifier(c.name)]);
						return c;
					})));
					break;
				}
			}
			if (i < columnsLen - 1) chunks.push(__sql_common_chunks_ts.commonStringChunks[", "]);
		}
		return new __sql_sql_ts.SQL(chunks);
	}
	buildSelectQuery({ withList, fieldsFlat, where, having, table, joins, orderBy, groupBy, fetch, for: _for, top, offset, distinct, setOperators }) {
		if (!fieldsFlat) throw new Error("Select query builder must be provided with `fieldsFlat` on `buildSelectQuery` invocation");
		const fieldsList = fieldsFlat;
		const tableKind = (0, __sql_sql_ts.chunkKindOf)(table);
		const ownTableName = (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.subquery) ? table._.alias : (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.view) ? table[require_view_common.ViewBaseConfig].name : (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.sql) ? void 0 : (0, __table_ts.getTableName)(table);
		for (const f of fieldsList) if ((0, __entity_ts.is)(f.field, __column_ts.Column) && (0, __table_ts.getTableName)(f.field.table) !== ownTableName && !((table) => joins?.some(({ alias }) => alias === (table[__table_ts.Table.Symbol.IsAlias] ? (0, __table_ts.getTableName)(table) : table[__table_ts.Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = (0, __table_ts.getTableName)(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		const distinctSql = distinct ? __sql_sql_ts.sql` distinct` : void 0;
		const topSql = top === void 0 ? void 0 : __sql_sql_ts.sql` top(${top})`;
		const selection = this.buildSelection(fieldsList, {
			isSingleTable,
			table
		});
		const tableSql = (() => {
			if ((0, __entity_ts.is)(table, __table_ts.Table) && table[__table_ts.Table.Symbol.OriginalName] !== table[__table_ts.Table.Symbol.Name]) {
				let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.OriginalName])} ${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Name])}`;
				if (table[__table_ts.Table.Symbol.Schema]) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__table_ts.Table.Symbol.Schema])}.${fullName}`;
				return fullName;
			}
			if ((0, __entity_ts.is)(table, __view_ts.View) && table[require_view_common.ViewBaseConfig].isAlias) {
				let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[require_view_common.ViewBaseConfig].originalName)}`;
				if (table[require_view_common.ViewBaseConfig].schema) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[require_view_common.ViewBaseConfig].schema)}.${fullName}`;
				return __sql_sql_ts.sql`${fullName} ${__sql_sql_ts.sql.identifier(table[require_view_common.ViewBaseConfig].name)}`;
			}
			return table;
		})();
		const joinsArray = [];
		if (joins) for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(__sql_common_chunks_ts.commonStringChunks[" "]);
			const table = joinMeta.table;
			const joinKeyword = joinMeta.lateral ? new __sql_common_chunks_ts.StringChunk(joinMeta.joinType === "left" ? "outer apply" : "cross apply") : new __sql_common_chunks_ts.StringChunk(`${joinMeta.joinType} join`);
			const onSql = joinMeta.on ? __sql_sql_ts.sql` on ${joinMeta.on}` : void 0;
			if ((0, __entity_ts.is)(table, require_mssql_core_table.MsSqlTable)) {
				const tableName = table[require_mssql_core_table.MsSqlTable.Symbol.Name];
				const tableSchema = table[require_mssql_core_table.MsSqlTable.Symbol.Schema];
				const origTableName = table[require_mssql_core_table.MsSqlTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${joinKeyword} ${tableSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(tableSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origTableName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}${onSql}`);
			} else if ((0, __entity_ts.is)(table, __view_ts.View)) {
				const viewName = table[require_view_common.ViewBaseConfig].name;
				const viewSchema = table[require_view_common.ViewBaseConfig].schema;
				const origViewName = table[require_view_common.ViewBaseConfig].originalName;
				const alias = viewName === origViewName ? void 0 : joinMeta.alias;
				joinsArray.push(__sql_sql_ts.sql`${joinKeyword} ${viewSchema ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(viewSchema)}.` : void 0}${__sql_sql_ts.sql.identifier(origViewName)}${alias && __sql_sql_ts.sql` ${__sql_sql_ts.sql.identifier(alias)}`}${onSql}`);
			} else joinsArray.push(__sql_sql_ts.sql`${joinKeyword} ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(__sql_common_chunks_ts.commonStringChunks[" "]);
		}
		const joinsSql = new __sql_sql_ts.SQL(joinsArray);
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const havingSql = having ? __sql_sql_ts.sql` having ${having}` : void 0;
		let orderBySql;
		if (orderBy && orderBy.length > 0) orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderBy, __sql_common_chunks_ts.commonStringChunks[", "])}`;
		let groupBySql;
		if (groupBy && groupBy.length > 0) groupBySql = __sql_sql_ts.sql` group by ${__sql_sql_ts.sql.join(groupBy, __sql_common_chunks_ts.commonStringChunks[", "])}`;
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset} rows`;
		const fetchSql = fetch === void 0 ? void 0 : __sql_sql_ts.sql` fetch next ${fetch} rows only`;
		let forSQL;
		if (_for && _for.mode === "json") forSQL = __sql_sql_ts.sql` for json ${new __sql_common_chunks_ts.StringChunk(_for.type)}${_for.options?.root ? __sql_sql_ts.sql` root(${__sql_sql_ts.sql.identifier(_for.options.root)})` : void 0}${_for.options?.includeNullValues ? __sql_sql_ts.sql` include_null_values` : void 0}${_for.options?.withoutArrayWrapper ? __sql_sql_ts.sql` without_array_wrapper` : void 0}`;
		const finalQuery = __sql_sql_ts.sql`${withSql}select${distinctSql}${topSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${offsetSql}${fetchSql}${forSQL}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		for (let i = 0; i < setOperators.length; ++i) leftSelect = this.buildSetOperationQuery({
			leftSelect,
			setOperator: setOperators[i]
		});
		return leftSelect;
	}
	buildSetOperationTail({ orderBy, offset, fetch }) {
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const orderByUnit of orderBy) if ((0, __entity_ts.is)(orderByUnit, require_mssql_core_columns_common.MsSqlColumn)) orderByValues.push(__sql_sql_ts.sql.identifier(orderByUnit.name));
			else if ((0, __entity_ts.is)(orderByUnit, __sql_sql_ts.SQL)) orderByValues.push(__sql_sql_ts.sql`${(0, __sql_sql_ts.unqualifyColumns)(orderByUnit)}`);
			else orderByValues.push(__sql_sql_ts.sql`${orderByUnit}`);
			orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByValues, __sql_common_chunks_ts.commonStringChunks[", "])}`;
		}
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset} rows`;
		const fetchSql = fetch === void 0 ? void 0 : __sql_sql_ts.sql` fetch next ${fetch} rows only`;
		if (orderBySql === void 0 && offsetSql === void 0 && fetchSql === void 0) return void 0;
		return __sql_sql_ts.sql`${orderBySql}${offsetSql}${fetchSql}`;
	}
	buildSetOperationQuery({ leftSelect, setOperator }) {
		const { type, isAll, rightSelect } = setOperator;
		const leftChunk = __sql_sql_ts.sql`(${leftSelect.getSQL()}) `;
		const rightChunk = __sql_sql_ts.sql`(${rightSelect.getSQL()})`;
		const operatorChunk = new __sql_common_chunks_ts.StringChunk(`${type} ${isAll ? "all " : ""}`);
		const tailSql = this.buildSetOperationTail(setOperator);
		return __sql_sql_ts.sql`${leftChunk}${operatorChunk}${rightChunk}${tailSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, output, columnList, select }) {
		const columns = table[__table_ts.Table.Symbol.Columns];
		const colEntries = select && !(0, __entity_ts.is)(valuesOrSelect, __sql_sql_ts.SQL) ? Object.keys(valuesOrSelect.getSelectedFields()).map((key) => [key, columns[key]]) : columnList ? columnList.map((name) => [name, columns[name]]) : Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		if (colEntries.length === 0 && !select && valuesOrSelect.length > 1) throw new require_errors.DrizzleError({ message: `Cannot insert ${valuesOrSelect.length} rows into "${table[__table_ts.Table.Symbol.Name]}": it has no insertable columns, so only a single all-defaults row can be inserted per statement` });
		const insertOrderArr = new Array(colEntries.length * 2 + 1);
		let orderWriteIdx = 0;
		insertOrderArr[orderWriteIdx++] = __sql_common_chunks_ts.commonStringChunks["("];
		for (let i = 0; i < colEntries.length; ++i) {
			const [, { name }] = colEntries[i];
			insertOrderArr[orderWriteIdx++] = __sql_sql_ts.sql.identifier(name);
			if (i < colEntries.length - 1) insertOrderArr[orderWriteIdx++] = __sql_common_chunks_ts.commonStringChunks[", "];
		}
		insertOrderArr[orderWriteIdx++] = __sql_common_chunks_ts.commonStringChunks[")"];
		const insertOrder = new __sql_sql_ts.SQL(insertOrderArr);
		let valuesSqlList;
		if (select) valuesSqlList = [valuesOrSelect.getSQL()];
		else {
			const values = valuesOrSelect;
			const cells = new Array(values.length * colEntries.length);
			let writeIdx = 0;
			for (let valueIndex = 0; valueIndex < values.length; ++valueIndex) {
				const value = values[valueIndex];
				for (let i = 0; i < colEntries.length; ++i) {
					const [fieldName, col] = colEntries[i];
					const colValue = value[fieldName];
					if (colValue === void 0) {
						if (col.defaultFn !== void 0) cells[writeIdx++] = col.defaultFn();
						else if (!col.default && col.onUpdateFn !== void 0) cells[writeIdx++] = col.onUpdateFn();
						else cells[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["default"];
					} else cells[writeIdx++] = colValue;
				}
			}
			valuesSqlList = [new __sql_sql_ts.ValueRows(cells, colEntries.map(([, col]) => col))];
		}
		const outputSql = output ? __sql_sql_ts.sql` output ${this.buildSelectionOutput(output, { type: "INSERTED" })}` : void 0;
		if (select) return __sql_sql_ts.sql`insert into ${table} ${insertOrder}${outputSql} ${new __sql_sql_ts.SQL(valuesSqlList)}`;
		if (colEntries.length === 0) return __sql_sql_ts.sql`insert into ${table}${outputSql} default values`;
		return __sql_sql_ts.sql`insert into ${table} ${insertOrder}${outputSql} values ${new __sql_sql_ts.SQL(valuesSqlList)}`;
	}
	sqlToQuery(sql, invokeSource) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			codecs: this.codecs,
			invokeSource
		});
	}
	buildRelationalQuery(config) {
		const chunks = [];
		const selection = this.collectRelationalQuery(config, chunks);
		return {
			sql: new __sql_sql_ts.SQL(chunks),
			selection
		};
	}
	collectRelationalQuery({ schema, table, tableConfig, queryConfig: config, relationWhere, mode, errorPath, depth, through, nested, withSubqueries, strategy }, collectTo) {
		const selection = [];
		const isSingle = mode === "first";
		const params = config === true ? void 0 : config;
		const currentPath = errorPath ?? "";
		const currentDepth = depth ?? 0;
		const isOptimized = (currentDepth ? strategy : params?.strategy) !== "basic";
		const collector = withSubqueries ?? { subqueries: /* @__PURE__ */ new Map() };
		if (!currentDepth) {
			(0, __relations_ts.collectSubquery)(collector, table);
			table = (0, __alias_ts.aliasedTable)(table, `d${currentDepth}`);
		}
		const tableRef = table[__table_ts.Qualifier];
		const limit = isSingle ? 1 : params?.limit;
		const offset = params?.offset;
		const { sql: where } = (0, __relations_ts.relationalQueryWhereToSQL)(table, params, tableConfig.relations, schema, collector, relationWhere);
		const order = params?.orderBy ? (0, __relations_ts.relationsOrderToSQL)(table, params.orderBy, tableConfig.relations, schema, collector, "top") : void 0;
		if (offset !== void 0 && !order) throw new require_errors.DrizzleError({ message: `Table "${tableConfig.name}"${currentPath ? ` ("${currentPath}")` : ""} uses "offset" without "orderBy". SQL Server only accepts "offset" as part of an "order by" clause.` });
		const withParam = params ? params.with : void 0;
		const withKeys = [];
		if (withParam) {
			for (const key of Object.keys(withParam)) if (withParam[key]) withKeys.push(key);
		}
		const useOffset = offset !== void 0;
		const withIdx = currentDepth ? -1 : collectTo.length;
		if (!currentDepth) collectTo.push(void 0);
		collectTo.push(rqbChunks.select);
		if (!useOffset && limit !== void 0) collectTo.push(rqbChunks.top, limit, __sql_common_chunks_ts.commonStringChunks[")"]);
		collectTo.push(__sql_common_chunks_ts.commonStringChunks[" "]);
		let selected = (0, __relations_ts.buildRqbColumns)(tableRef, tableConfig.table[__table_ts.TableColumns], selection, !!nested, tableConfig.name, this.codecs, collectTo, params?.columns) ? 1 : 0;
		if (params?.extras) {
			const mark = collectTo.length;
			if (selected) collectTo.push(__sql_common_chunks_ts.commonStringChunks[", "]);
			const extras = (0, __relations_ts.relationExtrasToSQL)(table, params.extras, this.codecs, nested, collectTo);
			selection.push(...extras.selection);
			if (extras.sql) ++selected;
			else collectTo.length = mark;
		}
		const applyAliases = new Array(withKeys.length);
		for (let i = 0; i < withKeys.length; ++i) {
			const k = withKeys[i];
			const relation = tableConfig.relations[k];
			if (!relation) throw new require_errors.DrizzleError({ message: `Unknown relation "${tableConfig.name}" -> "${k}"` });
			const applyAlias = applyAliases[i] = __sql_sql_ts.sql.identifier(`r${currentDepth}_${i}`);
			if (selected++) collectTo.push(__sql_common_chunks_ts.commonStringChunks[", "]);
			collectTo.push(relation.relationType === "one" ? nested ? rqbChunks.jsonQueryOpen : void 0 : nested ? rqbChunks.jsonQueryCoalesceOpen : rqbChunks.coalesceOpen, applyAlias, relation.relationType === "one" ? nested ? rqbChunks.jsonOneNestedClose : rqbChunks.jsonOneClose : nested ? rqbChunks.jsonManyNestedClose : rqbChunks.jsonManyClose, __sql_sql_ts.sql.identifier(k));
		}
		if (!selected) throw new require_errors.DrizzleError({ message: `No fields selected for table "${tableConfig.name}"${currentPath ? ` ("${currentPath}")` : ""}` });
		const isWrapped = withKeys.length > 0 && isOptimized && useOffset;
		collectTo.push(__sql_common_chunks_ts.commonStringChunks[" from "]);
		if (isWrapped) collectTo.push(__sql_common_chunks_ts.commonStringChunks["(select "], tableRef, __sql_common_chunks_ts.commonStringChunks[".* from "]);
		(0, __relations_ts.getTableAsAliasSQL)(table, collectTo);
		if (through) {
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[" inner join "]);
			(0, __relations_ts.getTableAsAliasSQL)(through.table, collectTo);
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[" on "], ...through.condition);
		}
		if (isWrapped) {
			if (where) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" where "], ...where);
			if (order) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" order by "], ...order);
			collectTo.push(rqbChunks.offset, offset, rqbChunks.rows);
			if (limit !== void 0) collectTo.push(rqbChunks.fetchNext, limit, rqbChunks.rowsOnly);
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[") as "], tableRef);
		}
		for (let i = 0; i < withKeys.length; ++i) {
			const k = withKeys[i];
			const join = withParam[k];
			const relation = tableConfig.relations[k];
			const isSingle = relation.relationType === "one";
			(0, __relations_ts.collectSubquery)(collector, relation.targetTable);
			(0, __relations_ts.collectSubquery)(collector, relation.throughTable);
			const targetTable = (0, __alias_ts.aliasedTable)(relation.targetTable, `d${currentDepth + 1}`);
			const throughTable = relation.throughTable ? (0, __alias_ts.aliasedTable)(relation.throughTable, `tr${currentDepth}`) : void 0;
			const { filter, joinCondition } = (0, __relations_ts.relationToSQL)(relation, table, targetTable, throughTable);
			collectTo.push(rqbChunks.applyOpen);
			const innerSelection = this.collectRelationalQuery({
				table: targetTable,
				mode: isSingle ? "first" : "many",
				schema,
				queryConfig: join,
				tableConfig: schema[relation.targetTableName],
				relationWhere: filter,
				errorPath: `${currentPath.length ? `${currentPath}.` : ""}${k}`,
				depth: currentDepth + 1,
				withSubqueries: collector,
				strategy: currentDepth ? strategy : params?.strategy,
				through: throughTable ? {
					table: throughTable,
					condition: joinCondition
				} : void 0,
				nested: true
			}, collectTo);
			collectTo.push(isSingle ? rqbChunks.forJsonOne : rqbChunks.forJsonMany, applyAliases[i], rqbChunks.applyColumn);
			selection.push({
				field: targetTable,
				fieldType: "Nested",
				key: k,
				selection: innerSelection,
				isArray: !isSingle,
				isOptional: (relation.optional ?? false) || join !== true && !!join.where
			});
		}
		if (isWrapped) {
			if (order) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" order by "], ...order);
		} else {
			if (where) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" where "], ...where);
			if (order) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" order by "], ...order);
			if (useOffset) {
				collectTo.push(rqbChunks.offset, offset, rqbChunks.rows);
				if (limit !== void 0) collectTo.push(rqbChunks.fetchNext, limit, rqbChunks.rowsOnly);
			}
		}
		if (withIdx !== -1) collectTo[withIdx] = this.buildWithCTE([...collector.subqueries.values()]);
		return selection;
	}
};
//#endregion
exports.MsSqlDialect = MsSqlDialect;

//# sourceMappingURL=dialect.cjs.map