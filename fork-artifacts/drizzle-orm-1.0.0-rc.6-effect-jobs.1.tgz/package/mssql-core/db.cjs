Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mssql_core_query_builders_select = require("./query-builders/select.cjs");
const require_mssql_core_query_builders_query_builder = require("./query-builders/query-builder.cjs");
const require_mssql_core_query_builders_count = require("./query-builders/count.cjs");
const require_mssql_core_query_builders_delete = require("./query-builders/delete.cjs");
const require_mssql_core_query_builders_insert = require("./query-builders/insert.cjs");
const require_mssql_core_query_builders_update = require("./query-builders/update.cjs");
const require_mssql_core_query_builders_query = require("./query-builders/query.cjs");
let __entity_ts = require("../entity.cjs");
let __subquery_ts = require("../subquery.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __selection_proxy_ts = require("../selection-proxy.cjs");
//#region src/mssql-core/db.ts
var MsSqlDatabase = class {
	dialect;
	session;
	static [__entity_ts.entityKind] = "MsSqlDatabase";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	query;
	constructor(dialect, session, relations) {
		this.dialect = dialect;
		this.session = session;
		this._ = {
			relations,
			session
		};
		this.query = {};
		for (const [tableName, relation] of Object.entries(relations)) this.query[tableName] = new require_mssql_core_query_builders_query.RelationalQueryBuilder(relations, relations[relation.name].table, relation, dialect, session);
	}
	/**
	* Creates a subquery that defines a temporary named result set as a CTE.
	*
	* It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param alias The alias for the subquery.
	*
	* Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
	*
	* @example
	*
	* ```ts
	* // Create a subquery with alias 'sq' and use it in the select query
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* const result = await db.with(sq).select().from(sq);
	* ```
	*
	* To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
	*
	* ```ts
	* // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
	* const sq = db.$with('sq').as(db.select({
	*   name: sql<string>`upper(${users.name})`.as('name'),
	* })
	* .from(users));
	*
	* const result = await db.with(sq).select({ name: sq.name }).from(sq);
	* ```
	*/
	$with(alias) {
		const self = this;
		return { as(qb) {
			if (typeof qb === "function") qb = qb(new require_mssql_core_query_builders_query_builder.QueryBuilder(self.dialect));
			return new Proxy(new __subquery_ts.WithSubquery(qb.getSQL(), qb.getSelectedFields(), alias, true), new __selection_proxy_ts.SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		} };
	}
	$count(source, filters) {
		return new require_mssql_core_query_builders_count.MsSqlCountBuilder({
			source,
			filters,
			session: this.session,
			dialect: this.dialect
		});
	}
	/**
	* Incorporates a previously defined CTE (using `$with`) into the main query.
	*
	* This method allows the main query to reference a temporary named result set.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param queries The CTEs to incorporate into the main query.
	*
	* @example
	*
	* ```ts
	* // Define a subquery 'sq' as a CTE using $with
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* // Incorporate the CTE 'sq' into the main query and select from it
	* const result = await db.with(sq).select().from(sq);
	* ```
	*/
	with(...queries) {
		const self = this;
		function select(fields) {
			return new require_mssql_core_query_builders_select.MsSqlSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries
			});
		}
		function selectDistinct(fields) {
			return new require_mssql_core_query_builders_select.MsSqlSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries,
				distinct: true
			});
		}
		return {
			select,
			selectDistinct
		};
	}
	select(fields) {
		return new require_mssql_core_query_builders_select.MsSqlSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect
		});
	}
	selectDistinct(fields) {
		return new require_mssql_core_query_builders_select.MsSqlSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect,
			distinct: true
		});
	}
	/**
	* Creates an update query.
	*
	* Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
	*
	* Use `.set()` method to specify which values to update.
	*
	* See docs: {@link https://orm.drizzle.team/docs/update}
	*
	* @param table The table to update.
	*
	* @example
	*
	* ```ts
	* // Update all rows in the 'cars' table
	* await db.update(cars).set({ color: 'red' });
	*
	* // Update rows with filters and conditions
	* await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
	* ```
	*/
	update(table) {
		return new require_mssql_core_query_builders_update.MsSqlUpdateBuilder(table, this.session, this.dialect);
	}
	insert(table, ...columns) {
		return new require_mssql_core_query_builders_insert.MsSqlInsertBuilder(table, this.session, this.dialect, void 0, columns.length ? columns : void 0);
	}
	/**
	* Creates a delete query.
	*
	* Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param table The table to delete from.
	*
	* @example
	*
	* ```ts
	* // Delete all rows in the 'cars' table
	* await db.delete(cars);
	*
	* // Delete rows with filters and conditions
	* await db.delete(cars).where(eq(cars.color, 'green'));
	* ```
	*/
	delete(table) {
		return new require_mssql_core_query_builders_delete.MsSqlDeleteBase(table, this.session, this.dialect);
	}
	execute(query, mode) {
		const sequel = (typeof query === "string" ? __sql_sql_ts.sql.raw(query) : query).getSQL();
		return this.session.prepareQuery(this.dialect.sqlToQuery(sequel), mode ?? "raw").execute();
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.MsSqlDatabase = MsSqlDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map