Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
//#region src/mssql-core/query-builders/count.ts
var MsSqlCountBuilder = class MsSqlCountBuilder extends __sql_sql_ts.SQL {
	countConfig;
	static [__entity_ts.entityKind] = "MsSqlCountBuilder";
	dialect;
	session;
	static buildCount(source, filters, parens) {
		const where = __sql_sql_ts.sql` where ${filters}`.if(filters);
		const query = __sql_sql_ts.sql`select count(*) from ${source}${where}`;
		return parens ? __sql_sql_ts.sql`(${query})` : query;
	}
	constructor(countConfig) {
		super(MsSqlCountBuilder.buildCount(countConfig.source, countConfig.filters, true).queryChunks);
		this.countConfig = countConfig;
		this.dialect = countConfig.dialect;
		this.session = countConfig.session;
		this.mapWith((e) => {
			if (typeof e === "number") return e;
			return Number(e ?? 0);
		});
	}
	executableSql;
	build() {
		if (!this.executableSql) {
			const { source, filters } = this.countConfig;
			this.executableSql = MsSqlCountBuilder.buildCount(source, filters);
		}
		return this.dialect.sqlToQuery(this.executableSql);
	}
	execute(placeholderValues) {
		return this.session.prepareQuery(this.build(), "arrays", (rows) => {
			const v = rows[0]?.[0];
			if (typeof v === "number") return v;
			return v ? Number(v) : 0;
		}).execute(placeholderValues);
	}
};
(0, __utils_ts.applyMixins)(MsSqlCountBuilder, [__query_promise_ts.QueryPromise]);
//#endregion
exports.MsSqlCountBuilder = MsSqlCountBuilder;

//# sourceMappingURL=count.cjs.map