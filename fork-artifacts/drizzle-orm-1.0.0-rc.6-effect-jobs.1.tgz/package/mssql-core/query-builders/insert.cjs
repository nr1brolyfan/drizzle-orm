Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mssql_core_query_builders_query_builder = require("./query-builder.cjs");
let __entity_ts = require("../../entity.cjs");
let __table_ts = require("../../table.cjs");
let __utils_ts = require("../../utils.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
//#region src/mssql-core/query-builders/insert.ts
var MsSqlInsertBuilder = class {
	static [__entity_ts.entityKind] = "MsSqlInsertBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	config;
	table;
	session;
	dialect;
	constructor(table, session, dialect, output, columnList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			output,
			columnList
		};
	}
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		return new MsSqlInsertBase(this.table, values, this.session, this.dialect, this.config.output, this.config.columnList);
	}
	select(selectQuery) {
		const select = typeof selectQuery === "function" ? selectQuery(new require_mssql_core_query_builders_query_builder.QueryBuilder()) : selectQuery;
		if (!(0, __entity_ts.is)(select, __sql_sql_ts.SQL)) {
			const insertCols = Object.keys(this.table[__table_ts.Table.Symbol.Columns]);
			const selected = Object.keys(select._.selectedFields);
			for (const col of selected) if (!insertCols.includes(col)) throw new Error(`Insert select error: column "${col}" does not exist in table "${this.table[__table_ts.Table.Symbol.Name]}"`);
		}
		return new MsSqlInsertBase(this.table, select, this.session, this.dialect, this.config.output, this.config.columnList, true);
	}
	output(fields = this.table[__table_ts.Table.Symbol.Columns]) {
		this.config.output = (0, __utils_ts.orderSelectedFields)(fields, void 0, this.dialect.codecs);
		return this;
	}
};
var MsSqlInsertBase = class extends __query_promise_ts.QueryPromise {
	session;
	dialect;
	static [__entity_ts.entityKind] = "MsSqlInsert";
	config;
	constructor(table, values, session, dialect, output, columnList, select) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			output,
			columnList,
			select
		};
	}
	getSQL() {
		return this.dialect.buildInsertQuery(this.config);
	}
	toSQL() {
		return this.dialect.sqlToQuery(this.getSQL());
	}
	prepare() {
		const fields = this.config.output;
		return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), fields ? "arrays" : "raw", fields ? this.dialect.mapperGenerators.rows(fields, void 0) : void 0);
	}
	execute(placeholderValues) {
		return this.prepare().execute(placeholderValues);
	}
	createIterator = () => {
		const self = this;
		return async function* (placeholderValues) {
			yield* self.prepare().iterator(placeholderValues);
		};
	};
	iterator = this.createIterator();
	$dynamic() {
		return this;
	}
};
//#endregion
exports.MsSqlInsertBase = MsSqlInsertBase;
exports.MsSqlInsertBuilder = MsSqlInsertBuilder;

//# sourceMappingURL=insert.cjs.map