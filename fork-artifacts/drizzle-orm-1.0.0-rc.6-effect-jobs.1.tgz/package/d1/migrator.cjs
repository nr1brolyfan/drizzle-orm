Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_ts = require("../migrator.cjs");
let __runtime_async_ts = require("../runtime/async.cjs");
let __up_migrations_sqlite_program_ts = require("../up-migrations/sqlite-program.cjs");
let __up_migrations_sqlite_ts = require("../up-migrations/sqlite.cjs");
//#region src/d1/migrator.ts
function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	const runner = (0, __up_migrations_sqlite_ts.sqliteAsyncMigrationRunner)(db, (statements) => db.session.batch(statements.map((statement) => db.run(statement.inlineParams()))));
	return (0, __runtime_async_ts.runAsyncProgram)(() => (0, __up_migrations_sqlite_program_ts.migrate)(migrations, runner, config));
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map