Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_d1_codecs = require("./codecs.cjs");
const require_d1_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __logger_ts = require("../logger.cjs");
let __sqlite_core_async_db_ts = require("../sqlite-core/async/db.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
//#region src/d1/driver.ts
var DrizzleD1Database = class extends __sqlite_core_async_db_ts.SQLiteAsyncDatabase {
	static [__entity_ts.entityKind] = "D1Database";
	/**
	* Executes multiple queries on database in one roundrtip
	*
	* D1 batch results are keyed by column's db name, thus every query
	* must alias columns with duplicate names to prevent data loss
	*
	* @example
	*
	* db.batch([
	* 	db.select({
	* 		userId: users.id.as('user_id'), // aliased to prevent user and post id from collapsing into same field in driver's response
	* 		postId: posts.id,
	* 		userName: users.name,
	* 		postContent: posts.content,
	* 		// ...
	* 	}).from(users).leftJoin(posts, eq(users.id, posts.id)),
	* 	// ...
	* ])
	*/
	async batch(batch) {
		return this.session.batch(batch);
	}
};
/**
* Driver quirks:
* - Integers past the safe integer range are read as numbers: `numeric` columns throw on them
*/
function drizzle(client, config = {}) {
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({ codecs: config.codecs ?? require_d1_codecs.d1Codecs });
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new DrizzleD1Database("async", dialect, new require_d1_session.SQLiteD1Session(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations, true);
	db.$client = client;
	return db;
}
//#endregion
exports.DrizzleD1Database = DrizzleD1Database;
exports.drizzle = drizzle;

//# sourceMappingURL=driver.cjs.map