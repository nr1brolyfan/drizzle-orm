Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sql_common_chunks = require("../common-chunks.cjs");
const require_sql_sql = require("../sql.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/sql/expressions/conditions.ts
function bindIfParam(value, column) {
	if (require_sql_sql.isDriverValueEncoder(column) && !require_sql_sql.isSQLWrapper(value)) {
		const kind = require_sql_sql.chunkKindOf(value);
		if (kind !== require_sql_sql.chunkKinds.param && kind !== require_sql_sql.chunkKinds.placeholder && kind !== require_sql_sql.chunkKinds.column && kind !== require_sql_sql.chunkKinds.table && kind !== require_sql_sql.chunkKinds.view) return new require_sql_sql.Param(value, column);
	}
	return value;
}
const checkColumnWithValue = (column, op, value) => new require_sql_sql.SQL([
	column,
	op,
	bindIfParam(value, column)
]);
/**
* Test that two values are equal.
*
* Remember that the SQL standard dictates that
* two NULL values are not equal, so if you want to test
* whether a value is null, you may want to use
* `isNull` instead.
*
* ## Examples
*
* ```ts
* // Select cars made by Ford
* db.select().from(cars)
*   .where(eq(cars.make, 'Ford'))
* ```
*
* @see isNull for a way to test equality to NULL.
*/
const eq = (left, right) => checkColumnWithValue(left, require_sql_common_chunks.commonStringChunks[" = "], right);
/**
* Test that two values are not equal.
*
* Remember that the SQL standard dictates that
* two NULL values are not equal, so if you want to test
* whether a value is not null, you may want to use
* `isNotNull` instead.
*
* ## Examples
*
* ```ts
* // Select cars not made by Ford
* db.select().from(cars)
*   .where(ne(cars.make, 'Ford'))
* ```
*
* @see isNotNull for a way to test whether a value is not null.
*/
const ne = (left, right) => checkColumnWithValue(left, require_sql_common_chunks.commonStringChunks[" <> "], right);
const joinConditions = (conditions, separatorWithParenChunk) => {
	const chunks = new Array(conditions.length * 2 + 1), lastIdx = conditions.length - 1;
	chunks[0] = require_sql_common_chunks.commonStringChunks["(("];
	for (let i = 0; i < lastIdx; i++) {
		chunks[i * 2 + 1] = conditions[i];
		chunks[i * 2 + 2] = separatorWithParenChunk;
	}
	chunks[lastIdx * 2 + 1] = conditions[lastIdx];
	chunks[lastIdx * 2 + 2] = require_sql_common_chunks.commonStringChunks["))"];
	return new require_sql_sql.SQL(chunks);
};
function and(...unfilteredConditions) {
	const conditions = unfilteredConditions.filter((c) => c !== void 0);
	if (conditions.length === 0) return;
	if (conditions.length === 1) return new require_sql_sql.SQL(conditions);
	return joinConditions(conditions, require_sql_common_chunks.commonStringChunks[") and ("]);
}
function or(...unfilteredConditions) {
	const conditions = unfilteredConditions.filter((c) => c !== void 0);
	if (conditions.length === 0) return;
	if (conditions.length === 1) return new require_sql_sql.SQL(conditions);
	return joinConditions(conditions, require_sql_common_chunks.commonStringChunks[") or ("]);
}
function not(condition) {
	if (!condition) return void 0;
	return (0, __entity_ts.is)(condition, require_sql_sql.SQL) ? require_sql_sql.sql`not (${condition})` : require_sql_sql.sql`not ${condition}`;
}
/**
* Test that the first expression passed is greater than
* the second expression.
*
* ## Examples
*
* ```ts
* // Select cars made after 2000.
* db.select().from(cars)
*   .where(gt(cars.year, 2000))
* ```
*
* @see gte for greater-than-or-equal
*/
const gt = (left, right) => checkColumnWithValue(left, require_sql_common_chunks.commonStringChunks[" > "], right);
/**
* Test that the first expression passed is greater than
* or equal to the second expression. Use `gt` to
* test whether an expression is strictly greater
* than another.
*
* ## Examples
*
* ```ts
* // Select cars made on or after 2000.
* db.select().from(cars)
*   .where(gte(cars.year, 2000))
* ```
*
* @see gt for a strictly greater-than condition
*/
const gte = (left, right) => checkColumnWithValue(left, require_sql_common_chunks.commonStringChunks[" >= "], right);
/**
* Test that the first expression passed is less than
* the second expression.
*
* ## Examples
*
* ```ts
* // Select cars made before 2000.
* db.select().from(cars)
*   .where(lt(cars.year, 2000))
* ```
*
* @see lte for less-than-or-equal
*/
const lt = (left, right) => checkColumnWithValue(left, require_sql_common_chunks.commonStringChunks[" < "], right);
/**
* Test that the first expression passed is less than
* or equal to the second expression.
*
* ## Examples
*
* ```ts
* // Select cars made before 2000.
* db.select().from(cars)
*   .where(lte(cars.year, 2000))
* ```
*
* @see lt for a strictly less-than condition
*/
const lte = (left, right) => checkColumnWithValue(left, require_sql_common_chunks.commonStringChunks[" <= "], right);
function inArray(column, values) {
	if (Array.isArray(values)) {
		if (values.length === 0) return new require_sql_sql.SQL([require_sql_common_chunks.commonStringChunks["1 = 0"]]);
		return new require_sql_sql.SQL([
			column,
			require_sql_common_chunks.commonStringChunks[" in "],
			values.map((v) => bindIfParam(v, column))
		]);
	}
	return checkColumnWithValue(column, require_sql_common_chunks.commonStringChunks[" in "], values);
}
function notInArray(column, values) {
	if (Array.isArray(values)) {
		if (values.length === 0) return new require_sql_sql.SQL([require_sql_common_chunks.commonStringChunks["1 = 1"]]);
		return new require_sql_sql.SQL([
			column,
			require_sql_common_chunks.commonStringChunks[" not in "],
			values.map((v) => bindIfParam(v, column))
		]);
	}
	return checkColumnWithValue(column, require_sql_common_chunks.commonStringChunks[" not in "], values);
}
/**
* Test whether an expression is NULL. By the SQL standard,
* NULL is neither equal nor not equal to itself, so
* it's recommended to use `isNull` and `notIsNull` for
* comparisons to NULL.
*
* ## Examples
*
* ```ts
* // Select cars that have no discontinuedAt date.
* db.select().from(cars)
*   .where(isNull(cars.discontinuedAt))
* ```
*
* @see isNotNull for the inverse of this test
*/
function isNull(value) {
	return require_sql_sql.sql`(${value} is null)`;
}
/**
* Test whether an expression is not NULL. By the SQL standard,
* NULL is neither equal nor not equal to itself, so
* it's recommended to use `isNull` and `notIsNull` for
* comparisons to NULL.
*
* ## Examples
*
* ```ts
* // Select cars that have been discontinued.
* db.select().from(cars)
*   .where(isNotNull(cars.discontinuedAt))
* ```
*
* @see isNull for the inverse of this test
*/
function isNotNull(value) {
	return require_sql_sql.sql`(${value} is not null)`;
}
/**
* Test whether a subquery evaluates to have any rows.
*
* ## Examples
*
* ```ts
* // Users whose `homeCity` column has a match in a cities
* // table.
* db
*   .select()
*   .from(users)
*   .where(
*     exists(db.select()
*       .from(cities)
*       .where(eq(users.homeCity, cities.id))),
*   );
* ```
*
* @see notExists for the inverse of this test
*/
function exists(subquery) {
	return require_sql_sql.sql`exists ${subquery}`;
}
/**
* Test whether a subquery doesn't include any result
* rows.
*
* ## Examples
*
* ```ts
* // Users whose `homeCity` column doesn't match
* // a row in the cities table.
* db
*   .select()
*   .from(users)
*   .where(
*     notExists(db.select()
*       .from(cities)
*       .where(eq(users.homeCity, cities.id))),
*   );
* ```
*
* @see exists for the inverse of this test
*/
function notExists(subquery) {
	return require_sql_sql.sql`not exists ${subquery}`;
}
function between(column, min, max) {
	return require_sql_sql.sql`${column} between ${bindIfParam(min, column)} and ${bindIfParam(max, column)}`;
}
function notBetween(column, min, max) {
	return require_sql_sql.sql`${column} not between ${bindIfParam(min, column)} and ${bindIfParam(max, column)}`;
}
/**
* Compare a column to a pattern, which can include `%` and `_`
* characters to match multiple variations. Including `%`
* in the pattern matches zero or more characters, and including
* `_` will match a single character.
*
* ## Examples
*
* ```ts
* // Select all cars with 'Turbo' in their names.
* db.select().from(cars)
*   .where(like(cars.name, '%Turbo%'))
* ```
*
* @see ilike for a case-insensitive version of this condition
*/
function like(column, value) {
	return require_sql_sql.sql`${column} like ${value}`;
}
/**
* The inverse of like - this tests that a given column
* does not match a pattern, which can include `%` and `_`
* characters to match multiple variations. Including `%`
* in the pattern matches zero or more characters, and including
* `_` will match a single character.
*
* ## Examples
*
* ```ts
* // Select all cars that don't have "ROver" in their name.
* db.select().from(cars)
*   .where(notLike(cars.name, '%Rover%'))
* ```
*
* @see like for the inverse condition
* @see notIlike for a case-insensitive version of this condition
*/
function notLike(column, value) {
	return require_sql_sql.sql`${column} not like ${value}`;
}
/**
* Case-insensitively compare a column to a pattern,
* which can include `%` and `_`
* characters to match multiple variations. Including `%`
* in the pattern matches zero or more characters, and including
* `_` will match a single character.
*
* Unlike like, this performs a case-insensitive comparison.
*
* ## Examples
*
* ```ts
* // Select all cars with 'Turbo' in their names.
* db.select().from(cars)
*   .where(ilike(cars.name, '%Turbo%'))
* ```
*
* @see like for a case-sensitive version of this condition
*/
function ilike(column, value) {
	return require_sql_sql.sql`${column} ilike ${value}`;
}
/**
* The inverse of ilike - this case-insensitively tests that a given column
* does not match a pattern, which can include `%` and `_`
* characters to match multiple variations. Including `%`
* in the pattern matches zero or more characters, and including
* `_` will match a single character.
*
* ## Examples
*
* ```ts
* // Select all cars that don't have "Rover" in their name.
* db.select().from(cars)
*   .where(notLike(cars.name, '%Rover%'))
* ```
*
* @see ilike for the inverse condition
* @see notLike for a case-sensitive version of this condition
*/
function notIlike(column, value) {
	return require_sql_sql.sql`${column} not ilike ${value}`;
}
function arrayContains(column, values) {
	if (Array.isArray(values)) {
		if (values.length === 0) throw new Error("arrayContains requires at least one value");
		const par = bindIfParam(values, column);
		const array = require_sql_sql.sql`${Array.isArray(par) ? new require_sql_sql.Param(par) : par}`;
		return require_sql_sql.sql`${column} @> ${array}`;
	}
	return require_sql_sql.sql`${column} @> ${bindIfParam(values, column)}`;
}
function arrayContained(column, values) {
	if (Array.isArray(values)) {
		if (values.length === 0) throw new Error("arrayContained requires at least one value");
		const par = bindIfParam(values, column);
		const array = require_sql_sql.sql`${Array.isArray(par) ? new require_sql_sql.Param(par) : par}`;
		return require_sql_sql.sql`${column} <@ ${array}`;
	}
	return require_sql_sql.sql`${column} <@ ${bindIfParam(values, column)}`;
}
function arrayOverlaps(column, values) {
	if (Array.isArray(values)) {
		if (values.length === 0) throw new Error("arrayOverlaps requires at least one value");
		const par = bindIfParam(values, column);
		const array = require_sql_sql.sql`${Array.isArray(par) ? new require_sql_sql.Param(par) : par}`;
		return require_sql_sql.sql`${column} && ${array}`;
	}
	return require_sql_sql.sql`${column} && ${bindIfParam(values, column)}`;
}
//#endregion
exports.and = and;
exports.arrayContained = arrayContained;
exports.arrayContains = arrayContains;
exports.arrayOverlaps = arrayOverlaps;
exports.between = between;
exports.bindIfParam = bindIfParam;
exports.eq = eq;
exports.exists = exists;
exports.gt = gt;
exports.gte = gte;
exports.ilike = ilike;
exports.inArray = inArray;
exports.isNotNull = isNotNull;
exports.isNull = isNull;
exports.like = like;
exports.lt = lt;
exports.lte = lte;
exports.ne = ne;
exports.not = not;
exports.notBetween = notBetween;
exports.notExists = notExists;
exports.notIlike = notIlike;
exports.notInArray = notInArray;
exports.notLike = notLike;
exports.or = or;

//# sourceMappingURL=conditions.cjs.map