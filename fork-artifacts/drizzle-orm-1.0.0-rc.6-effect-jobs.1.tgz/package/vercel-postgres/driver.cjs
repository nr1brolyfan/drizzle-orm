Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_vercel_postgres_codecs = require("./codecs.cjs");
const require_vercel_postgres_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __pg_core_dialect_ts = require("../pg-core/dialect.cjs");
let __logger_ts = require("../logger.cjs");
let __pg_core_async_db_ts = require("../pg-core/async/db.cjs");
let _vercel_postgres = require("@vercel/postgres");
//#region src/vercel-postgres/driver.ts
var VercelPgDatabase = class extends __pg_core_async_db_ts.PgAsyncDatabase {
	static [__entity_ts.entityKind] = "VercelPgDatabase";
};
function construct(client, config = {}) {
	const dialect = new __pg_core_dialect_ts.PgDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_vercel_postgres_codecs.vercelPgCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new VercelPgDatabase(dialect, new require_vercel_postgres_session.VercelPgSession(client, dialect, relations ?? {}, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
/**
* Requirements:
* - Sessions must use the ISO `DateStyle` (the default): temporal values of other `DateStyle`s throw
*/
function drizzle(...params) {
	if ((0, __utils_ts.isConfig)(params[0])) {
		const { client, ...DrizzlePgConfig } = params[0];
		return construct(client ?? _vercel_postgres.sql, DrizzlePgConfig);
	}
	return construct(params[0] ?? _vercel_postgres.sql, params[1]);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.VercelPgDatabase = VercelPgDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map