Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __codecs_ts = require("../codecs.cjs");
let __mssql_core_codecs_ts = require("../mssql-core/codecs.cjs");
//#region src/node-mssql/codecs.ts
const driver = "mssql";
const decimalReason = "the driver decodes `decimal`, `numeric` values to numbers, losing precision, and has no option to return them as text; use `mode: 'number'`";
const nodeMssqlCodecs = (0, __mssql_core_codecs_ts.refineGenericMsSqlCodecs)({
	bigint: { normalize: BigInt },
	"bigint:number": { normalize: Number },
	decimal: { normalize: (0, __codecs_ts.unsupportedCodec)("decimal", driver, decimalReason) },
	"decimal:number": { normalize: Number },
	"decimal:bigint": { normalize: (0, __codecs_ts.bigintFromIntegerValue)("decimal", driver) },
	numeric: { normalize: (0, __codecs_ts.unsupportedCodec)("numeric", driver, decimalReason) },
	"numeric:number": { normalize: Number },
	"numeric:bigint": { normalize: (0, __codecs_ts.bigintFromIntegerValue)("numeric", driver) }
});
//#endregion
exports.nodeMssqlCodecs = nodeMssqlCodecs;

//# sourceMappingURL=codecs.cjs.map