Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_node_mssql_codecs = require("./codecs.cjs");
const require_node_mssql_pool = require("./pool.cjs");
const require_node_mssql_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __mssql_core_dialect_ts = require("../mssql-core/dialect.cjs");
let __mssql_core_db_ts = require("../mssql-core/db.cjs");
//#region src/node-mssql/driver.ts
var NodeMsSqlDriver = class {
	client;
	dialect;
	options;
	static [__entity_ts.entityKind] = "NodeMsSqlDriver";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(client, dialect, options = {}) {
		this.client = client;
		this.dialect = dialect;
		this.options = options;
	}
	createSession(relations) {
		return new require_node_mssql_session.NodeMsSqlSession(this.client, this.dialect, relations, {
			logger: this.options.logger,
			paramsInErrors: this.options.paramsInErrors
		});
	}
};
function construct(client, config = {}) {
	const dialect = new __mssql_core_dialect_ts.MsSqlDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_node_mssql_codecs.nodeMssqlCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	if (isCallbackClient(client)) client = client.promise();
	const relations = config.relations ?? {};
	const session = new NodeMsSqlDriver(client, dialect, {
		logger,
		paramsInErrors: config.paramsInErrors
	}).createSession(relations);
	const db = new __mssql_core_db_ts.MsSqlDatabase(dialect, session, relations);
	db.$client = client;
	return db;
}
function getMsSqlConnectionParams(connectionString) {
	try {
		const url = new URL(connectionString);
		return {
			user: url.username,
			password: url.password,
			server: url.hostname,
			port: Number.parseInt(url.port, 10),
			database: url.pathname.replace(/^\//, ""),
			options: {
				encrypt: url.searchParams.get("encrypt") === "true",
				trustServerCertificate: url.searchParams.get("trustServerCertificate") === "true"
			}
		};
	} catch {
		return connectionString;
	}
}
/**
* Unsupported column types (throw on non-null values):
* - `decimal`, `numeric` in `string` mode (decoded to numbers, losing precision)
* - `decimal`, `numeric` in `bigint` mode: values past the safe integer range throw
*/
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(new require_node_mssql_pool.AutoPool(getMsSqlConnectionParams(params[0])), params[1]);
	const { connection, client, ...DrizzleMsSqlConfig } = params[0];
	if (client) return construct(client, DrizzleMsSqlConfig);
	return construct(typeof connection === "string" ? new require_node_mssql_pool.AutoPool(getMsSqlConnectionParams(connection)) : new require_node_mssql_pool.AutoPool(connection), DrizzleMsSqlConfig);
}
function isCallbackClient(client) {
	return typeof client.promise === "function";
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
Object.defineProperty(exports, "MsSqlDatabase", {
	enumerable: true,
	get: function() {
		return __mssql_core_db_ts.MsSqlDatabase;
	}
});
exports.NodeMsSqlDriver = NodeMsSqlDriver;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});
exports.getMsSqlConnectionParams = getMsSqlConnectionParams;

//# sourceMappingURL=driver.cjs.map