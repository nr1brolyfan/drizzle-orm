Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __sqlite_core_codecs_ts = require("../sqlite-core/codecs.cjs");
//#region src/better-sqlite3/codecs.ts
const betterSQLite3Codecs = (0, __sqlite_core_codecs_ts.refineSqliteCodecs)({
	integer: { normalize: Number },
	"integer:boolean": { normalize: __sqlite_core_codecs_ts.booleanFromInteger },
	"integer:timestamp": { normalize: __sqlite_core_codecs_ts.dateFromStoredSeconds },
	"integer:timestamp_ms": { normalize: __sqlite_core_codecs_ts.dateFromStoredMilliseconds },
	real: { normalize: Number },
	"text:json": { normalize: JSON.parse },
	"blob:json": { normalize: __sqlite_core_codecs_ts.jsonFromBlob },
	"blob:bigint": { normalize: __sqlite_core_codecs_ts.bigintFromBlob },
	numeric: { normalize: String },
	"numeric:number": { normalize: Number },
	"numeric:bigint": { normalize: BigInt }
});
//#endregion
exports.betterSQLite3Codecs = betterSQLite3Codecs;

//# sourceMappingURL=codecs.cjs.map