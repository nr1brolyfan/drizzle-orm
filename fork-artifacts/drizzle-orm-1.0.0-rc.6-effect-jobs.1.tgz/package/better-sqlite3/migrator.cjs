Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_ts = require("../migrator.cjs");
let __sqlite_core_async_session_ts = require("../sqlite-core/async/session.cjs");
//#region src/better-sqlite3/migrator.ts
function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	return (0, __sqlite_core_async_session_ts.migrateSync)(migrations, db.session, config);
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map