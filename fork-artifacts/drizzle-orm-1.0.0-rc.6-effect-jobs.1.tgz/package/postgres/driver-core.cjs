Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_codecs = require("./codecs.cjs");
const require_postgres_session = require("./session.cjs");
const require_postgres_shape = require("./shape.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __pg_core_dialect_ts = require("../pg-core/dialect.cjs");
let __logger_ts = require("../logger.cjs");
let __pg_core_async_db_ts = require("../pg-core/async/db.cjs");
//#region src/postgres/driver-core.ts
var PostgresDatabase = class extends __pg_core_async_db_ts.PgAsyncDatabase {
	static [__entity_ts.entityKind] = "PostgresDatabase";
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
	async batch(batch, options) {
		return this.session.batch(batch, options);
	}
	/**
	* Pipelines queries back-to-back on a single pooled connection, without a transaction
	*
	* Never throws because of a failing query
	*
	* Failing query does not stop or roll back the others
	*
	* Takes the same items as `batch`:
	*
	* ```ts
	* const getUser = db.select().from(users).where(eq(users.id, sql.placeholder('id'))).prepare('get_user');
	* const [alice, bob, inserted, allUsers] = await db.pipeline([
	*   getUser.bind({ id: 1 }),
	*   getUser.bind({ id: 2 }),
	*   db.insert(users).values({ name: 'John' }).returning(),
	*   db.select().from(users),
	* ]);
	* // each is `{ status: 'fulfilled', value }` or `{ status: 'rejected', reason }`
	* ```
	*/
	async pipeline(batch) {
		return this.session.pipeline(batch);
	}
	/**
	* Runs queries concurrently, fanned out across pooled connections, without a transaction
	*
	* Never throws because of a failing query
	*
	* Failing query does not stop or roll back the others
	*
	* Takes the same items as `batch`:
	*
	* ```ts
	* const getUser = db.select().from(users).where(eq(users.id, sql.placeholder('id'))).prepare('get_user');
	* const [alice, bob, inserted, allUsers] = await db.parallel([
	*   getUser.bind({ id: 1 }),
	*   getUser.bind({ id: 2 }),
	*   db.insert(users).values({ name: 'John' }).returning(),
	*   db.select().from(users),
	* ]);
	* // each is `{ status: 'fulfilled', value }` or `{ status: 'rejected', reason }`
	* ```
	*/
	async parallel(batch) {
		return this.session.parallel(batch);
	}
	/**
	* Inserts rows in bulk as multi-row `values` statements, filling `$defaultFn` / `$onUpdateFn` like `db.insert(...)`
	*
	* A cell a row leaves out gets the column's database default, and a column no row sets is left out of the statement
	*
	* Atomic by default: rows are split into chunks pipelined in one transaction - pass `atomic: false` to commit per chunk
	*
	* @example
	* ```ts
	* await db.bulkInsert(users, [{ name: 'John' }, { name: 'Jane' }]);
	* ```
	*/
	async bulkInsert(table, rows, options) {
		return this.session.bulkInsert(table, rows, options);
	}
	/**
	* Updates rows in bulk via driver-side `unnest`, matched by `by` key column(s), filling `$onUpdateFn` like `db.update(...)`
	*
	* Every row must set the same columns, except for the ones filled by `$onUpdateFn`
	*
	* Atomic by default: rows are split into chunks pipelined in one transaction - pass `atomic: false` to commit per chunk
	*
	* @example
	* ```ts
	* await db.bulkUpdate(users, [{ id: 1, name: 'John' }, { id: 2, name: 'Jane' }], { by: users.id });
	* ```
	*/
	async bulkUpdate(table, rows, options) {
		return this.session.bulkUpdate(table, rows, options);
	}
};
/** @internal */
function construct(client, config = {}) {
	const codecs = config.codecs ?? require_postgres_codecs.postgresCodecs;
	const dialect = new __pg_core_dialect_ts.PgDialect({
		codecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		shapeGenerator: require_postgres_shape.createShapeGenerator(codecs)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new PostgresDatabase(dialect, new require_postgres_session.PostgresSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
//#endregion
exports.PostgresDatabase = PostgresDatabase;
exports.construct = construct;

//# sourceMappingURL=driver-core.cjs.map