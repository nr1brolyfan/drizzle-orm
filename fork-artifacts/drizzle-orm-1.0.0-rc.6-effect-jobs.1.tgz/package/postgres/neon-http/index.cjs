Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_codecs = require("../codecs.cjs");
const require_postgres_shape = require("../shape.cjs");
const require_postgres_neon_http_session = require("./session.cjs");
const require_postgres_neon_http_driver = require("./driver.cjs");
exports.PostgresNeonHttpDatabase = require_postgres_neon_http_driver.PostgresNeonHttpDatabase;
exports.PostgresNeonHttpSession = require_postgres_neon_http_session.PostgresNeonHttpSession;
Object.defineProperty(exports, "buildShape", {
	enumerable: true,
	get: function() {
		return require_postgres_shape.buildShape;
	}
});
exports.createShapeGenerator = require_postgres_shape.createShapeGenerator;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return require_postgres_neon_http_driver.drizzle;
	}
});
exports.postgresCodecs = require_postgres_codecs.postgresCodecs;
var _postgres_neon_http = require("#postgres/neon-http");
Object.keys(_postgres_neon_http).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres_neon_http[k];
		}
	});
});
