Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_driver_core = require("./driver-core.cjs");
let _postgres_cf = require("#postgres/cf");
//#region src/postgres/cf.ts
function drizzle(...params) {
	if (typeof params[0] === "string") {
		const instance = (0, _postgres_cf.createPool)({ url: params[0] });
		return require_postgres_driver_core.construct(instance, params[1]);
	}
	const { connection, client, ...config } = params[0];
	if (client) return require_postgres_driver_core.construct(client, config);
	const instance = typeof connection === "string" ? (0, _postgres_cf.createPool)({ url: connection }) : (0, _postgres_cf.createPool)(connection);
	return require_postgres_driver_core.construct(instance, config);
}
(function(_drizzle) {
	function mock(config) {
		return require_postgres_driver_core.construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});
Object.keys(_postgres_cf).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres_cf[k];
		}
	});
});

//# sourceMappingURL=cf.cjs.map