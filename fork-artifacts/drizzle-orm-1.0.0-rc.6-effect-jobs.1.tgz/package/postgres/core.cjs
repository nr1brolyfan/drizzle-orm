Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_driver_core = require("./driver-core.cjs");
//#region src/postgres/core.ts
function drizzle(config) {
	const { client, ...rest } = config;
	return require_postgres_driver_core.construct(client, rest);
}
//#endregion
exports.PostgresDatabase = require_postgres_driver_core.PostgresDatabase;
exports.drizzle = drizzle;

//# sourceMappingURL=core.cjs.map