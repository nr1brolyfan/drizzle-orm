Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../../../_virtual/_rolldown/runtime.cjs");
const require_postgres_effect_http_session = require("../http/session.cjs");
const require_postgres_effect_neon_http_shape = require("./shape.cjs");
const require_postgres_effect_neon_http_codecs = require("./codecs.cjs");
const require_postgres_effect_neon_http_session = require("./session.cjs");
let __entity_ts = require("../../../entity.cjs");
let __utils_ts = require("../../../utils.cjs");
let __effect_core_index_ts = require("../../../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../../../effect-core/defaults.cjs");
let __pg_core_dialect_ts = require("../../../pg-core/dialect.cjs");
let __pg_core_effect_db_ts = require("../../../pg-core/effect/db.cjs");
let _postgres_effect_neon_http = require("#postgres/effect/neon-http");
//#region src/postgres/effect/neon-http/driver.ts
var EffectPostgresNeonHttpDatabase = class extends __pg_core_effect_db_ts.PgEffectDatabase {
	static [__entity_ts.entityKind] = "EffectPostgresNeonHttpDatabase";
	/**
	* Runs the queries in one transaction, in a single request
	*
	* A failing query fails the batch with it's `EffectDrizzleQueryError` and rolls back the entire batch
	*/
	batch(batch, options) {
		return this.session.batch(batch, options);
	}
	/**
	* Runs the queries concurrently, each as it's own request, without a transaction
	*
	* Never fails because of a failing query: each gives it's own `Result`
	*/
	parallel(batch) {
		return this.session.parallel(batch);
	}
};
/**
* Creates an EffectPostgresNeonHttpDatabase instance on top of Drizzle Postgres over Neon's SQL-over-HTTP endpoint.
*
* Requires `DrizzlePostgresHttpClient` (a Neon HTTP one), and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* HTTP holds no session: there are no interactive transactions (`db.transaction` dies), use `db.batch` for an atomic
* set of statements.
*
* @example
* ```ts
* import * as PostgresNeonHttpDrizzle from 'drizzle-orm/postgres/effect/neon-http';
*
* const db = yield* PostgresNeonHttpDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresNeonHttpDrizzle.DefaultServices),
*   Effect.provide(PostgresNeonHttpDrizzle.DrizzlePostgresHttpClient.layer({ url: Redacted.make(process.env.DATABASE_URL!) })),
* );
* ```
*/
const make = effect_Effect.fn("PostgresNeonHttpDrizzle.make")(function* (config = {}) {
	const client = yield* _postgres_effect_neon_http.DrizzlePostgresHttpClient.DrizzlePostgresHttpClient;
	if (client.kind !== "neon") return yield* effect_Effect.die(new Error(require_postgres_effect_http_session.wrongKind("neon", client.kind)));
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const codecs = config.codecs ?? require_postgres_effect_neon_http_codecs.codecs_exports.postgresCodecs;
	const dialect = new __pg_core_dialect_ts.PgDialect({
		codecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		shapeGenerator: (0, require_postgres_effect_neon_http_shape.shape_exports.createShapeGenerator)(codecs)
	});
	const relations = config.relations ?? {};
	const db = new EffectPostgresNeonHttpDatabase(dialect, new require_postgres_effect_neon_http_session.EffectPostgresNeonHttpSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	return Object.assign(db, { $client: client });
});
/**
* Convenience function that creates an EffectPostgresNeonHttpDatabase with `DefaultServices` already provided.
*/
const makeWithDefaults = (config = {}) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectPostgresNeonHttpDatabase = EffectPostgresNeonHttpDatabase;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map