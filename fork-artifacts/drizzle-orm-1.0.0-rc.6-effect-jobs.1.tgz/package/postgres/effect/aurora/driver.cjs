Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../../../_virtual/_rolldown/runtime.cjs");
const require_postgres_effect_aurora_shape = require("./shape.cjs");
const require_postgres_effect_aurora_codecs = require("./codecs.cjs");
const require_postgres_effect_aurora_session = require("./session.cjs");
let __entity_ts = require("../../../entity.cjs");
let __utils_ts = require("../../../utils.cjs");
let __effect_core_index_ts = require("../../../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../../../effect-core/defaults.cjs");
let __pg_core_effect_db_ts = require("../../../pg-core/effect/db.cjs");
let _postgres_effect_aurora = require("#postgres/effect/aurora");
let __postgres_aurora_dialect_ts = require("../../aurora/dialect.cjs");
//#region src/postgres/effect/aurora/driver.ts
var EffectPostgresAuroraDatabase = class extends __pg_core_effect_db_ts.PgEffectDatabase {
	static [__entity_ts.entityKind] = "EffectPostgresAuroraDatabase";
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
/**
* Creates an EffectPostgresAuroraDatabase instance on top of Drizzle Postgres's Aurora Data API client.
*
* Requires `DrizzleAuroraClient`, and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* Driver quirks:
* - `time` values are cut to milliseconds
* - `timestamp` values with fractional seconds lose `BC`
* - `null` elements of arrays are dropped (`[1, null, 3]` is returned as `[1, 3]`)
*
* Unsupported column types (throw on non-null values):
* - `timetz`, `timestamptz` in `string` mode (converted to UTC, offset dropped)
* - `bytea[]` (returned empty)
*
* @example
* ```ts
* import * as PostgresAuroraDrizzle from 'drizzle-orm/postgres/effect/aurora';
*
* const db = yield* PostgresAuroraDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresAuroraDrizzle.DefaultServices),
*   Effect.provide(PostgresAuroraDrizzle.DrizzleAuroraClient.layer({ resourceArn, secretArn, database })),
* );
* ```
*/
const make = effect_Effect.fn("PostgresAuroraDrizzle.make")(function* (config = {}) {
	const client = yield* _postgres_effect_aurora.DrizzleAuroraClient.DrizzleAuroraClient;
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const codecs = config.codecs ?? require_postgres_effect_aurora_codecs.codecs_exports.postgresAuroraCodecs;
	const dialect = new __postgres_aurora_dialect_ts.PostgresAuroraDialect({
		codecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		shapeGenerator: (0, require_postgres_effect_aurora_shape.shape_exports.createShapeGenerator)(codecs)
	});
	const relations = config.relations ?? {};
	const db = new EffectPostgresAuroraDatabase(dialect, new require_postgres_effect_aurora_session.EffectPostgresAuroraSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	return Object.assign(db, { $client: client });
});
/**
* Convenience function that creates an EffectPostgresAuroraDatabase with `DefaultServices` already provided.
*/
const makeWithDefaults = (config = {}) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectPostgresAuroraDatabase = EffectPostgresAuroraDatabase;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map