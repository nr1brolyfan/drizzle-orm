Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../../../_virtual/_rolldown/runtime.cjs");
const require_postgres_effect_aurora_shape = require("./shape.cjs");
const require_postgres_effect_aurora_codecs = require("./codecs.cjs");
const require_postgres_effect_aurora_session = require("./session.cjs");
const require_postgres_effect_aurora_driver = require("./driver.cjs");
let __effect_core_index_ts = require("../../../effect-core/index.cjs");
let __effect_core_defaults_ts = require("../../../effect-core/defaults.cjs");
//#region src/postgres/effect/aurora/index.ts
var aurora_exports = /* @__PURE__ */ require_runtime.__exportAll({
	DefaultServices: () => __effect_core_defaults_ts.DefaultServices,
	EffectLogger: () => __effect_core_index_ts.EffectLogger,
	EffectPostgresAuroraDatabase: () => require_postgres_effect_aurora_driver.EffectPostgresAuroraDatabase,
	EffectPostgresAuroraSession: () => require_postgres_effect_aurora_session.EffectPostgresAuroraSession,
	EffectPostgresAuroraTransaction: () => require_postgres_effect_aurora_session.EffectPostgresAuroraTransaction,
	make: () => require_postgres_effect_aurora_driver.make,
	makeWithDefaults: () => require_postgres_effect_aurora_driver.makeWithDefaults
});
require_runtime.__reExport(aurora_exports, require("#postgres/effect/aurora"));
require_runtime.__reExport(aurora_exports, require_postgres_effect_aurora_codecs.codecs_exports);
require_runtime.__reExport(aurora_exports, require_postgres_effect_aurora_shape.shape_exports);
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
Object.defineProperty(exports, "EffectLogger", {
	enumerable: true,
	get: function() {
		return __effect_core_index_ts.EffectLogger;
	}
});
exports.EffectPostgresAuroraDatabase = require_postgres_effect_aurora_driver.EffectPostgresAuroraDatabase;
exports.EffectPostgresAuroraSession = require_postgres_effect_aurora_session.EffectPostgresAuroraSession;
exports.EffectPostgresAuroraTransaction = require_postgres_effect_aurora_session.EffectPostgresAuroraTransaction;
exports.make = require_postgres_effect_aurora_driver.make;
exports.makeWithDefaults = require_postgres_effect_aurora_driver.makeWithDefaults;
var _postgres_effect_aurora = require("#postgres/effect/aurora");
Object.keys(_postgres_effect_aurora).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres_effect_aurora[k];
		}
	});
});
var __postgres_aurora_shape_ts = require("../../aurora/shape.cjs");
Object.keys(__postgres_aurora_shape_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __postgres_aurora_shape_ts[k];
		}
	});
});
var __postgres_aurora_codecs_ts = require("../../aurora/codecs.cjs");
Object.keys(__postgres_aurora_codecs_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __postgres_aurora_codecs_ts[k];
		}
	});
});

//# sourceMappingURL=index.cjs.map