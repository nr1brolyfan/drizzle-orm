Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../../_virtual/_rolldown/runtime.cjs");
const require_postgres_effect_shape = require("./shape.cjs");
const require_postgres_effect_codecs = require("./codecs.cjs");
const require_postgres_effect_session = require("./session.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __effect_core_index_ts = require("../../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../../effect-core/defaults.cjs");
let __pg_core_dialect_ts = require("../../pg-core/dialect.cjs");
let __pg_core_effect_db_ts = require("../../pg-core/effect/db.cjs");
let _postgres_effect_core = require("#postgres/effect/core");
//#region src/postgres/effect/driver.ts
var EffectPostgresDatabase = class extends __pg_core_effect_db_ts.PgEffectDatabase {
	static [__entity_ts.entityKind] = "EffectPostgresDatabase";
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
	batch(batch, options) {
		return this.session.batch(batch, options);
	}
	/**
	* Pipelines queries back-to-back on a single pooled connection, without a transaction, as the async driver's
	* `pipeline` does
	*
	* Never fails because of a failing query: one Result per query, in input order. A failing query does not stop or
	* roll back the others. Fails with an `SqlError` when there is no connection to run them on
	*
	* Takes the same items as `batch`:
	*
	* ```ts
	* const getUser = db.select().from(users).where(eq(users.id, sql.placeholder('id'))).prepare('get_user');
	* const [alice, bob, inserted, allUsers] = yield* db.pipeline([
	*   getUser.bind({ id: 1 }),
	*   getUser.bind({ id: 2 }),
	*   db.insert(users).values({ name: 'John' }).returning(),
	*   db.select().from(users),
	* ]);
	* // each is a `Result`: `Result.isSuccess(alice) ? alice.success : alice.failure`
	* ```
	*/
	pipeline(batch) {
		return this.session.pipeline(batch);
	}
	/**
	* Runs queries concurrently, fanned out across pooled connections, without a transaction
	*
	* Never fails because of a failing query: each gives it's own `Result`
	*
	* Failing query does not stop or roll back the others
	*
	* Takes the same items as `batch`:
	*
	* ```ts
	* const getUser = db.select().from(users).where(eq(users.id, sql.placeholder('id'))).prepare('get_user');
	* const [alice, bob, inserted, allUsers] = yield* db.parallel([
	*   getUser.bind({ id: 1 }),
	*   getUser.bind({ id: 2 }),
	*   db.insert(users).values({ name: 'John' }).returning(),
	*   db.select().from(users),
	* ]);
	* // each is a `Result`: `Result.isSuccess(alice) ? alice.success : alice.failure`
	* ```
	*/
	parallel(batch) {
		return this.session.parallel(batch);
	}
	/**
	* Inserts rows in bulk as multi-row `values` statements, filling `$defaultFn` / `$onUpdateFn` like `db.insert(...)`
	*
	* A cell a row leaves out gets the column's database default, and a column no row sets is left out of the statement
	*
	* Atomic by default: rows are split into chunks pipelined in one transaction - pass `atomic: false` to commit per chunk
	*
	* @example
	* ```ts
	* yield* db.bulkInsert(users, [{ name: 'John' }, { name: 'Jane' }]);
	* ```
	*/
	bulkInsert(table, rows, options) {
		return this.session.bulkInsert(table, rows, options);
	}
	/**
	* Updates rows in bulk via driver-side `unnest`, matched by `by` key column(s), filling `$onUpdateFn` like `db.update(...)`
	*
	* Every row must set the same columns, except for the ones filled by `$onUpdateFn`
	*
	* Atomic by default: rows are split into chunks pipelined in one transaction - pass `atomic: false` to commit per chunk
	*
	* @example
	* ```ts
	* yield* db.bulkUpdate(users, [{ id: 1, name: 'John' }, { id: 2, name: 'Jane' }], { by: users.id });
	* ```
	*/
	bulkUpdate(table, rows, options) {
		return this.session.bulkUpdate(table, rows, options);
	}
};
/**
* Creates an EffectPostgresDatabase instance on top of Drizzle Postgres.
*
* Requires `DrizzlePostgresClient`, and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* Every transport provides the same `DrizzlePostgresClient` service, so `make` is the same for all of them: only the
* client's layer differs. Each transport's layer is in an entry point of it's own, so importing this one loads no
* other transport, and no PGlite.
*
* @example Node, Bun, Deno, Cloudflare Workers: the client of this entry point dials with the runtime's sockets
* ```ts
* import * as PostgresDrizzle from 'drizzle-orm/postgres/effect';
*
* const db = yield* PostgresDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresDrizzle.DefaultServices),
*   Effect.provide(PostgresDrizzle.DrizzlePostgresClient.layer({ url: Redacted.make(process.env.DATABASE_URL!) })),
* );
* ```
*
* @example A runtime's client by name, for bundlers that apply no runtime conditions: `node` (Node, Bun), `deno`, `cf`
* ```ts
* import * as PostgresDrizzle from 'drizzle-orm/postgres/effect';
* import { DrizzlePostgresClient } from 'drizzle-orm/postgres/client/effect/cf';
*
* const db = yield* PostgresDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresDrizzle.DefaultServices),
*   Effect.provide(DrizzlePostgresClient.layer({ url: Redacted.make(env.DATABASE_URL) })),
* );
* ```
*
* @example Neon over it's WebSocket proxy: prepared statements, pipelining and interactive transactions, as over TCP
* ```ts
* import * as PostgresDrizzle from 'drizzle-orm/postgres/effect';
* import { DrizzlePostgresClient } from 'drizzle-orm/postgres/client/effect/neon-ws';
*
* const db = yield* PostgresDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresDrizzle.DefaultServices),
*   // the global `WebSocket`: on Node < 22, pass `webSocketConstructor` (the `ws` package's)
*   Effect.provide(DrizzlePostgresClient.layer({ url: Redacted.make(process.env.DATABASE_URL!) })),
* );
* ```
*
* @example PGlite: an in-process Postgres, which stays yours (closing the layer leaves it open)
* ```ts
* import { PGlite } from '@electric-sql/pglite';
* import * as PostgresDrizzle from 'drizzle-orm/postgres/effect';
* import { DrizzlePostgresClient } from 'drizzle-orm/postgres/client/effect/pglite';
*
* const db = yield* PostgresDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresDrizzle.DefaultServices),
*   Effect.provide(DrizzlePostgresClient.layer(new PGlite())), // or `new PGlite('./data')`
* );
* ```
*
* @example A transport of your own: the core client dials with the `DrizzlePostgresTransport` in context
* ```ts
* import * as Layer from 'effect/Layer';
* import * as PostgresDrizzle from 'drizzle-orm/postgres/effect';
* import { DrizzlePostgresClient, DrizzlePostgresTransport } from 'drizzle-orm/postgres/client/effect/core';
*
* const db = yield* PostgresDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresDrizzle.DefaultServices),
*   Effect.provide(
*     DrizzlePostgresClient.layer({ url: Redacted.make(process.env.DATABASE_URL!) }).pipe(
*       Layer.provide(Layer.succeed(DrizzlePostgresTransport.DrizzlePostgresTransport, { connect, cancel })),
*     ),
*   ),
* );
* ```
*
* @example A pool you already have, from any of the above: the layer uses it as it is, and leaves it open
* ```ts
* import * as PostgresDrizzle from 'drizzle-orm/postgres/effect';
* import { createPool } from 'drizzle-orm/postgres/client/node';
*
* const pool = createPool(process.env.DATABASE_URL!);
* const db = yield* PostgresDrizzle.make({ relations }).pipe(
*   Effect.provide(PostgresDrizzle.DefaultServices),
*   Effect.provide(PostgresDrizzle.DrizzlePostgresClient.layerFromPool(pool)),
* );
* ```
*
* Aurora's Data API, the HTTP gateway and Neon's HTTP endpoint have entry points of their own:
* `drizzle-orm/postgres/effect/aurora`, `drizzle-orm/postgres/effect/http` and `drizzle-orm/postgres/effect/neon-http`.
*/
const make = effect_Effect.fn("PostgresDrizzle.make")(function* (config = {}) {
	const client = yield* _postgres_effect_core.DrizzlePostgresClient.DrizzlePostgresClient;
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const codecs = config.codecs ?? require_postgres_effect_codecs.codecs_exports.postgresCodecs;
	const dialect = new __pg_core_dialect_ts.PgDialect({
		codecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		shapeGenerator: (0, require_postgres_effect_shape.shape_exports.createShapeGenerator)(codecs)
	});
	const relations = config.relations ?? {};
	const db = new EffectPostgresDatabase(dialect, new require_postgres_effect_session.EffectPostgresSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	return Object.assign(db, { $client: client });
});
/**
* Same as {@link make}, with `DefaultServices` provided. Only `DrizzlePostgresClient` is required.
*/
const makeWithDefaults = (config = {}) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectPostgresDatabase = EffectPostgresDatabase;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map