Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../../_virtual/_rolldown/runtime.cjs");
//#region src/postgres/effect/codecs.ts
var codecs_exports = /* @__PURE__ */ require_runtime.__exportAll({});
require_runtime.__reExport(codecs_exports, require("../codecs.cjs"));
//#endregion
Object.defineProperty(exports, "codecs_exports", {
	enumerable: true,
	get: function() {
		return codecs_exports;
	}
});
var __postgres_codecs_ts = require("../codecs.cjs");
Object.keys(__postgres_codecs_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __postgres_codecs_ts[k];
		}
	});
});

//# sourceMappingURL=codecs.cjs.map