Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../../_virtual/_rolldown/runtime.cjs");
const require_postgres_effect_shape = require("./shape.cjs");
const require_postgres_effect_codecs = require("./codecs.cjs");
const require_postgres_effect_session = require("./session.cjs");
const require_postgres_effect_driver = require("./driver.cjs");
let __effect_core_index_ts = require("../../effect-core/index.cjs");
let __effect_core_defaults_ts = require("../../effect-core/defaults.cjs");
//#region src/postgres/effect/index.ts
var effect_exports = /* @__PURE__ */ require_runtime.__exportAll({
	DefaultServices: () => __effect_core_defaults_ts.DefaultServices,
	EffectLogger: () => __effect_core_index_ts.EffectLogger,
	EffectPostgresDatabase: () => require_postgres_effect_driver.EffectPostgresDatabase,
	EffectPostgresPreparedQuery: () => require_postgres_effect_session.EffectPostgresPreparedQuery,
	EffectPostgresSession: () => require_postgres_effect_session.EffectPostgresSession,
	EffectPostgresTransaction: () => require_postgres_effect_session.EffectPostgresTransaction,
	make: () => require_postgres_effect_driver.make,
	makeWithDefaults: () => require_postgres_effect_driver.makeWithDefaults
});
require_runtime.__reExport(effect_exports, require("#postgres/effect"));
require_runtime.__reExport(effect_exports, require_postgres_effect_codecs.codecs_exports);
require_runtime.__reExport(effect_exports, require_postgres_effect_shape.shape_exports);
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
Object.defineProperty(exports, "EffectLogger", {
	enumerable: true,
	get: function() {
		return __effect_core_index_ts.EffectLogger;
	}
});
exports.EffectPostgresDatabase = require_postgres_effect_driver.EffectPostgresDatabase;
exports.EffectPostgresPreparedQuery = require_postgres_effect_session.EffectPostgresPreparedQuery;
exports.EffectPostgresSession = require_postgres_effect_session.EffectPostgresSession;
exports.EffectPostgresTransaction = require_postgres_effect_session.EffectPostgresTransaction;
exports.make = require_postgres_effect_driver.make;
exports.makeWithDefaults = require_postgres_effect_driver.makeWithDefaults;
var _postgres_effect = require("#postgres/effect");
Object.keys(_postgres_effect).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres_effect[k];
		}
	});
});
var __postgres_shape_ts = require("../shape.cjs");
Object.keys(__postgres_shape_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __postgres_shape_ts[k];
		}
	});
});
var __postgres_codecs_ts = require("../codecs.cjs");
Object.keys(__postgres_codecs_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __postgres_codecs_ts[k];
		}
	});
});

//# sourceMappingURL=index.cjs.map