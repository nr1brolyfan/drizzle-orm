Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __pg_core_codecs_ts = require("../pg-core/codecs.cjs");
//#region src/postgres/codecs.ts
const jsonStringify = (value) => JSON.stringify(value);
const postgresCodecs = {
	json: {
		normalizeParam: jsonStringify,
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)(jsonStringify, true)
	},
	jsonb: {
		normalizeParam: jsonStringify,
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)(jsonStringify, true)
	},
	bytea: {
		normalizeInJson: __pg_core_codecs_ts.byteaFromPgHex,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.byteaFromPgHex)
	},
	"timestamp:string": {
		castInJson: __pg_core_codecs_ts.castToText,
		castArrayInJson: __pg_core_codecs_ts.castToTextArr
	},
	"timestamptz:string": {
		castInJson: __pg_core_codecs_ts.castToText,
		castArrayInJson: __pg_core_codecs_ts.castToTextArr
	},
	point: {
		normalizeInJson: __pg_core_codecs_ts.parsePointXY,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointXY)
	},
	"point:tuple": {
		normalizeInJson: __pg_core_codecs_ts.parsePointTuple,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointTuple)
	},
	line: {
		normalizeInJson: __pg_core_codecs_ts.parseLineABC,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineABC)
	},
	"line:tuple": {
		normalizeInJson: __pg_core_codecs_ts.parseLineTuple,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineTuple)
	},
	box: { normalizeParamArray: __pg_core_codecs_ts.makeBoxArray },
	"geometry(point)": {
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray,
		castInJson: __pg_core_codecs_ts.castToText,
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		normalizeInJson: __pg_core_codecs_ts.parseGeometryXY,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseGeometryXY)
	},
	"geometry(point):tuple": {
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray,
		castInJson: __pg_core_codecs_ts.castToText,
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		normalizeInJson: __pg_core_codecs_ts.parseGeometryTuple,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseGeometryTuple)
	},
	"geography(point)": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	"geography(point):tuple": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	halfvec: {
		castInJson: __pg_core_codecs_ts.castToText,
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		normalizeInJson: __pg_core_codecs_ts.parsePgVector,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePgVector)
	},
	vector: {
		castInJson: __pg_core_codecs_ts.castToText,
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		normalizeInJson: __pg_core_codecs_ts.parsePgVector,
		normalizeArrayInJson: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePgVector)
	}
};
//#endregion
exports.postgresCodecs = postgresCodecs;

//# sourceMappingURL=codecs.cjs.map