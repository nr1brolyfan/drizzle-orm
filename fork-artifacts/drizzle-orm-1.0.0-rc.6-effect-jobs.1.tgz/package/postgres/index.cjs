Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_codecs = require("./codecs.cjs");
const require_postgres_session = require("./session.cjs");
const require_postgres_shape = require("./shape.cjs");
const require_postgres_driver_core = require("./driver-core.cjs");
const require_postgres_driver = require("./driver.cjs");
exports.PostgresDatabase = require_postgres_driver_core.PostgresDatabase;
exports.PostgresPreparedQuery = require_postgres_session.PostgresPreparedQuery;
exports.PostgresSession = require_postgres_session.PostgresSession;
exports.PostgresTransaction = require_postgres_session.PostgresTransaction;
Object.defineProperty(exports, "buildShape", {
	enumerable: true,
	get: function() {
		return require_postgres_shape.buildShape;
	}
});
exports.construct = require_postgres_driver_core.construct;
exports.createShapeGenerator = require_postgres_shape.createShapeGenerator;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return require_postgres_driver.drizzle;
	}
});
exports.postgresCodecs = require_postgres_codecs.postgresCodecs;
var _postgres = require("#postgres");
Object.keys(_postgres).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres[k];
		}
	});
});
