var _postgres_cdc = require("#postgres/cdc");
Object.keys(_postgres_cdc).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres_cdc[k];
		}
	});
});
