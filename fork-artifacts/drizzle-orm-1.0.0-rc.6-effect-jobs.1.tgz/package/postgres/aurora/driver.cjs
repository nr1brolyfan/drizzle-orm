Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_shape = require("../shape.cjs");
const require_postgres_aurora_codecs = require("./codecs.cjs");
const require_postgres_aurora_dialect = require("./dialect.cjs");
const require_postgres_aurora_session = require("./session.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __logger_ts = require("../../logger.cjs");
let __pg_core_async_db_ts = require("../../pg-core/async/db.cjs");
let _postgres_aurora = require("#postgres/aurora");
//#region src/postgres/aurora/driver.ts
var PostgresAuroraDatabase = class extends __pg_core_async_db_ts.PgAsyncDatabase {
	static [__entity_ts.entityKind] = "PostgresAuroraDatabase";
};
function construct(client, config = {}) {
	const codecs = config.codecs ?? require_postgres_aurora_codecs.postgresAuroraCodecs;
	const dialect = new require_postgres_aurora_dialect.PostgresAuroraDialect({
		codecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		shapeGenerator: require_postgres_shape.createShapeGenerator(codecs)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new PostgresAuroraDatabase(dialect, new require_postgres_aurora_session.PostgresAuroraSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
/**
* Driver quirks:
* - `time` values are cut to milliseconds
* - `timestamp` values with fractional seconds lose `BC`
* - `null` elements of arrays are dropped (`[1, null, 3]` is returned as `[1, 3]`)
*
* Unsupported column types (throw on non-null values):
* - `timetz`, `timestamptz` in `string` mode (converted to UTC, offset dropped)
* - `bytea[]` (returned empty)
*/
function drizzle(...params) {
	const { connection, client, ...config } = params[0];
	if (client) return construct(client, config);
	return construct((0, _postgres_aurora.createPool)(connection), config);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.PostgresAuroraDatabase = PostgresAuroraDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map