Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_shape = require("../shape.cjs");
const require_postgres_aurora_codecs = require("./codecs.cjs");
const require_postgres_aurora_dialect = require("./dialect.cjs");
const require_postgres_aurora_session = require("./session.cjs");
const require_postgres_aurora_driver = require("./driver.cjs");
exports.PostgresAuroraDatabase = require_postgres_aurora_driver.PostgresAuroraDatabase;
exports.PostgresAuroraDialect = require_postgres_aurora_dialect.PostgresAuroraDialect;
exports.PostgresAuroraSession = require_postgres_aurora_session.PostgresAuroraSession;
exports.PostgresAuroraTransaction = require_postgres_aurora_session.PostgresAuroraTransaction;
Object.defineProperty(exports, "buildShape", {
	enumerable: true,
	get: function() {
		return require_postgres_shape.buildShape;
	}
});
exports.createShapeGenerator = require_postgres_shape.createShapeGenerator;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return require_postgres_aurora_driver.drizzle;
	}
});
exports.postgresAuroraCodecs = require_postgres_aurora_codecs.postgresAuroraCodecs;
var _postgres_aurora = require("#postgres/aurora");
Object.keys(_postgres_aurora).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres_aurora[k];
		}
	});
});
