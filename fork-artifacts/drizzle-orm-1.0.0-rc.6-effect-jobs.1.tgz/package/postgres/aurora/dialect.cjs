Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __pg_core_dialect_ts = require("../../pg-core/dialect.cjs");
//#region src/postgres/aurora/dialect.ts
/** Postgres dialect of AWS Data API, which takes named `:pN` parameters */
var PostgresAuroraDialect = class extends __pg_core_dialect_ts.PgDialect {
	static [__entity_ts.entityKind] = "PostgresAuroraDialect";
	escapeParam(num) {
		return `:p${num + 1}`;
	}
};
//#endregion
exports.PostgresAuroraDialect = PostgresAuroraDialect;

//# sourceMappingURL=dialect.cjs.map