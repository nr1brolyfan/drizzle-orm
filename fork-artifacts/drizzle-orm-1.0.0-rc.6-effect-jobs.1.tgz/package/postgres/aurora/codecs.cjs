Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_codecs = require("../codecs.cjs");
let __codecs_ts = require("../../codecs.cjs");
//#region src/postgres/aurora/codecs.ts
const driver = "postgres/aurora";
const timeTzReason = "Data API converts `timetz` values to UTC dropping their offset and accepts no per-query result formats";
const timestamptzTextReason = "Data API converts `timestamptz` values to UTC, dropping the offset the server formats in the session's time zone, and accepts no per-query result formats";
const byteaArrayReason = "Data API has no array type for binary values and returns `bytea[]` empty";
const unsupported = (type, reason) => {
	const normalize = (0, __codecs_ts.unsupportedCodec)(type, driver, reason);
	return {
		normalize,
		normalizeArray: normalize
	};
};
/** Variant of {@link postgresCodecs} for AWS Data API, which formats values itself with no per-query alternative */
const postgresAuroraCodecs = (0, __codecs_ts.refineCodecs)(require_postgres_codecs.postgresCodecs, {
	bytea: { normalizeArray: (0, __codecs_ts.unsupportedCodec)("bytea[]", driver, byteaArrayReason) },
	timetz: unsupported("time with time zone", timeTzReason),
	"timestamptz:string": unsupported("timestamp with time zone", timestamptzTextReason)
});
//#endregion
exports.postgresAuroraCodecs = postgresAuroraCodecs;

//# sourceMappingURL=codecs.cjs.map