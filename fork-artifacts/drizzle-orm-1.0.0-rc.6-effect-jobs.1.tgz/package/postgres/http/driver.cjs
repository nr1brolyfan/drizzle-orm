Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_codecs = require("../codecs.cjs");
const require_postgres_shape = require("../shape.cjs");
const require_postgres_http_session = require("./session.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __pg_core_dialect_ts = require("../../pg-core/dialect.cjs");
let __logger_ts = require("../../logger.cjs");
let __pg_core_async_db_ts = require("../../pg-core/async/db.cjs");
let _postgres_http = require("#postgres/http");
//#region src/postgres/http/driver.ts
var PostgresHttpDatabase = class extends __pg_core_async_db_ts.PgAsyncDatabase {
	static [__entity_ts.entityKind] = "PostgresHttpDatabase";
	/**
	* Runs multiple queries at once in transaction
	*
	* Failing query will throw, stop remaining queries and roll back entire batch
	*/
	async batch(batch, options) {
		return this.session.batch(batch, options);
	}
	/**
	* Pipelines queries back-to-back on a single connection, without a transaction
	*
	* Never throws because of a failing query
	*
	* Failing query does not stop or roll back the others
	*/
	async pipeline(batch, options) {
		return this.session.pipeline(batch, options);
	}
	/**
	* Runs queries concurrently, each as it's own request, without a transaction
	*
	* Never throws because of a failing query
	*
	* Failing query does not stop or roll back the others
	*/
	async parallel(batch, options) {
		return this.session.parallel(batch, options);
	}
};
function construct(client, config = {}) {
	const codecs = config.codecs ?? require_postgres_codecs.postgresCodecs;
	const dialect = new __pg_core_dialect_ts.PgDialect({
		codecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		shapeGenerator: require_postgres_shape.createShapeGenerator(codecs)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new PostgresHttpDatabase(dialect, new require_postgres_http_session.PostgresHttpSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
function drizzle(...params) {
	if (typeof params[0] === "string") return construct((0, _postgres_http.client)({ url: params[0] }), params[1]);
	const { connection, client, ...config } = params[0];
	if (client) return construct(client, config);
	return construct(typeof connection === "string" ? (0, _postgres_http.client)({ url: connection }) : (0, _postgres_http.client)(connection), config);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.PostgresHttpDatabase = PostgresHttpDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map