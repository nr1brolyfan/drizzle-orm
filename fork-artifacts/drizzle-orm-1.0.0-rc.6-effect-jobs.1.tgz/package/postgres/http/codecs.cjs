Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_codecs = require("../codecs.cjs");
exports.postgresCodecs = require_postgres_codecs.postgresCodecs;
