Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_codecs = require("../codecs.cjs");
const require_postgres_shape = require("../shape.cjs");
const require_postgres_http_session = require("./session.cjs");
const require_postgres_http_driver = require("./driver.cjs");
exports.PostgresHttpDatabase = require_postgres_http_driver.PostgresHttpDatabase;
exports.PostgresHttpPreparedQuery = require_postgres_http_session.PostgresHttpPreparedQuery;
exports.PostgresHttpSession = require_postgres_http_session.PostgresHttpSession;
Object.defineProperty(exports, "buildShape", {
	enumerable: true,
	get: function() {
		return require_postgres_shape.buildShape;
	}
});
exports.createShapeGenerator = require_postgres_shape.createShapeGenerator;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return require_postgres_http_driver.drizzle;
	}
});
exports.httpQueryError = require_postgres_http_session.httpQueryError;
exports.postgresCodecs = require_postgres_codecs.postgresCodecs;
var _postgres_http = require("#postgres/http");
Object.keys(_postgres_http).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return _postgres_http[k];
		}
	});
});
