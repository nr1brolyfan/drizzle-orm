Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_node_postgres_codecs = require("../codecs.cjs");
const require_node_postgres_dsql_session = require("./session.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __pg_core_dialect_ts = require("../../pg-core/dialect.cjs");
let __logger_ts = require("../../logger.cjs");
let _aws_aurora_dsql_node_postgres_connector = require("@aws/aurora-dsql-node-postgres-connector");
let __pg_core_async_dsql_db_ts = require("../../pg-core/async/dsql/db.cjs");
//#region src/node-postgres/dsql/driver.ts
var NodePgDsqlDatabase = class extends __pg_core_async_dsql_db_ts.DsqlAsyncDatabase {
	static [__entity_ts.entityKind] = "NodePgDsqlDatabase";
	transaction(transaction, config) {
		return super.transaction(transaction, config);
	}
};
function construct(client, config = {}) {
	const dialect = new __pg_core_dialect_ts.PgDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_node_postgres_codecs.nodePgCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new NodePgDsqlDatabase(dialect, new require_node_postgres_dsql_session.NodePgDsqlSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
/**
* Requirements:
* - Sessions must use the ISO `DateStyle` (the default): temporal values of other `DateStyle`s throw
*/
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(new _aws_aurora_dsql_node_postgres_connector.AuroraDSQLPool({ connectionString: params[0] }), params[1]);
	const { connection, client, ...drizzlePgCDrizzlePgConfig } = params[0];
	if (client) return construct(client, drizzlePgCDrizzlePgConfig);
	return construct(typeof connection === "string" ? new _aws_aurora_dsql_node_postgres_connector.AuroraDSQLPool({ connectionString: connection }) : new _aws_aurora_dsql_node_postgres_connector.AuroraDSQLPool(connection), drizzlePgCDrizzlePgConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.NodePgDsqlDatabase = NodePgDsqlDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map