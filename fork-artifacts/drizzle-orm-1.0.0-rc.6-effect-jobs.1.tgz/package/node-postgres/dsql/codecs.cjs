Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_node_postgres_codecs = require("../codecs.cjs");
exports.nodePgCodecs = require_node_postgres_codecs.nodePgCodecs;
