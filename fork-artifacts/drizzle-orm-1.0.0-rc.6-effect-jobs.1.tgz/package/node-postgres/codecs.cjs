Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __pg_core_array_ts = require("../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../pg-core/codecs.cjs");
//#region src/node-postgres/codecs.ts
const pointToTuple = ({ x, y }) => [x, y];
const nodePgCodecs = (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
	bigint: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"bigint:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	"bigint:string": {
		normalize: String,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(String)
	},
	bigserial: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"bigserial:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	bit: { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	numeric: { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	"numeric:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(Number)
	},
	"numeric:bigint": {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(BigInt)
	},
	date: {
		normalize: __pg_core_codecs_ts.textToDate,
		normalizeArray: __pg_core_codecs_ts.textToDatePgArray
	},
	"date:string": { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	timestamp: {
		normalize: __pg_core_codecs_ts.textToDateWithTz,
		normalizeArray: __pg_core_codecs_ts.textToDateWithTzPgArray
	},
	timestamptz: {
		normalize: __pg_core_codecs_ts.textToDate,
		normalizeArray: __pg_core_codecs_ts.textToDatePgArray
	},
	"timestamp:string": { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	"timestamptz:string": { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	"geometry(point)": {
		normalize: __pg_core_codecs_ts.parseGeometryXY,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryXY),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	"geometry(point):tuple": {
		normalize: __pg_core_codecs_ts.parseGeometryTuple,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryTuple),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	interval: { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	json: {
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	jsonb: {
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	enum: {
		normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	line: {
		normalize: __pg_core_codecs_ts.parseLineABC,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parseLineABC)
	},
	"line:tuple": {
		normalize: __pg_core_codecs_ts.parseLineTuple,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parseLineTuple)
	},
	macaddr8: {
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
	},
	"point:tuple": {
		normalize: pointToTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(pointToTuple)
	},
	halfvec: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector)
	},
	sparsevec: { normalizeArray: (v) => (0, __pg_core_array_ts.parsePgArray)(v) },
	vector: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector)
	}
});
//#endregion
exports.nodePgCodecs = nodePgCodecs;

//# sourceMappingURL=codecs.cjs.map