Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_entity = require("./entity.cjs");
const require_errors = require("./errors.cjs");
//#region src/codecs.ts
const noopCodecs = {};
const unsupportedColumnTypeError = (type, driver, reason) => new require_errors.DrizzleError({ message: `Column type "${type}" is not supported with the ${driver} driver: ${reason}` });
/**
* Normalizer for a column type that a driver can't return without losing data, and that can't be requested from it
* in a lossless form per query - throws on every non-null value
*/
const unsupportedCodec = (type, driver, reason) => () => {
	throw unsupportedColumnTypeError(type, driver, reason);
};
const unsafeIntegerReason = "the driver returned an integer outside of the safe integer range as a number, which has already lost precision; configure the client to return such values as strings or bigints";
/** `bigint` from a driver value that is a `bigint`, integer text or, depending on client options, a `number` */
const bigintFromIntegerValue = (type, driver) => (value) => {
	if (typeof value === "number") {
		if (Number.isSafeInteger(value)) return BigInt(value);
		throw unsupportedColumnTypeError(type, driver, unsafeIntegerReason);
	}
	return BigInt(value);
};
const noCodecs = {
	castInJson: void 0,
	castParam: void 0,
	normalize: void 0,
	normalizeInJson: void 0,
	normalizeParam: void 0
};
const arrayToItemTypeCodecNameMap = {
	castInJson: "castInJson",
	castArrayInJson: "castInJson",
	castParam: "castParam",
	castArrayParam: "castParam",
	normalize: "normalize",
	normalizeArray: "normalize",
	normalizeInJson: "normalizeInJson",
	normalizeArrayInJson: "normalizeInJson",
	normalizeParam: "normalizeParam",
	normalizeParamArray: "normalizeParam"
};
var CodecsCollection = class {
	resolveTypes;
	codecs;
	static [require_entity.entityKind] = "CodecsCollection";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(resolveTypes, codecs = noopCodecs) {
		this.resolveTypes = resolveTypes;
		this.codecs = codecs;
	}
	itemCodecsCache = /* @__PURE__ */ new Map();
	arrayCodecsCache = /* @__PURE__ */ new Map();
	/** @internal */
	codecsOf(column, override) {
		const sqlType = override ?? column.codec;
		if (!sqlType) return noCodecs;
		const isArray = !!column.dimensions;
		const cache = isArray ? this.arrayCodecsCache : this.itemCodecsCache;
		let resolved = cache.get(sqlType);
		if (resolved === void 0) {
			const codec = this.codecs[sqlType];
			resolved = codec ? isArray ? {
				castInJson: codec.castArrayInJson,
				castParam: codec.castArrayParam,
				normalize: codec.normalizeArray,
				normalizeInJson: codec.normalizeArrayInJson,
				normalizeParam: codec.normalizeParamArray
			} : {
				castInJson: codec.castInJson,
				castParam: codec.castParam,
				normalize: codec.normalize,
				normalizeInJson: codec.normalizeInJson,
				normalizeParam: codec.normalizeParam
			} : noCodecs;
			cache.set(sqlType, resolved);
		}
		return resolved;
	}
	get(column, type, override) {
		return this.codecsOf(column, override)[arrayToItemTypeCodecNameMap[type]];
	}
	apply(column, type, value, override) {
		const codecType = arrayToItemTypeCodecNameMap[type];
		const codec = this.codecsOf(column, override)[codecType];
		if (!codec) return value;
		if (codecType === "castParam") return codec(value, column, column.dimensions);
		return codec(value, column.dimensions);
	}
};
function refineCodecs(source, extension = {}) {
	const keys = (/* @__PURE__ */ new Set([...Object.keys(source), ...Object.keys(extension)])).values();
	const result = {};
	for (const k of keys) {
		if (!(k in extension)) {
			result[k] = source[k] ? { ...source[k] } : void 0;
			continue;
		}
		if (!(k in source) || extension[k] === void 0) {
			result[k] = extension[k] ? { ...extension[k] } : void 0;
			continue;
		}
		const innerKeys = (/* @__PURE__ */ new Set([...Object.keys(extension[k]), ...Object.keys(source[k] ?? {})])).values();
		result[k] = {};
		for (const ik of innerKeys) result[k][ik] = ik in extension[k] ? extension[k][ik] : source[k]?.[ik];
	}
	return result;
}
//#endregion
exports.CodecsCollection = CodecsCollection;
exports.bigintFromIntegerValue = bigintFromIntegerValue;
exports.noopCodecs = noopCodecs;
exports.refineCodecs = refineCodecs;
exports.unsupportedCodec = unsupportedCodec;
exports.unsupportedColumnTypeError = unsupportedColumnTypeError;

//# sourceMappingURL=codecs.cjs.map