Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
const require_effect_postgres_codecs = require("./codecs.cjs");
const require_effect_postgres_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __effect_core_index_ts = require("../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../effect-core/defaults.cjs");
let __pg_core_dialect_ts = require("../pg-core/dialect.cjs");
let __pg_core_effect_db_ts = require("../pg-core/effect/db.cjs");
let _effect_sql_pg_PgClient = require("@effect/sql-pg/PgClient");
//#region src/effect-postgres/driver.ts
var EffectPgDatabase = class extends __pg_core_effect_db_ts.PgEffectDatabase {
	static [__entity_ts.entityKind] = "EffectPgDatabase";
};
/**
* Creates an EffectPgDatabase instance.
*
* Requires `PgClient`, and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* @example
* ```ts
* // With default services (no logging, no caching)
* const db = yield* PgDrizzle.make({ relations }).pipe(
*   Effect.provide(PgDrizzle.DefaultServices),
* );
*
* // With Effect-based logging
* const db = yield* PgDrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layer),
*   Effect.provide(PgDrizzle.DefaultServices),
* );
*
* // With custom Drizzle logger
* const db = yield* PgDrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layerFromDrizzle(myLogger)),
*   Effect.provide(PgDrizzle.DefaultServices),
* );
* ```
*
* Driver quirks:
* - `timestamp` in `string` mode loses microseconds
* - The driver itself fails on `point`, `line`, `bit`, `interval[]` and multidimensional arrays
*
* Unsupported column types (throw on non-null values):
* - `timestamptz` in `string` mode (offset dropped)
* - `macaddr`, `macaddr8`, `enum[]`, `geometry`, `vector`, `halfvec`, `sparsevec` (binary format decoded as corrupted text)
*/
const make = effect_Effect.fn("PgDrizzle.make")(function* (config = {}) {
	const client = yield* _effect_sql_pg_PgClient.PgClient;
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const dialect = new __pg_core_dialect_ts.PgDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_effect_postgres_codecs.effectPgCodecs
	});
	const relations = config.relations ?? {};
	const db = new EffectPgDatabase(dialect, new require_effect_postgres_session.EffectPgSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
});
/**
* Convenience function that creates an EffectPgDatabase with `DefaultServices` already provided.
*/
const makeWithDefaults = (config = {}) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectPgDatabase = EffectPgDatabase;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map