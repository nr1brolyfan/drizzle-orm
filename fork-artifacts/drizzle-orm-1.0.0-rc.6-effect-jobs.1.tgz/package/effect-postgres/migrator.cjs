Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __pg_core_effect_session_ts = require("../pg-core/effect/session.cjs");
let __migrator_ts = require("../migrator.cjs");
//#region src/effect-postgres/migrator.ts
function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	return (0, __pg_core_effect_session_ts.migrate)(migrations, db.session, config);
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map