Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __utils_ts = require("../utils.cjs");
let __codecs_ts = require("../codecs.cjs");
let __pg_core_array_ts = require("../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../pg-core/codecs.cjs");
//#region src/effect-postgres/codecs.ts
const bytesToPgHex = (value) => {
	let hex = "\\x";
	for (const byte of value) hex += byte.toString(16).padStart(2, "0");
	return hex;
};
const driver = "@effect/sql-pg";
const binaryReason = "the driver decodes the binary format of this type as text, corrupting it, and its `Effect` client accepts no per-query result formats";
const timeZoneReason = "the driver decodes `timestamptz` values to `Date`s, dropping the offset the server formats in the session's time zone, and its `Effect` client accepts no per-query result formats";
const timestampText = (0, __pg_core_codecs_ts.pgTimestampTextFromUtcDate)(false);
/** PostgreSQL's `date` text from the driver's ISO 8601 date: ISO year `0` is 1 BC, `-1` is 2 BC (`-0043-03-15` -> `0044-03-15 BC`) */
const pgDateText = (value) => {
	if (value === "infinity" || value === "-infinity") return value;
	const yearEnd = value.indexOf("-", 1);
	const year = +value.slice(0, yearEnd);
	return year > 0 ? value : `${String(1 - year).padStart(4, "0")}${value.slice(yearEnd)} BC`;
};
const dateFromIsoText = (value) => (0, __pg_core_codecs_ts.textToDate)(pgDateText(value));
/** PostgreSQL's `time` text from the driver's microseconds since midnight */
const pgTimeFromMicroseconds = (value) => {
	const micros = BigInt(value);
	const seconds = micros / 1000000n;
	const fraction = micros % 1000000n;
	const hms = `${String(seconds / 3600n).padStart(2, "0")}:${String(seconds / 60n % 60n).padStart(2, "0")}:${String(seconds % 60n).padStart(2, "0")}`;
	return fraction === 0n ? hms : `${hms}.${String(fraction).padStart(6, "0").replace(/0+$/, "")}`;
};
/** PostgreSQL's `timetz` text omits zero offset minutes: `12:00:00+05:00` -> `12:00:00+05` */
const pgTimeTzText = (value) => value.endsWith(":00") && value.charCodeAt(value.length - 6) !== 58 ? value.slice(0, -3) : value;
const effectPgCodecs = (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
	bit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	date: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: dateFromIsoText,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(dateFromIsoText)
	},
	"date:string": {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: pgDateText,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(pgDateText)
	},
	"geometry(point)": {
		normalize: (0, __codecs_ts.unsupportedCodec)("geometry(point)", driver, binaryReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("geometry(point)", driver, binaryReason)
	},
	"geometry(point):tuple": {
		normalize: (0, __codecs_ts.unsupportedCodec)("geometry(point)", driver, binaryReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("geometry(point)", driver, binaryReason)
	},
	"geometry(polygon)": { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	interval: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	line: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"line:tuple": { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	macaddr: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("macaddr", driver, binaryReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("macaddr", driver, binaryReason)
	},
	macaddr8: {
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("macaddr8", driver, binaryReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("macaddr8", driver, binaryReason)
	},
	point: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"point:tuple": { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	timestamp: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	timestamptz: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"timestamp:string": {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: timestampText,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(timestampText)
	},
	"timestamptz:string": {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timeZoneReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timeZoneReason)
	},
	json: {
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	jsonb: {
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	box: { normalizeParamArray: __pg_core_codecs_ts.makeBoxArray },
	box2d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	box3d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	cidr: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	circle: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	datemultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	daterange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"geography(point)": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	"geography(point):tuple": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	inet: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int4multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int4range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int8multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int8range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	lseg: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	money: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	nummultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	numrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	oid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	path: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	polygon: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	raster: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regclass: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regconfig: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regdictionary: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regnamespace: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regoper: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regoperator: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regproc: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regprocedure: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regrole: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regtype: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	time: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: pgTimeFromMicroseconds,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(pgTimeFromMicroseconds)
	},
	timetz: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: pgTimeTzText,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(pgTimeTzText)
	},
	tsmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsquery: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tstzmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tstzrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsvector: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	varbit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	xml: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	bytea: {
		normalizeInJson: typeof Buffer === "undefined" ? __utils_ts.pgHexToUint8Array : __pg_core_codecs_ts.genericPgCodecs.bytea?.normalizeInJson,
		normalizeArrayInJson: typeof Buffer === "undefined" ? (0, __pg_core_codecs_ts.arrayCompatNormalize)(__utils_ts.pgHexToUint8Array) : __pg_core_codecs_ts.genericPgCodecs.bytea?.normalizeArrayInJson,
		normalize: typeof Buffer === "undefined" ? void 0 : (v) => Buffer.from(v),
		normalizeArray: typeof Buffer === "undefined" ? void 0 : (0, __pg_core_codecs_ts.arrayCompatNormalize)((v) => Buffer.from(v)),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)(bytesToPgHex, true)
	},
	enum: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("enum[]", driver, binaryReason)
	},
	numeric: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"numeric:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"numeric:bigint": {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"bigint:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"bigint:string": {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: String,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(String)
	},
	"bigserial:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	float4: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: __pg_core_codecs_ts.shortestFloat32,
		normalizeArray: __pg_core_codecs_ts.shortestFloat32Array
	},
	uuid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	halfvec: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("halfvec", driver, binaryReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("halfvec", driver, binaryReason)
	},
	sparsevec: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("sparsevec", driver, binaryReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("sparsevec", driver, binaryReason)
	},
	vector: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("vector", driver, binaryReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("vector", driver, binaryReason)
	},
	bigint: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	bigserial: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	bool: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	char: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	varchar: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	text: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	smallint: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	smallserial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	serial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	float8: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) }
});
//#endregion
exports.effectPgCodecs = effectPgCodecs;

//# sourceMappingURL=codecs.cjs.map