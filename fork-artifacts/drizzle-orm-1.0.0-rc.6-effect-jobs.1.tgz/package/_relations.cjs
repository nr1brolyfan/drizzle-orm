Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_entity = require("./entity.cjs");
const require_column = require("./column.cjs");
const require_sql_sql = require("./sql/sql.cjs");
const require_sql_expressions_conditions = require("./sql/expressions/conditions.cjs");
const require_sql_expressions_select = require("./sql/expressions/select.cjs");
const require_pg_core_primary_keys = require("./pg-core/primary-keys.cjs");
let __table_ts = require("./table.cjs");
//#region src/_relations.ts
var Relation = class {
	sourceTable;
	referencedTable;
	relationName;
	static [require_entity.entityKind] = "Relation";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	referencedTableName;
	fieldName;
	constructor(sourceTable, referencedTable, relationName) {
		this.sourceTable = sourceTable;
		this.referencedTable = referencedTable;
		this.relationName = relationName;
		this.referencedTableName = referencedTable[__table_ts.Table.Symbol.Name];
	}
};
var Relations = class {
	table;
	config;
	static [require_entity.entityKind] = "Relations";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(table, config) {
		this.table = table;
		this.config = config;
	}
};
var One = class One extends Relation {
	config;
	isNullable;
	static [require_entity.entityKind] = "One";
	constructor(sourceTable, referencedTable, config, isNullable) {
		super(sourceTable, referencedTable, config?.relationName);
		this.config = config;
		this.isNullable = isNullable;
	}
	withFieldName(fieldName) {
		const relation = new One(this.sourceTable, this.referencedTable, this.config, this.isNullable);
		relation.fieldName = fieldName;
		return relation;
	}
};
var Many = class Many extends Relation {
	config;
	static [require_entity.entityKind] = "Many";
	constructor(sourceTable, referencedTable, config) {
		super(sourceTable, referencedTable, config?.relationName);
		this.config = config;
	}
	withFieldName(fieldName) {
		const relation = new Many(this.sourceTable, this.referencedTable, this.config);
		relation.fieldName = fieldName;
		return relation;
	}
};
function getOperators() {
	return {
		and: require_sql_expressions_conditions.and,
		between: require_sql_expressions_conditions.between,
		eq: require_sql_expressions_conditions.eq,
		exists: require_sql_expressions_conditions.exists,
		gt: require_sql_expressions_conditions.gt,
		gte: require_sql_expressions_conditions.gte,
		ilike: require_sql_expressions_conditions.ilike,
		inArray: require_sql_expressions_conditions.inArray,
		isNull: require_sql_expressions_conditions.isNull,
		isNotNull: require_sql_expressions_conditions.isNotNull,
		like: require_sql_expressions_conditions.like,
		lt: require_sql_expressions_conditions.lt,
		lte: require_sql_expressions_conditions.lte,
		ne: require_sql_expressions_conditions.ne,
		not: require_sql_expressions_conditions.not,
		notBetween: require_sql_expressions_conditions.notBetween,
		notExists: require_sql_expressions_conditions.notExists,
		notLike: require_sql_expressions_conditions.notLike,
		notIlike: require_sql_expressions_conditions.notIlike,
		notInArray: require_sql_expressions_conditions.notInArray,
		or: require_sql_expressions_conditions.or,
		sql: require_sql_sql.sql
	};
}
function getOrderByOperators() {
	return {
		sql: require_sql_sql.sql,
		asc: require_sql_expressions_select.asc,
		desc: require_sql_expressions_select.desc
	};
}
function extractTablesRelationalConfig(schema, configHelpers) {
	if (Object.keys(schema).length === 1 && "default" in schema && !require_entity.is(schema["default"], __table_ts.Table)) schema = schema["default"];
	const tableNamesMap = {};
	const relationsBuffer = {};
	const tablesConfig = {};
	for (const [key, value] of Object.entries(schema)) if (require_entity.is(value, __table_ts.Table)) {
		const dbName = (0, __table_ts.getLegacyTableUniqueName)(value);
		const bufferedRelations = relationsBuffer[dbName];
		tableNamesMap[dbName] = key;
		tablesConfig[key] = {
			tsName: key,
			dbName: value[__table_ts.Table.Symbol.Name],
			schema: value[__table_ts.Table.Symbol.Schema],
			columns: value[__table_ts.Table.Symbol.Columns],
			relations: bufferedRelations?.relations ?? {},
			primaryKey: bufferedRelations?.primaryKey ?? []
		};
		for (const column of Object.values(value[__table_ts.Table.Symbol.Columns])) if (column.primary) tablesConfig[key].primaryKey.push(column);
		const extraConfig = value[__table_ts.Table.Symbol.ExtraConfigBuilder]?.(value[__table_ts.Table.Symbol.ExtraConfigColumns]);
		if (extraConfig) {
			const extraValues = Array.isArray(extraConfig) ? extraConfig.flat(1) : Object.values(extraConfig);
			for (const configEntry of extraValues) if (require_entity.is(configEntry, require_pg_core_primary_keys.PrimaryKeyBuilder)) tablesConfig[key].primaryKey.push(...configEntry.columns);
		}
	} else if (require_entity.is(value, Relations)) {
		const dbName = (0, __table_ts.getLegacyTableUniqueName)(value.table);
		const tableName = tableNamesMap[dbName];
		const relations = value.config(configHelpers(value.table));
		for (const [relationName, relation] of Object.entries(relations)) if (tableName) {
			const tableConfig = tablesConfig[tableName];
			tableConfig.relations[relationName] = relation;
		} else {
			if (!(dbName in relationsBuffer)) relationsBuffer[dbName] = { relations: {} };
			relationsBuffer[dbName].relations[relationName] = relation;
		}
	}
	return {
		tables: tablesConfig,
		tableNamesMap
	};
}
function relations(table, relations) {
	return new Relations(table, (helpers) => Object.fromEntries(Object.entries(relations(helpers)).map(([key, value]) => [key, value.withFieldName(key)])));
}
function createOne(sourceTable) {
	return function one(table, config) {
		return new One(sourceTable, table, config, config?.fields.reduce((res, f) => res && f.notNull, true) ?? false);
	};
}
function createMany(sourceTable) {
	return function many(referencedTable, config) {
		return new Many(sourceTable, referencedTable, config);
	};
}
function normalizeRelation(schema, tableNamesMap, relation) {
	if (require_entity.is(relation, One) && relation.config) return {
		fields: relation.config.fields,
		references: relation.config.references
	};
	const referencedTableTsName = tableNamesMap[(0, __table_ts.getLegacyTableUniqueName)(relation.referencedTable)];
	if (!referencedTableTsName) throw new Error(`Table "${relation.referencedTable[__table_ts.Table.Symbol.Name]}" not found in schema`);
	const referencedTableConfig = schema[referencedTableTsName];
	if (!referencedTableConfig) throw new Error(`Table "${referencedTableTsName}" not found in schema`);
	const sourceTable = relation.sourceTable;
	const sourceTableTsName = tableNamesMap[(0, __table_ts.getLegacyTableUniqueName)(sourceTable)];
	if (!sourceTableTsName) throw new Error(`Table "${sourceTable[__table_ts.Table.Symbol.Name]}" not found in schema`);
	const reverseRelations = [];
	for (const referencedTableRelation of Object.values(referencedTableConfig.relations)) if (relation.relationName && relation !== referencedTableRelation && referencedTableRelation.relationName === relation.relationName || !relation.relationName && referencedTableRelation.referencedTable === relation.sourceTable) reverseRelations.push(referencedTableRelation);
	if (reverseRelations.length > 1) throw relation.relationName ? /* @__PURE__ */ new Error(`There are multiple relations with name "${relation.relationName}" in table "${referencedTableTsName}"`) : /* @__PURE__ */ new Error(`There are multiple relations between "${referencedTableTsName}" and "${relation.sourceTable[__table_ts.Table.Symbol.Name]}". Please specify relation name`);
	if (reverseRelations[0] && require_entity.is(reverseRelations[0], One) && reverseRelations[0].config) return {
		fields: reverseRelations[0].config.references,
		references: reverseRelations[0].config.fields
	};
	throw new Error(`There is not enough information to infer relation "${sourceTableTsName}.${relation.fieldName}"`);
}
function createTableRelationsHelpers(sourceTable) {
	return {
		one: createOne(sourceTable),
		many: createMany(sourceTable)
	};
}
function mapRelationalRow(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
	const result = {};
	for (const [selectionItemIndex, selectionItem] of buildQueryResultSelection.entries()) if (selectionItem.isJson) {
		const relation = tableConfig.relations[selectionItem.tsKey];
		const rawSubRows = row[selectionItemIndex];
		const subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
		result[selectionItem.tsKey] = require_entity.is(relation, One) ? subRows && mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRows, selectionItem.selection, mapColumnValue) : subRows.map((subRow) => mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRow, selectionItem.selection, mapColumnValue));
	} else {
		const value = mapColumnValue(row[selectionItemIndex]);
		const field = selectionItem.field;
		let decoder;
		if (require_entity.is(field, require_column.Column)) decoder = field;
		else if (require_entity.is(field, require_sql_sql.SQL)) decoder = field.decoder;
		else decoder = field.sql.decoder;
		result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
	}
	return result;
}
function mapRelationalRowFromObj(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
	const result = {};
	for (const [selectionItemIndex, selectionItem] of buildQueryResultSelection.entries()) if (selectionItem.isJson) {
		const relation = tableConfig.relations[selectionItem.tsKey];
		const isOne = require_entity.is(relation, One);
		const rawSubRows = row[selectionItemIndex];
		let subRows = rawSubRows;
		if (subRows || Array.isArray(subRows)) {
			subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
			subRows = isOne ? subRows.flatMap((r) => Array.isArray(r) ? r : Object.values(r)) : subRows.map((r) => Array.isArray(r) ? r : Object.values(r));
		}
		result[selectionItem.tsKey] = isOne ? subRows && mapRelationalRowFromObj(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRows, selectionItem.selection, mapColumnValue) : (subRows ?? []).map((subRow) => mapRelationalRowFromObj(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRow, selectionItem.selection, mapColumnValue));
	} else {
		const value = mapColumnValue(row[selectionItemIndex]);
		const field = selectionItem.field;
		let decoder;
		if (require_entity.is(field, require_column.Column)) decoder = field;
		else if (require_entity.is(field, require_sql_sql.SQL)) decoder = field.decoder;
		else decoder = field.sql.decoder;
		result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
	}
	return result;
}
//#endregion
exports.Many = Many;
exports.One = One;
exports.Relation = Relation;
exports.Relations = Relations;
exports.createMany = createMany;
exports.createOne = createOne;
exports.createTableRelationsHelpers = createTableRelationsHelpers;
exports.extractTablesRelationalConfig = extractTablesRelationalConfig;
exports.getOperators = getOperators;
exports.getOrderByOperators = getOrderByOperators;
exports.mapRelationalRow = mapRelationalRow;
exports.mapRelationalRowFromObj = mapRelationalRowFromObj;
exports.normalizeRelation = normalizeRelation;
exports.relations = relations;

//# sourceMappingURL=_relations.cjs.map