Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/entity.ts
const entityKind = Symbol.for("drizzle:entityKind");
const hasOwnEntityKind = Symbol.for("drizzle:hasOwnEntityKind");
const kindsByConstructor = /* @__PURE__ */ new WeakMap();
function collectKinds(ctor) {
	const kinds = /* @__PURE__ */ new Set();
	for (let cls = ctor; cls; cls = Object.getPrototypeOf(cls)) if (entityKind in cls) kinds.add(cls[entityKind]);
	kindsByConstructor.set(ctor, kinds);
	return kinds;
}
const nativeHasInstance = Function.prototype[Symbol.hasInstance];
function is(value, type) {
	if (nativeHasInstance.call(type, value)) return true;
	if (value === null || typeof value !== "object") return false;
	const ctor = Object.getPrototypeOf(value)?.constructor;
	if (typeof ctor !== "function") return false;
	return (kindsByConstructor.get(ctor) ?? collectKinds(ctor)).has(type[entityKind]);
}
function entityKindsOf(value) {
	if (value === null || typeof value !== "object") return void 0;
	const ctor = Object.getPrototypeOf(value)?.constructor;
	if (typeof ctor !== "function") return void 0;
	return kindsByConstructor.get(ctor) ?? collectKinds(ctor);
}
//#endregion
exports.entityKind = entityKind;
exports.entityKindsOf = entityKindsOf;
exports.hasOwnEntityKind = hasOwnEntityKind;
exports.is = is;

//# sourceMappingURL=entity.cjs.map