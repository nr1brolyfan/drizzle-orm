Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_libsql_driver_core = require("../driver-core.cjs");
let _libsql_client_http = require("@libsql/client/http");
//#region src/libsql/http/index.ts
/**
* Driver quirks:
* - With `intMode: 'number'` (the default), the client throws on integers past the safe integer range
*/
function drizzle(...params) {
	if (typeof params[0] === "string") {
		const instance = (0, _libsql_client_http.createClient)({ url: params[0] });
		return require_libsql_driver_core.construct(instance, params[1]);
	}
	const { connection, client, ...DrizzleSQLiteConfig } = params[0];
	if (client) return require_libsql_driver_core.construct(client, DrizzleSQLiteConfig);
	const instance = typeof connection === "string" ? (0, _libsql_client_http.createClient)({ url: connection }) : (0, _libsql_client_http.createClient)(connection);
	return require_libsql_driver_core.construct(instance, DrizzleSQLiteConfig);
}
(function(_drizzle) {
	function mock(config) {
		return require_libsql_driver_core.construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=index.cjs.map