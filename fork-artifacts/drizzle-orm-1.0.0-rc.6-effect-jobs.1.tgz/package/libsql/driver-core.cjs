Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_libsql_codecs = require("./codecs.cjs");
const require_libsql_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __sqlite_core_async_db_ts = require("../sqlite-core/async/db.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
//#region src/libsql/driver-core.ts
var LibSQLDatabase = class extends __sqlite_core_async_db_ts.SQLiteAsyncDatabase {
	static [__entity_ts.entityKind] = "LibSQLDatabase";
	async batch(batch) {
		return this.session.batch(batch);
	}
};
/** @internal */
function construct(client, config = {}) {
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({
		codecs: config.codecs ?? require_libsql_codecs.libsqlCodecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new LibSQLDatabase("async", dialect, new require_libsql_session.LibSQLSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}, void 0), relations);
	db.$client = client;
	return db;
}
//#endregion
exports.LibSQLDatabase = LibSQLDatabase;
exports.construct = construct;

//# sourceMappingURL=driver-core.cjs.map