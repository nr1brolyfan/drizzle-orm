Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __sqlite_core_codecs_ts = require("../sqlite-core/codecs.cjs");
//#region src/tursodatabase-sync/codecs.ts
const tursoDatabaseSyncCodecs = (0, __sqlite_core_codecs_ts.refineSqliteCodecs)({
	integer: { normalize: Number },
	"integer:boolean": { normalize: __sqlite_core_codecs_ts.booleanFromInteger },
	"integer:timestamp": { normalize: __sqlite_core_codecs_ts.dateFromStoredSeconds },
	"integer:timestamp_ms": { normalize: __sqlite_core_codecs_ts.dateFromStoredMilliseconds },
	real: { normalize: Number },
	"text:json": { normalize: JSON.parse },
	"blob:json": { normalize: __sqlite_core_codecs_ts.jsonFromBlob },
	"blob:bigint": { normalize: __sqlite_core_codecs_ts.bigintFromBlob },
	numeric: { normalize: String },
	"numeric:number": { normalize: Number },
	"numeric:bigint": { normalize: BigInt }
});
//#endregion
exports.tursoDatabaseSyncCodecs = tursoDatabaseSyncCodecs;

//# sourceMappingURL=codecs.cjs.map