Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_tursodatabase_sync_codecs = require("./codecs.cjs");
const require_tursodatabase_sync_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __sqlite_core_async_db_ts = require("../sqlite-core/async/db.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
let _tursodatabase_sync = require("@tursodatabase/sync");
//#region src/tursodatabase-sync/driver.ts
var TursoDatabaseSyncDatabase = class extends __sqlite_core_async_db_ts.SQLiteAsyncDatabase {
	static [__entity_ts.entityKind] = "TursoDatabaseSyncDatabase";
};
function construct(client, config = {}) {
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({
		codecs: config.codecs ?? require_tursodatabase_sync_codecs.tursoDatabaseSyncCodecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new TursoDatabaseSyncDatabase("async", dialect, new require_tursodatabase_sync_session.TursoDatabaseSyncSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(new _tursodatabase_sync.Database({ path: params[0] }), params[1]);
	const { connection, client, ...drizzleConfig } = params[0];
	if (client) return construct(client, drizzleConfig);
	return construct(typeof connection === "string" ? new _tursodatabase_sync.Database({ path: connection }) : new _tursodatabase_sync.Database(connection), drizzleConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.TursoDatabaseSyncDatabase = TursoDatabaseSyncDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map