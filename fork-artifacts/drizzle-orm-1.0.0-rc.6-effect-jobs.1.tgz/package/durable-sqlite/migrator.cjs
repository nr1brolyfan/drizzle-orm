Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_utils_ts = require("../migrator.utils.cjs");
let __runtime_sync_ts = require("../runtime/sync.cjs");
let __up_migrations_sqlite_program_ts = require("../up-migrations/sqlite-program.cjs");
let __up_migrations_sqlite_ts = require("../up-migrations/sqlite.cjs");
//#region src/durable-sqlite/migrator.ts
function migrate(db, config) {
	const migrations = (0, __migrator_utils_ts.readMigrationsFromRecord)(config.migrations);
	const runner = (0, __up_migrations_sqlite_ts.sqliteSyncMigrationRunner)(db.session, (statements) => db.transaction((tx) => {
		for (const statement of statements) tx.run(statement);
	}));
	return (0, __runtime_sync_ts.runSyncProgram)(() => (0, __up_migrations_sqlite_program_ts.migrate)(migrations, runner, { init: config.init }));
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map