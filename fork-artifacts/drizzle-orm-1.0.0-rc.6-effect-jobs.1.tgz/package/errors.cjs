Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("./entity.cjs");
//#region src/errors.ts
var DrizzleError = class extends Error {
	static [__entity_ts.entityKind] = "DrizzleError";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor({ message, cause }) {
		super(message);
		this.name = "DrizzleError";
		this.cause = cause;
	}
};
var DrizzleQueryError = class DrizzleQueryError extends Error {
	query;
	params;
	cause;
	static [__entity_ts.entityKind] = "DrizzleQueryError";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(query, params, cause) {
		super(params ? `Failed query: ${query}\nparams: ${params}` : `Failed query: ${query}`);
		this.query = query;
		this.params = params;
		this.cause = cause;
		this.name = "DrizzleQueryError";
		Error.captureStackTrace(this, DrizzleQueryError);
		if (cause) this.cause = cause;
	}
};
var TransactionRollbackError = class extends DrizzleError {
	static [__entity_ts.entityKind] = "TransactionRollbackError";
	constructor() {
		super({ message: "Rollback" });
		this.name = "TransactionRollbackError";
	}
};
//#endregion
exports.DrizzleError = DrizzleError;
exports.DrizzleQueryError = DrizzleQueryError;
exports.TransactionRollbackError = TransactionRollbackError;

//# sourceMappingURL=errors.cjs.map