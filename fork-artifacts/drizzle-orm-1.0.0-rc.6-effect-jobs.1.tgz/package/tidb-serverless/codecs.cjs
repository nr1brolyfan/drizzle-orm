Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __utils_ts = require("../utils.cjs");
let __mysql_core_codecs_ts = require("../mysql-core/codecs.cjs");
//#region src/tidb-serverless/codecs.ts
const bitStringFromBytes = (value) => {
	const str = new Array(value.length);
	for (let i = 0; i < value.length; ++i) str[i] = value[i] === 49 ? "1" : "0";
	return str.join("");
};
const tidbCodecs = (0, __mysql_core_codecs_ts.refineGenericMySqlCodecs)({
	serial: { normalize: Number },
	bigint: { normalize: BigInt },
	"bigint:number": { normalize: Number },
	"bigint:string": { normalize: String },
	boolean: { normalize: (value) => value === 1 },
	date: { normalize: (value) => new Date(value) },
	datetime: { normalize: (value) => /* @__PURE__ */ new Date(value.replace(" ", "T") + "Z") },
	timestamp: { normalize: (value) => /* @__PURE__ */ new Date(value + "+0000") },
	"decimal:number": { normalize: Number },
	"decimal:bigint": { normalize: BigInt },
	binary: { normalize: bitStringFromBytes },
	varbinary: { normalize: bitStringFromBytes },
	blob: { normalize: typeof Buffer === "undefined" ? __utils_ts.decodeUtf8 : (value) => Buffer.from(value).toString("utf8") },
	tinyblob: { normalize: typeof Buffer === "undefined" ? __utils_ts.decodeUtf8 : (value) => Buffer.from(value).toString("utf8") },
	mediumblob: { normalize: typeof Buffer === "undefined" ? __utils_ts.decodeUtf8 : (value) => Buffer.from(value).toString("utf8") },
	longblob: { normalize: typeof Buffer === "undefined" ? __utils_ts.decodeUtf8 : (value) => Buffer.from(value).toString("utf8") },
	"blob:buffer": { normalize: typeof Buffer === "undefined" ? void 0 : (value) => Buffer.from(value) },
	"tinyblob:buffer": { normalize: typeof Buffer === "undefined" ? void 0 : (value) => Buffer.from(value) },
	"mediumblob:buffer": { normalize: typeof Buffer === "undefined" ? void 0 : (value) => Buffer.from(value) },
	"longblob:buffer": { normalize: typeof Buffer === "undefined" ? void 0 : (value) => Buffer.from(value) }
});
//#endregion
exports.tidbCodecs = tidbCodecs;

//# sourceMappingURL=codecs.cjs.map