Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_tidb_serverless_codecs = require("./codecs.cjs");
const require_tidb_serverless_session = require("./session.cjs");
const require_tidb_serverless_driver = require("./driver.cjs");
exports.TiDBServerlessDatabase = require_tidb_serverless_driver.TiDBServerlessDatabase;
exports.TiDBServerlessSession = require_tidb_serverless_session.TiDBServerlessSession;
exports.TiDBServerlessTransaction = require_tidb_serverless_session.TiDBServerlessTransaction;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return require_tidb_serverless_driver.drizzle;
	}
});
exports.tidbCodecs = require_tidb_serverless_codecs.tidbCodecs;
exports.tidbRawTextDecoders = require_tidb_serverless_session.tidbRawTextDecoders;
