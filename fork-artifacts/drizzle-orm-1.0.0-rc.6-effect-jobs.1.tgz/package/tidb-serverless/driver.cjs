Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_tidb_serverless_codecs = require("./codecs.cjs");
const require_tidb_serverless_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __mysql_core_async_db_ts = require("../mysql-core/async/db.cjs");
let __mysql_core_dialect_ts = require("../mysql-core/dialect.cjs");
let _tidbcloud_serverless = require("@tidbcloud/serverless");
//#region src/tidb-serverless/driver.ts
var TiDBServerlessDatabase = class extends __mysql_core_async_db_ts.MySqlAsyncDatabase {
	static [__entity_ts.entityKind] = "TiDBServerlessDatabase";
};
function construct(client, config = {}) {
	const dialect = new __mysql_core_dialect_ts.MySqlDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_tidb_serverless_codecs.tidbCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new TiDBServerlessDatabase(dialect, new require_tidb_serverless_session.TiDBServerlessSession(client, dialect, void 0, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
function drizzle(...params) {
	if (typeof params[0] === "string") return construct((0, _tidbcloud_serverless.connect)({ url: params[0] }), params[1]);
	const { connection, client, ...DrizzleMySqlConfig } = params[0];
	if (client) return construct(client, DrizzleMySqlConfig);
	return construct(typeof connection === "string" ? (0, _tidbcloud_serverless.connect)({ url: connection }) : (0, _tidbcloud_serverless.connect)(connection), DrizzleMySqlConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.TiDBServerlessDatabase = TiDBServerlessDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map