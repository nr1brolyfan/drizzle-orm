Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_planetscale_serverless_codecs = require("./codecs.cjs");
const require_planetscale_serverless_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __mysql_core_async_db_ts = require("../mysql-core/async/db.cjs");
let __mysql_core_dialect_ts = require("../mysql-core/dialect.cjs");
let _planetscale_database = require("@planetscale/database");
//#region src/planetscale-serverless/driver.ts
var PlanetScaleDatabase = class extends __mysql_core_async_db_ts.MySqlAsyncDatabase {
	static [__entity_ts.entityKind] = "PlanetScaleDatabase";
};
function construct(client, config = {}) {
	if (!(client instanceof _planetscale_database.Client)) throw new Error(`Warning: You need to pass an instance of Client:

import { Client } from "@planetscale/database";

const client = new Client({
  host: process.env["DATABASE_HOST"],
  username: process.env["DATABASE_USERNAME"],
  password: process.env["DATABASE_PASSWORD"],
});

const db = drizzle({ client });
		`);
	const dialect = new __mysql_core_dialect_ts.MySqlDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_planetscale_serverless_codecs.planetscaleServerlessCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new PlanetScaleDatabase(dialect, new require_planetscale_serverless_session.PlanetscaleSession(client, dialect, void 0, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
/**
* Driver quirks:
* - `float` values are rounded to 6 significant digits by MySQL's text protocol
*/
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(new _planetscale_database.Client({ url: params[0] }), params[1]);
	const { connection, client, ...DrizzleMySqlConfig } = params[0];
	if (client) return construct(client, DrizzleMySqlConfig);
	return construct(typeof connection === "string" ? new _planetscale_database.Client({ url: connection }) : new _planetscale_database.Client(connection), DrizzleMySqlConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.PlanetScaleDatabase = PlanetScaleDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map