Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
const require_effect_libsql_codecs = require("./codecs.cjs");
const require_effect_libsql_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __effect_core_index_ts = require("../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../effect-core/defaults.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
let _effect_sql_libsql_LibsqlClient = require("@effect/sql-libsql/LibsqlClient");
let __sqlite_core_effect_db_ts = require("../sqlite-core/effect/db.cjs");
//#region src/effect-libsql/driver.ts
var EffectLibsqlDatabase = class extends __sqlite_core_effect_db_ts.SQLiteEffectDatabase {
	static [__entity_ts.entityKind] = "EffectLibsqlDatabase";
};
/**
* Creates an EffectLibsqlDatabase instance.
*
* Requires `LibsqlClient`, and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* @example
* ```ts
* // With default services (no logging, no caching)
* const db = yield* LibsqlDrizzle.make({ relations }).pipe(
*   Effect.provide(LibsqlDrizzle.DefaultServices),
* );
*
* // With Effect-based logging
* const db = yield* LibsqlDrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layer),
*   Effect.provide(LibsqlDrizzle.DefaultServices),
* );
*
* // With custom Drizzle logger
* const db = yield* LibsqlDrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layerFromDrizzle(myLogger)),
*   Effect.provide(LibsqlDrizzle.DefaultServices),
* );
* ```
*
* Driver quirks:
* - With `intMode: 'number'` (the default), the client throws on integers past the safe integer range
*/
const make = effect_Effect.fn("LibsqlDrizzle.make")(function* (config = {}) {
	const client = yield* _effect_sql_libsql_LibsqlClient.LibsqlClient;
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({
		codecs: config.codecs ?? require_effect_libsql_codecs.effectLibsqlCodecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit)
	});
	const relations = config.relations ?? {};
	const db = new EffectLibsqlDatabase(dialect, new require_effect_libsql_session.EffectLibsqlSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
});
/**
* Convenience function that creates an EffectLibsqlDatabase with `DefaultServices` already provided.
*/
const makeWithDefaults = (config = {}) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectLibsqlDatabase = EffectLibsqlDatabase;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map