Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
const require_effect_d1_codecs = require("./codecs.cjs");
const require_effect_d1_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __effect_core_index_ts = require("../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../effect-core/defaults.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
let __sqlite_core_effect_db_ts = require("../sqlite-core/effect/db.cjs");
let _effect_sql_d1_D1Client = require("@effect/sql-d1/D1Client");
//#region src/effect-d1/driver.ts
var EffectSQLiteD1Database = class extends __sqlite_core_effect_db_ts.SQLiteEffectDatabase {
	static [__entity_ts.entityKind] = "EffectSQLiteD1Database";
};
/**
* Creates an EffectSQLiteD1Database instance.
*
* Requires `D1Client`, and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* @example
* ```ts
* // With default services (no logging, no caching)
* const db = yield* SQLiteD1Drizzle.make({ relations }).pipe(
*   Effect.provide(SQLiteD1Drizzle.DefaultServices),
* );
*
* // With Effect-based logging
* const db = yield* SQLiteD1Drizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layer),
*   Effect.provide(SQLiteD1Drizzle.DefaultServices),
* );
*
* // With custom Drizzle logger
* const db = yield* SQLiteD1Drizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layerFromDrizzle(myLogger)),
*   Effect.provide(SQLiteD1Drizzle.DefaultServices),
* );
* ```
*
* Driver quirks:
* - Integers past the safe integer range are read as numbers: `numeric` columns throw on them
*/
const make = effect_Effect.fn("SQLiteD1Drizzle.make")(function* (config) {
	const client = yield* _effect_sql_d1_D1Client.D1Client;
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({ codecs: config.codecs ?? require_effect_d1_codecs.effectD1Codecs });
	const relations = config.relations ?? {};
	const db = new EffectSQLiteD1Database(dialect, new require_effect_d1_session.EffectSQLiteD1Session(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations, true);
	db.$client = client;
	return db;
});
/**
* Convenience function that creates an EffectSQLiteD1Database with `DefaultServices` already provided.
*/
const makeWithDefaults = (config) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectSQLiteD1Database = EffectSQLiteD1Database;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map