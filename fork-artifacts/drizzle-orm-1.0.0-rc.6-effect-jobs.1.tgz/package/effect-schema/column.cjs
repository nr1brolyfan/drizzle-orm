Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_utils = require("../utils.cjs");
let __table_ts = require("../table.cjs");
let __column_ts = require("../column.cjs");
let __column_builder_ts = require("../column-builder.cjs");
let effect = require("effect");
//#region src/effect-schema/column.ts
const literalSchema = effect.Schema.Union([
	effect.Schema.String,
	effect.Schema.Number,
	effect.Schema.Boolean,
	effect.Schema.Null
]);
const jsonSchema = effect.Schema.Union([
	literalSchema,
	effect.Schema.Record(effect.Schema.String, effect.Schema.Any),
	effect.Schema.Array(effect.Schema.Any)
]);
const bufferSchema = typeof Buffer === "undefined" ? effect.Schema.Unknown : effect.Schema.instanceOf(Buffer);
function columnToSchema(column) {
	let schema;
	const dimensions = column.dimensions;
	if (typeof dimensions === "number" && dimensions > 0) return pgArrayColumnToSchema(column, dimensions);
	const { type, constraint } = (0, __column_builder_ts.extractExtendedColumnType)(column);
	switch (type) {
		case "array":
			schema = arrayColumnToSchema(column, constraint);
			break;
		case "object":
			schema = objectColumnToSchema(column, constraint);
			break;
		case "number":
			schema = numberColumnToSchema(column, constraint);
			break;
		case "bigint":
			schema = bigintColumnToSchema(column, constraint);
			break;
		case "boolean":
			schema = effect.Schema.Boolean;
			break;
		case "string":
			schema = stringColumnToSchema(column, constraint);
			break;
		case "custom":
			schema = effect.Schema.Any;
			break;
		default: schema = effect.Schema.Any;
	}
	return schema;
}
function numberColumnToSchema(column, constraint) {
	let min;
	let max;
	let integer = false;
	switch (constraint) {
		case "int8":
			min = require_utils.CONSTANTS.INT8_MIN;
			max = require_utils.CONSTANTS.INT8_MAX;
			integer = true;
			break;
		case "uint8":
			min = 0;
			max = require_utils.CONSTANTS.INT8_UNSIGNED_MAX;
			integer = true;
			break;
		case "int16":
			min = require_utils.CONSTANTS.INT16_MIN;
			max = require_utils.CONSTANTS.INT16_MAX;
			integer = true;
			break;
		case "uint16":
			min = 0;
			max = require_utils.CONSTANTS.INT16_UNSIGNED_MAX;
			integer = true;
			break;
		case "int24":
			min = require_utils.CONSTANTS.INT24_MIN;
			max = require_utils.CONSTANTS.INT24_MAX;
			integer = true;
			break;
		case "uint24":
			min = 0;
			max = require_utils.CONSTANTS.INT24_UNSIGNED_MAX;
			integer = true;
			break;
		case "int32":
			min = require_utils.CONSTANTS.INT32_MIN;
			max = require_utils.CONSTANTS.INT32_MAX;
			integer = true;
			break;
		case "uint32":
			min = 0;
			max = require_utils.CONSTANTS.INT32_UNSIGNED_MAX;
			integer = true;
			break;
		case "int53":
			min = Number.MIN_SAFE_INTEGER;
			max = Number.MAX_SAFE_INTEGER;
			integer = true;
			break;
		case "uint53":
			min = 0;
			max = Number.MAX_SAFE_INTEGER;
			integer = true;
			break;
		case "float":
			min = require_utils.CONSTANTS.INT24_MIN;
			max = require_utils.CONSTANTS.INT24_MAX;
			break;
		case "ufloat":
			min = 0;
			max = require_utils.CONSTANTS.INT24_UNSIGNED_MAX;
			break;
		case "double":
			min = require_utils.CONSTANTS.INT48_MIN;
			max = require_utils.CONSTANTS.INT48_MAX;
			break;
		case "udouble":
			min = 0;
			max = require_utils.CONSTANTS.INT48_UNSIGNED_MAX;
			break;
		case "year":
			min = 1901;
			max = 2155;
			integer = true;
			break;
		case "unsigned":
			min = 0;
			max = Number.MAX_SAFE_INTEGER;
			break;
		default:
			min = Number.MIN_SAFE_INTEGER;
			max = Number.MAX_SAFE_INTEGER;
	}
	let schema = integer ? effect.Schema.Int : effect.Schema.Number;
	schema = schema.check(effect.Schema.isGreaterThanOrEqualTo(min), effect.Schema.isLessThanOrEqualTo(max));
	return schema;
}
const bigintStringModeSchema = effect.Schema.BigInt.check(effect.Schema.isGreaterThanOrEqualToBigInt(require_utils.CONSTANTS.INT64_MIN), effect.Schema.isLessThanOrEqualToBigInt(require_utils.CONSTANTS.INT64_MAX));
const unsignedBigintStringModeSchema = effect.Schema.BigInt.check(effect.Schema.isGreaterThanOrEqualToBigInt(0n), effect.Schema.isLessThanOrEqualToBigInt(require_utils.CONSTANTS.INT64_UNSIGNED_MAX));
function bigintColumnToSchema(column, constraint) {
	let min;
	let max;
	switch (constraint) {
		case "int64":
			min = require_utils.CONSTANTS.INT64_MIN;
			max = require_utils.CONSTANTS.INT64_MAX;
			break;
		case "uint64":
			min = 0n;
			max = require_utils.CONSTANTS.INT64_UNSIGNED_MAX;
	}
	let schema = effect.Schema.BigInt;
	if (min !== void 0) schema = schema.check(effect.Schema.isGreaterThanOrEqualToBigInt(min));
	if (max !== void 0) schema = schema.check(effect.Schema.isLessThanOrEqualToBigInt(max));
	return schema;
}
function pgArrayColumnToSchema(column, dimensions) {
	const [baseType, baseConstraint] = column.dataType.split(" ");
	let baseSchema;
	switch (baseType) {
		case "number":
			baseSchema = numberColumnToSchema(column, baseConstraint);
			break;
		case "bigint":
			baseSchema = bigintColumnToSchema(column, baseConstraint);
			break;
		case "boolean":
			baseSchema = effect.Schema.Boolean;
			break;
		case "string":
			baseSchema = stringColumnToSchema(column, baseConstraint);
			break;
		case "object":
			baseSchema = objectColumnToSchema(column, baseConstraint);
			break;
		case "array":
			baseSchema = arrayColumnToSchema(column, baseConstraint);
			break;
		default: baseSchema = effect.Schema.Any;
	}
	let schema = effect.Schema.Array(baseSchema);
	for (let i = 1; i < dimensions; i++) schema = effect.Schema.Array(schema);
	return schema;
}
function arrayColumnToSchema(column, constraint) {
	switch (constraint) {
		case "geometry":
		case "point": return effect.Schema.Tuple([effect.Schema.Number, effect.Schema.Number]);
		case "line": return effect.Schema.Tuple([
			effect.Schema.Number,
			effect.Schema.Number,
			effect.Schema.Number
		]);
		case "vector":
		case "halfvector": {
			const length = column.length;
			const schema = effect.Schema.Array(effect.Schema.Number);
			return length ? schema.check(effect.Schema.isBetweenLength(length, length)) : schema;
		}
		case "int64vector": {
			const length = column.length;
			const schema = effect.Schema.Array(effect.Schema.BigInt.check(effect.Schema.isGreaterThanOrEqualToBigInt(require_utils.CONSTANTS.INT64_MIN), effect.Schema.isLessThanOrEqualToBigInt(require_utils.CONSTANTS.INT64_MAX)));
			return length ? schema.check(effect.Schema.isBetweenLength(length, length)) : schema;
		}
		default: return effect.Schema.Array(effect.Schema.Any);
	}
}
function objectColumnToSchema(column, constraint) {
	switch (constraint) {
		case "buffer": return bufferSchema;
		case "date": return effect.Schema.Date;
		case "geometry":
		case "point": return effect.Schema.Struct({
			x: effect.Schema.Number,
			y: effect.Schema.Number
		});
		case "json": return jsonSchema;
		case "line": return effect.Schema.Struct({
			a: effect.Schema.Number,
			b: effect.Schema.Number,
			c: effect.Schema.Number
		});
		default: return effect.Schema.ObjectKeyword;
	}
}
function stringColumnToSchema(column, constraint) {
	const { name: columnName, length, isLengthExact } = column;
	let regex;
	if (constraint === "binary") regex = /^[01]*$/;
	if (constraint === "uuid") return effect.Schema.String.check(effect.Schema.isUUID());
	if (constraint === "enum") {
		const enumValues = column.enumValues;
		if (!enumValues) throw new Error(`Column "${(0, __table_ts.getTableName)((0, __column_ts.getColumnTable)(column))}"."${columnName}" is of 'enum' type, but lacks enum values`);
		return effect.Schema.Literals(enumValues);
	}
	if (constraint === "int64") return bigintStringModeSchema;
	if (constraint === "uint64") return unsignedBigintStringModeSchema;
	let schema = effect.Schema.String;
	schema = regex ? schema.check(effect.Schema.isPattern(regex)) : schema;
	return length && isLengthExact ? schema.check(effect.Schema.isBetweenLength(length, length)) : length ? schema.check(effect.Schema.isMaxLength(length)) : schema;
}
//#endregion
exports.bigintStringModeSchema = bigintStringModeSchema;
exports.bufferSchema = bufferSchema;
exports.columnToSchema = columnToSchema;
exports.jsonSchema = jsonSchema;
exports.literalSchema = literalSchema;
exports.unsignedBigintStringModeSchema = unsignedBigintStringModeSchema;

//# sourceMappingURL=column.cjs.map