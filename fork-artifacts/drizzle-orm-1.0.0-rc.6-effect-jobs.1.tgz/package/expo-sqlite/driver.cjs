Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_expo_sqlite_codecs = require("./codecs.cjs");
const require_expo_sqlite_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __sqlite_core_async_db_ts = require("../sqlite-core/async/db.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
//#region src/expo-sqlite/driver.ts
var ExpoSQLiteDatabase = class extends __sqlite_core_async_db_ts.SQLiteAsyncDatabase {
	static [__entity_ts.entityKind] = "ExpoSQLiteDatabase";
};
/**
* Driver quirks:
* - Integers past the safe integer range are read as numbers: `numeric` columns throw on them
*/
function drizzle(client, config = {}) {
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({
		codecs: config.codecs ?? require_expo_sqlite_codecs.expoSQLiteCodecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new ExpoSQLiteDatabase("sync", dialect, new require_expo_sqlite_session.ExpoSQLiteSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
//#endregion
exports.ExpoSQLiteDatabase = ExpoSQLiteDatabase;
exports.drizzle = drizzle;

//# sourceMappingURL=driver.cjs.map