Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_expo_sqlite_codecs = require("../codecs.cjs");
exports.expoSQLiteCodecs = require_expo_sqlite_codecs.expoSQLiteCodecs;
