Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
const require_effect_sqlite_do_codecs = require("./codecs.cjs");
const require_effect_sqlite_do_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __effect_core_index_ts = require("../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../effect-core/defaults.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
let __sqlite_core_effect_db_ts = require("../sqlite-core/effect/db.cjs");
let _effect_sql_sqlite_do_SqliteClient = require("@effect/sql-sqlite-do/SqliteClient");
//#region src/effect-sqlite-do/driver.ts
var EffectSQLiteDoDatabase = class extends __sqlite_core_effect_db_ts.SQLiteEffectDatabase {
	static [__entity_ts.entityKind] = "EffectSQLiteDoDatabase";
};
/**
* Creates an EffectSQLiteDoDatabase instance.
*
* Requires `SqliteClient`, and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* @example
* ```ts
* // With default services (no logging, no caching)
* const db = yield* SQLiteDODrizzle.make({ relations }).pipe(
*   Effect.provide(SQLiteDODrizzle.DefaultServices),
* );
*
* // With Effect-based logging
* const db = yield* SQLiteDODrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layer),
*   Effect.provide(SQLiteDODrizzle.DefaultServices),
* );
*
* // With custom Drizzle logger
* const db = yield* SQLiteDODrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layerFromDrizzle(myLogger)),
*   Effect.provide(SQLiteDODrizzle.DefaultServices),
* );
* ```
*
* Driver quirks:
* - Integers past the safe integer range are read as numbers: `numeric` columns throw on them
*/
const make = effect_Effect.fn("SQLiteDODrizzle.make")(function* (config) {
	const client = yield* _effect_sql_sqlite_do_SqliteClient.SqliteClient;
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({ codecs: config.codecs ?? require_effect_sqlite_do_codecs.effectSQLiteDoCodecs });
	const relations = config.relations ?? {};
	const db = new EffectSQLiteDoDatabase(dialect, new require_effect_sqlite_do_session.EffectSQLiteDOSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
});
/**
* Convenience function that creates an EffectSQLiteDoDatabase with `DefaultServices` already provided.
*/
const makeWithDefaults = (config) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectSQLiteDoDatabase = EffectSQLiteDoDatabase;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map