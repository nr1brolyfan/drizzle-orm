Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_bun_sql_mysql_codecs = require("./codecs.cjs");
const require_bun_sql_mysql_session = require("./session.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __logger_ts = require("../../logger.cjs");
let __mysql_core_async_db_ts = require("../../mysql-core/async/db.cjs");
let __mysql_core_dialect_ts = require("../../mysql-core/dialect.cjs");
let bun = require("bun");
//#region src/bun-sql/mysql/driver.ts
var BunMySqlDatabase = class extends __mysql_core_async_db_ts.MySqlAsyncDatabase {
	static [__entity_ts.entityKind] = "BunMySqlDatabase";
};
function construct(client, config = {}) {
	const dialect = new __mysql_core_dialect_ts.MySqlDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_bun_sql_mysql_codecs.bunSqlMySqlCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new BunMySqlDatabase(dialect, new require_bun_sql_mysql_session.BunMySqlSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
/**
* Driver quirks:
* - `float` values are rounded to 6 significant digits in queries without bound parameters, which Bun sends through
*   MySQL's text protocol; queries with parameters use prepared statements, which keep the full value
* - `datetime`, `timestamp` in `string` mode lose microseconds
*/
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(new bun.SQL(params[0]), params[1]);
	const { connection, client, ...drizzleConfig } = params[0];
	if (client) return construct(client, drizzleConfig);
	if (typeof connection === "object" && connection.url !== void 0) {
		const { url, ...config } = connection;
		return construct(new bun.SQL({
			url,
			...config
		}), drizzleConfig);
	}
	return construct(new bun.SQL(connection), drizzleConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.BunMySqlDatabase = BunMySqlDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map