Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __mysql_core_codecs_ts = require("../../mysql-core/codecs.cjs");
//#region src/bun-sql/mysql/codecs.ts
/** `YYYY-MM-DD` of a `date` the driver decoded to UTC midnight */
const dateTextFromUtc = (value) => `${String(value.getUTCFullYear()).padStart(4, "0")}-${String(value.getUTCMonth() + 1).padStart(2, "0")}-${String(value.getUTCDate()).padStart(2, "0")}`;
const bunSqlMySqlCodecs = (0, __mysql_core_codecs_ts.refineGenericMySqlCodecs)({
	serial: { normalize: Number },
	bigint: { normalize: BigInt },
	"bigint:number": { normalize: Number },
	"bigint:string": { normalize: String },
	boolean: { normalize: (value) => value === 1 },
	"date:string": { normalize: dateTextFromUtc },
	"datetime:string": { normalize: __mysql_core_codecs_ts.mysqlDatetimeTextFromUtcDate },
	"timestamp:string": { normalize: __mysql_core_codecs_ts.mysqlDatetimeTextFromUtcDate },
	"decimal:number": { normalize: Number },
	"decimal:bigint": { normalize: BigInt },
	float: { normalize: __mysql_core_codecs_ts.floatFromDouble },
	binary: { normalize: (value) => value.toString() },
	varbinary: { normalize: (value) => value.toString() },
	blob: { normalize: (value) => value.toString("utf8") },
	tinyblob: { normalize: (value) => value.toString("utf8") },
	mediumblob: { normalize: (value) => value.toString("utf8") },
	longblob: { normalize: (value) => value.toString("utf8") }
});
//#endregion
exports.bunSqlMySqlCodecs = bunSqlMySqlCodecs;

//# sourceMappingURL=codecs.cjs.map