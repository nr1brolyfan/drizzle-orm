Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_ts = require("../../migrator.cjs");
let __mysql_core_async_session_ts = require("../../mysql-core/async/session.cjs");
//#region src/bun-sql/mysql/migrator.ts
async function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	return (0, __mysql_core_async_session_ts.migrate)(migrations, db, config);
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map