Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_ts = require("../../migrator.cjs");
let __sqlite_core_async_session_ts = require("../../sqlite-core/async/session.cjs");
//#region src/bun-sql/sqlite/migrator.ts
async function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	return await (0, __sqlite_core_async_session_ts.migrateAsync)(migrations, db, config);
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map