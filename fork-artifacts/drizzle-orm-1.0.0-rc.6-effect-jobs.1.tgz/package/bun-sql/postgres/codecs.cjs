Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __codecs_ts = require("../../codecs.cjs");
let __pg_core_array_ts = require("../../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../../pg-core/codecs.cjs");
//#region src/bun-sql/postgres/codecs.ts
/** `sql.json(value)` for bun < v1.4.4 */
var BunSqlJsonParam = class {
	value;
	static [__entity_ts.entityKind] = "BunSqlJsonParam";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(value) {
		this.value = value;
	}
	toJSON(key) {
		const value = this.value;
		return typeof value?.toJSON === "function" ? value.toJSON(key) : value;
	}
};
const makeJsonParamNormalizer = (client) => typeof client.json === "function" ? (value) => client.json(value) : client.options.prepare === false ? (value) => JSON.stringify(value) : (value) => new BunSqlJsonParam(value);
const driver = "bun-sql";
const invalidDate = /* @__PURE__ */ new Date(NaN);
const dateFromBun = (value) => value === Infinity || value === -Infinity ? invalidDate : value;
const timeZoneReason = "the driver decodes `timestamptz` values to `Date`s, dropping the offset the server formats in the session's time zone, and accepts no per-query parsers";
const timestampText = (0, __pg_core_codecs_ts.pgTimestampTextFromUtcDate)(false);
const dateTextFromBun = (value) => value === Infinity ? "infinity" : value === -Infinity ? "-infinity" : (0, __pg_core_codecs_ts.pgDateTextFromUtcDate)(value);
/** JSON param marker exists only on client and isn't importable outside of it */
const bunSqlPgCodecs = (client) => {
	const normalizeJsonParam = makeJsonParamNormalizer(client);
	return (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
		date: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: dateFromBun,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(dateFromBun)
		},
		"date:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: dateTextFromBun,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(dateTextFromBun)
		},
		uuid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		timestamp: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: dateFromBun,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(dateFromBun)
		},
		timestamptz: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: dateFromBun,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(dateFromBun)
		},
		"timestamp:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: timestampText,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(timestampText)
		},
		"timestamptz:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timeZoneReason),
			normalizeArray: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timeZoneReason)
		},
		float4: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: __pg_core_codecs_ts.shortestFloat32,
			normalizeArray: __pg_core_codecs_ts.shortestFloat32Array
		},
		bigint: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: BigInt,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
		},
		"bigint:number": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: Number,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
		},
		"bigint:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: String,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(String)
		},
		bigserial: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: BigInt,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
		},
		"bigserial:number": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: Number,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
		},
		int: {
			normalizeArray: (value, dimensions) => {
				if (value instanceof Int32Array) return Array.from(value);
				if (dimensions <= 1) return value;
				const stack = [{
					arr: value,
					depth: 1
				}];
				while (stack.length > 0) {
					const { arr, depth } = stack.pop();
					if (depth === dimensions - 1) for (let i = 0; i < arr.length; i++) {
						const leaf = arr[i];
						if (leaf instanceof Int32Array) arr[i] = Array.from(leaf);
					}
					else for (let i = 0; i < arr.length; i++) stack.push({
						arr: arr[i],
						depth: depth + 1
					});
				}
				return value;
			},
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		bit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		bool: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		box: { normalizeParamArray: __pg_core_codecs_ts.makeBoxArray },
		box2d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		box3d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		char: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		cidr: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		circle: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		datemultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		daterange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		float8: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		"geography(point)": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
		"geography(point):tuple": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
		inet: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int4multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int4range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int8multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int8range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		lseg: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		macaddr: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		money: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		nummultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		numrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		oid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		path: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		polygon: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		raster: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regclass: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regconfig: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regdictionary: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regnamespace: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regoper: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regoperator: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regproc: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regprocedure: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regrole: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regtype: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		serial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		smallint: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		smallserial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		text: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		time: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		timetz: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsquery: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tstzmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tstzrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsvector: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		varbit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		varchar: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		xml: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		bytea: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		enum: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
		},
		json: {
			normalizeParam: normalizeJsonParam,
			normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
		},
		jsonb: {
			normalizeParam: normalizeJsonParam,
			normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
		},
		"geometry(point)": {
			normalize: __pg_core_codecs_ts.parseGeometryXY,
			normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryXY),
			normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
		},
		"geometry(point):tuple": {
			normalize: __pg_core_codecs_ts.parseGeometryTuple,
			normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryTuple),
			normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
		},
		interval: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		line: {
			normalize: __pg_core_codecs_ts.parseLineABC,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineABC),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		"line:tuple": {
			normalize: __pg_core_codecs_ts.parseLineTuple,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineTuple),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		macaddr8: {
			castArrayInJson: __pg_core_codecs_ts.castToTextArr,
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		numeric: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		"numeric:number": {
			normalize: Number,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		"numeric:bigint": {
			normalize: BigInt,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		point: {
			normalize: __pg_core_codecs_ts.parsePointXY,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointXY),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		"point:tuple": {
			normalize: __pg_core_codecs_ts.parsePointTuple,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointTuple),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		halfvec: {
			normalize: __pg_core_codecs_ts.parsePgVector,
			normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		sparsevec: {
			normalizeArray: (v) => (0, __pg_core_array_ts.parsePgArray)(v),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		vector: {
			normalize: __pg_core_codecs_ts.parsePgVector,
			normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		}
	});
};
//#endregion
exports.BunSqlJsonParam = BunSqlJsonParam;
exports.bunSqlPgCodecs = bunSqlPgCodecs;

//# sourceMappingURL=codecs.cjs.map