Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __tracing_ts = require("../tracing.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
//#region src/runtime/core.ts
const tracedSpan = (name, attributes, body) => __tracing_ts.tracer.startActiveSpan(name, (span) => {
	if (attributes) span?.setAttributes(attributes);
	return body();
});
/** Runs `body` in `runtime`'s tracing span, or just runs it on an untraced runtime */
function withSpan(runtime, name, attributes, body) {
	return runtime.span ? runtime.span(name, attributes, body) : body();
}
/** Runtime-agnostic query execution flow */
function executePreparedQuery(runtime, query, logger, paramsInErrors, placeholderValues, run, mapRows) {
	return runtime.suspend(() => {
		const sql = query._sql ? query._sql.join(" ") : query.sql;
		const params = query.params.length === 0 ? query.params : (0, __sql_sql_ts.fillPlaceholders)(query.params, placeholderValues ?? {});
		const onError = (e) => runtime.queryError(sql, paramsInErrors ? params : void 0, e);
		const span = runtime.span;
		if (!span) return runtime.chain(runtime.detach(() => logger.logQuery(sql, params)), () => {
			const rows = runtime.attempt(() => run(params), onError);
			return mapRows ? runtime.chain(rows, mapRows) : rows;
		});
		const attributes = {
			"drizzle.query.text": sql,
			"drizzle.query.params": JSON.stringify(params)
		};
		return span("drizzle.execute", attributes, () => runtime.chain(runtime.detach(() => logger.logQuery(sql, params)), () => {
			const rows = span("drizzle.driver.execute", attributes, () => runtime.attempt(() => run(params), onError));
			if (!mapRows) return rows;
			return runtime.chain(rows, (rows) => span("drizzle.mapResponse", void 0, () => runtime.suspend(() => mapRows(rows))));
		}));
	});
}
/** Waits for `value` in a {@link QueryProgram}: a plain value or Promise for async and sync runtimes, an Effect for the Effect one */
function* perform(value) {
	return yield value;
}
/** Runs the program `body` creates on `runtime`, returning what the runtime runs */
function runProgram(runtime, body) {
	return runtime.suspend(() => {
		const program = body();
		const step = (input) => {
			const next = program.next(input);
			return next.done ? next.value : runtime.chain(next.value, step);
		};
		return step();
	});
}
//#endregion
exports.executePreparedQuery = executePreparedQuery;
exports.perform = perform;
exports.runProgram = runProgram;
exports.tracedSpan = tracedSpan;
exports.withSpan = withSpan;

//# sourceMappingURL=core.cjs.map