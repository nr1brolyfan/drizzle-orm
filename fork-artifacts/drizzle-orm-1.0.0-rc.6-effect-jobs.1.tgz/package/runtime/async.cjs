Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime_core = require("./core.cjs");
let __tracing_ts = require("../tracing.cjs");
let __errors_ts = require("../errors.cjs");
//#region src/runtime/async.ts
const isThenable = (value) => value !== null && typeof value === "object" && typeof value.then === "function";
const asyncQueryRuntime = {
	suspend(body) {
		try {
			return body();
		} catch (e) {
			return Promise.reject(e);
		}
	},
	chain: (first, next) => isThenable(first) ? first.then(next) : next(first),
	detach: (work) => {
		work();
	},
	attempt(run, onError) {
		let query;
		try {
			query = run();
		} catch (e) {
			return Promise.reject(onError(e));
		}
		return query.then(void 0, (e) => {
			throw onError(e);
		});
	},
	queryError: (query, params, cause) => new __errors_ts.DrizzleQueryError(query, params, cause)
};
const tracedAsyncQueryRuntime = {
	...asyncQueryRuntime,
	span: __tracing_ts.hasTelemetry ? require_runtime_core.tracedSpan : void 0
};
const runAsyncProgram = (body) => Promise.resolve(require_runtime_core.runProgram(asyncQueryRuntime, body));
function asyncMigrationRunner(session, atomically) {
	return {
		execute: (query) => session.execute(query),
		objects: (query) => session.objects(query),
		atomically: atomically ?? (async (statements) => {
			await session.transaction(async (tx) => {
				for (const statement of statements) await tx.execute(statement);
			});
		})
	};
}
//#endregion
exports.asyncMigrationRunner = asyncMigrationRunner;
exports.asyncQueryRuntime = asyncQueryRuntime;
exports.runAsyncProgram = runAsyncProgram;
exports.tracedAsyncQueryRuntime = tracedAsyncQueryRuntime;

//# sourceMappingURL=async.cjs.map