Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
const require_runtime_core = require("./core.cjs");
let __tracing_ts = require("../tracing.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let effect_Cause = require("effect/Cause");
effect_Cause = require_runtime.__toESM(effect_Cause, 1);
let __effect_core_errors_ts = require("../effect-core/errors.cjs");
//#region src/runtime/effect.ts
/** A plain value returned where an Effect is expected, as {@link QueryRuntime}'s `suspend` and `andThen` allow */
const lift = (value) => effect_Effect.isEffect(value) ? value : effect_Effect.succeed(value);
const effectQueryRuntime = {
	suspend: (body) => effect_Effect.suspend(() => lift(body())),
	chain: (first, next) => effect_Effect.flatMap(first, (value) => lift(next(value))),
	detach: (work) => effect_Effect.suspend(work),
	attempt: (run, onError) => {
		let query;
		try {
			query = run();
		} catch (e) {
			return effect_Effect.fail(onError(e));
		}
		return effect_Effect.catch(query, (e) => effect_Effect.fail(onError(e)));
	},
	queryError: (query, params, cause) => new __effect_core_errors_ts.EffectDrizzleQueryError({
		query,
		params,
		cause: effect_Cause.fail(cause)
	})
};
const tracedEffectQueryRuntime = {
	...effectQueryRuntime,
	span: __tracing_ts.hasTelemetry ? require_runtime_core.tracedSpan : void 0
};
const runEffectProgram = (body) => require_runtime_core.runProgram(effectQueryRuntime, body);
const effectMigrationRunner = (session) => ({
	execute: (query) => session.execute(query),
	objects: (query) => session.objects(query),
	atomically: (statements) => session.transaction((tx) => effect_Effect.forEach(statements, (statement) => tx.execute(statement), { discard: true }))
});
//#endregion
exports.effectMigrationRunner = effectMigrationRunner;
exports.effectQueryRuntime = effectQueryRuntime;
exports.runEffectProgram = runEffectProgram;
exports.tracedEffectQueryRuntime = tracedEffectQueryRuntime;

//# sourceMappingURL=effect.cjs.map