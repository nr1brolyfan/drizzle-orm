Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_ts = require("../migrator.cjs");
let __sqlite_core_effect_session_ts = require("../sqlite-core/effect/session.cjs");
//#region src/effect-sqlite-bun/migrator.ts
function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	return (0, __sqlite_core_effect_session_ts.migrate)(migrations, db.session, config);
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map