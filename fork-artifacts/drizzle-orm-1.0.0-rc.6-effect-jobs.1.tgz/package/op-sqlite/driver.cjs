Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_op_sqlite_codecs = require("./codecs.cjs");
const require_op_sqlite_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __sqlite_core_async_db_ts = require("../sqlite-core/async/db.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
//#region src/op-sqlite/driver.ts
var OPSQLiteDatabase = class extends __sqlite_core_async_db_ts.SQLiteAsyncDatabase {
	static [__entity_ts.entityKind] = "OPSQLiteDatabase";
};
/**
* Driver quirks:
* - Integers past the safe integer range are read as numbers: `numeric` columns throw on them
*/
function drizzle(client, config = {}) {
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({
		codecs: config.codecs ?? require_op_sqlite_codecs.opSQLiteCodecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new OPSQLiteDatabase("async", dialect, new require_op_sqlite_session.OPSQLiteSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
//#endregion
exports.OPSQLiteDatabase = OPSQLiteDatabase;
exports.drizzle = drizzle;

//# sourceMappingURL=driver.cjs.map