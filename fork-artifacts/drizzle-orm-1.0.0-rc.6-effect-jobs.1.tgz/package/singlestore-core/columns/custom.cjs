Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_singlestore_core_columns_common = require("./common.cjs");
const require_singlestore_core_codecs = require("../codecs.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
//#region src/singlestore-core/columns/custom.ts
var SingleStoreCustomColumnBuilder = class extends require_singlestore_core_columns_common.SingleStoreColumnBuilder {
	static [__entity_ts.entityKind] = "SingleStoreCustomColumnBuilder";
	constructor(name, fieldConfig, customTypeParams) {
		super(name, "custom", "SingleStoreCustomColumn");
		this.config.fieldConfig = fieldConfig;
		this.config.customTypeParams = customTypeParams;
	}
	/** @internal */
	build(table) {
		return new SingleStoreCustomColumn(table, this.config);
	}
};
var SingleStoreCustomColumn = class extends require_singlestore_core_columns_common.SingleStoreColumn {
	static [__entity_ts.entityKind] = "SingleStoreCustomColumn";
	/** @internal */
	codec;
	sqlName;
	mapFromJsonValue;
	jsonSelectIdentifier;
	constructor(table, config) {
		super(table, config);
		this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
		this.mapToDriverValue = config.customTypeParams.toDriver ?? this.mapToDriverValue;
		this.mapFromDriverValue = config.customTypeParams.fromDriver ?? this.mapFromDriverValue;
		this.mapFromJsonValue = config.customTypeParams.fromJson;
		this.jsonSelectIdentifier = config.customTypeParams.forJsonSelect;
		const cfgCodec = typeof config.customTypeParams.codec === "string" || typeof config.customTypeParams.codec === "undefined" ? config.customTypeParams.codec : config.customTypeParams.codec(config.fieldConfig);
		this.codec = typeof cfgCodec === "string" ? require_singlestore_core_codecs.resolveSingleStoreTypeAlias(cfgCodec) : void 0;
	}
	getSQLType() {
		return this.sqlName;
	}
};
/**
* Custom singlestore database data type generator
*/
function customType(customTypeParams) {
	return (a, b) => {
		const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
		return new SingleStoreCustomColumnBuilder(name, config, customTypeParams);
	};
}
//#endregion
exports.SingleStoreCustomColumn = SingleStoreCustomColumn;
exports.SingleStoreCustomColumnBuilder = SingleStoreCustomColumnBuilder;
exports.customType = customType;

//# sourceMappingURL=custom.cjs.map