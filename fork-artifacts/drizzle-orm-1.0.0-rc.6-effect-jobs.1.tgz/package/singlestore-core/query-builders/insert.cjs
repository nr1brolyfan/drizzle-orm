Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __table_ts = require("../../table.cjs");
let __utils_ts = require("../../utils.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
//#region src/singlestore-core/query-builders/insert.ts
var SingleStoreInsertBuilder = class {
	table;
	session;
	dialect;
	columnList;
	static [__entity_ts.entityKind] = "SingleStoreInsertBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	shouldIgnore = false;
	constructor(table, session, dialect, columnList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.columnList = columnList;
	}
	ignore() {
		this.shouldIgnore = true;
		return this;
	}
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		return new SingleStoreInsertBase(this.table, values, this.shouldIgnore, this.session, this.dialect, this.columnList);
	}
};
var SingleStoreInsertBase = class extends __query_promise_ts.QueryPromise {
	session;
	dialect;
	static [__entity_ts.entityKind] = "SingleStoreInsert";
	config;
	constructor(table, values, ignore, session, dialect, columnList) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			ignore,
			columnList
		};
	}
	/**
	* Adds an `on duplicate key update` clause to the query.
	*
	* Calling this method will update update the row if any unique index conflicts. MySQL will automatically determine the conflict target based on the primary key and unique indexes.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#on-duplicate-key-update}
	*
	* @param config The `set` clause
	*
	* @example
	* ```ts
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW'})
	*   .onDuplicateKeyUpdate({ set: { brand: 'Porsche' }});
	* ```
	*
	* While MySQL does not directly support doing nothing on conflict, you can perform a no-op by setting any column's value to itself and achieve the same effect:
	*
	* ```ts
	* import { sql } from 'drizzle-orm';
	*
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onDuplicateKeyUpdate({ set: { id: sql`id` } });
	* ```
	*/
	onDuplicateKeyUpdate(config) {
		if (this.config.returning) throw new Error("`$returningId` cannot be used with `onDuplicateKeyUpdate`: updated rows' ids are not reported by the database.");
		const setSql = this.dialect.buildUpdateSet(this.config.table, (0, __utils_ts.mapUpdateSet)(this.config.table, config.set));
		this.config.onConflict = __sql_sql_ts.sql`update ${setSql}`;
		return this;
	}
	$returningId() {
		if (this.config.onConflict) throw new Error("`$returningId` cannot be used with `onDuplicateKeyUpdate`: updated rows' ids are not reported by the database.");
		const returning = [];
		for (const [key, value] of Object.entries(this.config.table[__table_ts.Table.Symbol.Columns])) if (value.primary) returning.push({
			field: value,
			fieldType: "Column",
			path: [key]
		});
		this.config.returning = returning;
		return this;
	}
	getSQL() {
		return this.dialect.buildInsertQuery(this.config).sql;
	}
	toSQL() {
		return this.dialect.sqlToQuery(this.getSQL());
	}
	prepare() {
		const { sql, generatedIds } = this.dialect.buildInsertQuery(this.config);
		return this.session.prepareQuery(this.dialect.sqlToQuery(sql), "raw", this.dialect.mapperGenerators.$returning(this.config.returning, generatedIds));
	}
	execute = (placeholderValues) => {
		return this.prepare().execute(placeholderValues);
	};
	createIterator = () => {
		const self = this;
		return async function* (placeholderValues) {
			yield* self.prepare().iterator(placeholderValues);
		};
	};
	iterator = this.createIterator();
	$dynamic() {
		return this;
	}
};
//#endregion
exports.SingleStoreInsertBase = SingleStoreInsertBase;
exports.SingleStoreInsertBuilder = SingleStoreInsertBuilder;

//# sourceMappingURL=insert.cjs.map