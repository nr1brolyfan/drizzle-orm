Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __sql_sql_ts = require("../sql/sql.cjs");
//#region src/singlestore-core/expressions.ts
function concat(...values) {
	return __sql_sql_ts.sql`concat(${__sql_sql_ts.sql.join(values.map((value) => __sql_sql_ts.sql`${value}`), __sql_sql_ts.sql`, `)})`;
}
function substring(column, { from, for: _for }) {
	return _for === void 0 ? __sql_sql_ts.sql`substring(${column} from ${from})` : __sql_sql_ts.sql`substring(${column} from ${from} for ${_for})`;
}
function dotProduct(column, value) {
	return __sql_sql_ts.sql`${column} <*> ${JSON.stringify(value)}`;
}
function euclideanDistance(column, value) {
	return __sql_sql_ts.sql`${column} <-> ${JSON.stringify(value)}`;
}
//#endregion
exports.concat = concat;
exports.dotProduct = dotProduct;
exports.euclideanDistance = euclideanDistance;
exports.substring = substring;
var __sql_expressions_index_ts = require("../sql/expressions/index.cjs");
Object.keys(__sql_expressions_index_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __sql_expressions_index_ts[k];
		}
	});
});

//# sourceMappingURL=expressions.cjs.map