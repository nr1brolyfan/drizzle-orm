Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_ts = require("../migrator.cjs");
let __mysql_core_effect_session_ts = require("../mysql-core/effect/session.cjs");
//#region src/effect-mysql2/migrator.ts
function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	return (0, __mysql_core_effect_session_ts.migrate)(migrations, db.session, config);
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map