Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
const require_effect_mysql2_codecs = require("./codecs.cjs");
const require_effect_mysql2_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __errors_ts = require("../errors.cjs");
let __utils_ts = require("../utils.cjs");
let __effect_core_index_ts = require("../effect-core/index.cjs");
let effect_Effect = require("effect/Effect");
effect_Effect = require_runtime.__toESM(effect_Effect, 1);
let __effect_core_defaults_ts = require("../effect-core/defaults.cjs");
let __mysql_core_dialect_ts = require("../mysql-core/dialect.cjs");
let _effect_sql_mysql2_MysqlClient = require("@effect/sql-mysql2/MysqlClient");
let effect_Redacted = require("effect/Redacted");
effect_Redacted = require_runtime.__toESM(effect_Redacted, 1);
let __mysql_core_effect_db_ts = require("../mysql-core/effect/db.cjs");
//#region src/effect-mysql2/driver.ts
var EffectMysql2Database = class extends __mysql_core_effect_db_ts.MySqlEffectDatabase {
	static [__entity_ts.entityKind] = "EffectMysql2Database";
};
/** mysql2 options of the client's pool: `@effect/sql-mysql2` passes `poolConfig` through, or the url's query string */
const poolOptionsOf = (client) => {
	const { url, poolConfig } = client.config;
	if (url === void 0) return poolConfig ?? {};
	const options = {};
	for (const [key, value] of new URL(effect_Redacted.value(url)).searchParams) try {
		options[key] = JSON.parse(value);
	} catch {
		options[key] = value;
	}
	return options;
};
const temporalTypes = [
	"DATE",
	"DATETIME",
	"TIMESTAMP"
];
/**
* `@effect/sql-mysql2` accepts no per-query type casts, so pool options that lose data are rejected: temporal values
* are decoded to `Date`s in the connection's time zone without `dateStrings` (shifting wall-clock times that don't exist
* in it, misreading years below 100), `decimal` values to numbers with `decimalNumbers`
*/
const assertLosslessPoolOptions = (client) => {
	const { dateStrings, decimalNumbers } = poolOptionsOf(client);
	const types = dateStrings === true ? temporalTypes : Array.isArray(dateStrings) ? dateStrings : typeof dateStrings === "string" ? [dateStrings] : [];
	if (!temporalTypes.every((type) => types.includes(type))) throw new __errors_ts.DrizzleError({ message: "`@effect/sql-mysql2`'s client must be created with `dateStrings: true` (in `poolConfig`, or as `?dateStrings=true` in `url`): without it, temporal values are decoded to `Date`s in the connection's time zone, shifting wall-clock times that don't exist in it and misreading years below 100" });
	if (decimalNumbers === true) throw new __errors_ts.DrizzleError({ message: "`@effect/sql-mysql2`'s client must not be created with `decimalNumbers: true`: it decodes `decimal` values to numbers, losing precision" });
};
/**
* Creates an EffectMysql2Database instance.
*
* Requires `MysqlClient`, and `EffectLogger` services to be provided.
* Use `DefaultServices` to provide the default (no-op) logger implementation.
*
* @example
* ```ts
* // With default services (no logging, no caching)
* const db = yield* MySqlDrizzle.make({ relations }).pipe(
*   Effect.provide(MySqlDrizzle.DefaultServices),
* );
*
* // With Effect-based logging
* const db = yield* MySqlDrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layer),
*   Effect.provide(MySqlDrizzle.DefaultServices),
* );
*
* // With custom Drizzle logger
* const db = yield* MySqlDrizzle.make({ relations }).pipe(
*   Effect.provide(EffectLogger.layerFromDrizzle(myLogger)),
*   Effect.provide(MySqlDrizzle.DefaultServices),
* );
* ```
*
* Requirements:
* - The client's pool must be created with `dateStrings: true` and without `decimalNumbers: true`, throws otherwise
*
* Driver quirks:
* - `time` and `string`-mode `datetime`, `timestamp` lose trailing zeros of fractional seconds
*/
const make = effect_Effect.fn("MySqlDrizzle.make")(function* (config = {}) {
	const client = yield* _effect_sql_mysql2_MysqlClient.MysqlClient;
	assertLosslessPoolOptions(client);
	const logger = yield* __effect_core_index_ts.EffectLogger;
	const dialect = new __mysql_core_dialect_ts.MySqlDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_effect_mysql2_codecs.effectMysql2Codecs,
		paginationToBigint: true
	});
	const relations = config.relations ?? {};
	const db = new EffectMysql2Database(dialect, new require_effect_mysql2_session.EffectMysql2Session(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
});
/**
* Convenience function that creates an EffectMysql2Database with `DefaultServices` already provided.
*/
const makeWithDefaults = (config = {}) => make(config).pipe(effect_Effect.provide(__effect_core_defaults_ts.DefaultServices));
//#endregion
Object.defineProperty(exports, "DefaultServices", {
	enumerable: true,
	get: function() {
		return __effect_core_defaults_ts.DefaultServices;
	}
});
exports.EffectMysql2Database = EffectMysql2Database;
exports.make = make;
exports.makeWithDefaults = makeWithDefaults;

//# sourceMappingURL=driver.cjs.map