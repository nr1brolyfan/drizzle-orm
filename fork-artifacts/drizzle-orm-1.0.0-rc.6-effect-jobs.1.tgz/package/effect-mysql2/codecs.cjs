Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __mysql_core_codecs_ts = require("../mysql-core/codecs.cjs");
//#region src/effect-mysql2/codecs.ts
const effectMysql2Codecs = (0, __mysql_core_codecs_ts.refineGenericMySqlCodecs)({
	serial: { normalize: Number },
	bigint: { normalize: BigInt },
	"bigint:number": { normalize: Number },
	"bigint:string": { normalize: String },
	boolean: { normalize: (value) => value === 1 },
	"decimal:number": { normalize: Number },
	"decimal:bigint": { normalize: BigInt },
	float: { normalize: __mysql_core_codecs_ts.floatFromDouble },
	date: { normalize: __mysql_core_codecs_ts.mysqlDateFromText },
	datetime: { normalize: __mysql_core_codecs_ts.mysqlDatetimeFromText },
	timestamp: { normalize: __mysql_core_codecs_ts.mysqlTimestampFromText },
	binary: { normalize: (value) => value.toString() },
	varbinary: { normalize: (value) => value.toString() },
	blob: { normalize: (value) => value.toString("utf8") },
	tinyblob: { normalize: (value) => value.toString("utf8") },
	mediumblob: { normalize: (value) => value.toString("utf8") },
	longblob: { normalize: (value) => value.toString("utf8") }
});
//#endregion
exports.effectMysql2Codecs = effectMysql2Codecs;

//# sourceMappingURL=codecs.cjs.map