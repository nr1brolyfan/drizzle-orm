Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
const require_cockroach_codecs = require("./codecs.cjs");
const require_cockroach_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __cockroach_core_dialect_ts = require("../cockroach-core/dialect.cjs");
let __logger_ts = require("../logger.cjs");
let pg = require("pg");
pg = require_runtime.__toESM(pg, 1);
let __cockroach_core_db_ts = require("../cockroach-core/db.cjs");
//#region src/cockroach/driver.ts
var NodeCockroachDriver = class {
	client;
	dialect;
	options;
	static [__entity_ts.entityKind] = "NodeCockroachDriver";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(client, dialect, options = {}) {
		this.client = client;
		this.dialect = dialect;
		this.options = options;
	}
	createSession(relations) {
		return new require_cockroach_session.NodeCockroachSession(this.client, this.dialect, relations, {
			logger: this.options.logger,
			paramsInErrors: this.options.paramsInErrors
		});
	}
};
var NodeCockroachDatabase = class extends __cockroach_core_db_ts.CockroachDatabase {
	static [__entity_ts.entityKind] = "NodeCockroachDatabase";
};
function construct(client, config = {}) {
	const dialect = new __cockroach_core_dialect_ts.CockroachDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_cockroach_codecs.nodeCockroachCodecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new NodeCockroachDatabase(dialect, new NodeCockroachDriver(client, dialect, {
		logger,
		paramsInErrors: config.paramsInErrors
	}).createSession(relations), relations);
	db.$client = client;
	return db;
}
/**
* Requirements:
* - Sessions must use the ISO `DateStyle` (the default): temporal values of other `DateStyle`s throw
*/
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(new pg.default.Pool({ connectionString: params[0] }), params[1]);
	const { connection, client, ...drizzleCockroaDrizzleCockroachConfig } = params[0];
	if (client) return construct(client, drizzleCockroaDrizzleCockroachConfig);
	return construct(typeof connection === "string" ? new pg.default.Pool({ connectionString: connection }) : new pg.default.Pool(connection), drizzleCockroaDrizzleCockroachConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.NodeCockroachDatabase = NodeCockroachDatabase;
exports.NodeCockroachDriver = NodeCockroachDriver;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map