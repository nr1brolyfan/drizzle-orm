Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __cockroach_core_codecs_ts = require("../cockroach-core/codecs.cjs");
//#region src/cockroach/codecs.ts
const nodeCockroachCodecs = (0, __cockroach_core_codecs_ts.refineGenericCockroachCodecs)({
	int2: {
		normalize: Number,
		normalizeArray: (0, __cockroach_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	int4: {
		normalize: Number,
		normalizeArray: (0, __cockroach_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	real: {
		normalize: Number,
		normalizeArray: (0, __cockroach_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	float: {
		normalize: Number,
		normalizeArray: (0, __cockroach_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	int8: {
		normalize: BigInt,
		normalizeArray: (0, __cockroach_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"int8:number": {
		normalize: Number,
		normalizeArray: (0, __cockroach_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	decimal: { normalizeArray: __cockroach_core_codecs_ts.parseArray },
	"decimal:number": {
		normalize: Number,
		normalizeArray: (0, __cockroach_core_codecs_ts.parseArrayAndNormalize)(Number)
	},
	"decimal:bigint": {
		normalize: BigInt,
		normalizeArray: (0, __cockroach_core_codecs_ts.parseArrayAndNormalize)(BigInt)
	},
	date: {
		normalize: __cockroach_core_codecs_ts.textToDate,
		normalizeArray: __cockroach_core_codecs_ts.textToDateArray
	},
	"date:string": { normalizeArray: __cockroach_core_codecs_ts.parseArray },
	timestamp: {
		normalize: __cockroach_core_codecs_ts.textToDateWithTz,
		normalizeArray: __cockroach_core_codecs_ts.textToDateWithTzArray
	},
	timestamptz: {
		normalize: __cockroach_core_codecs_ts.textToDate,
		normalizeArray: __cockroach_core_codecs_ts.textToDateArray
	},
	"timestamp:string": { normalizeArray: __cockroach_core_codecs_ts.parseArray },
	"timestamptz:string": { normalizeArray: __cockroach_core_codecs_ts.parseArray },
	interval: { normalizeArray: __cockroach_core_codecs_ts.parseArray },
	geometry: {
		normalize: __cockroach_core_codecs_ts.parseGeometryTuple,
		normalizeArray: (0, __cockroach_core_codecs_ts.parseGeometryArrayAndNormalize)(__cockroach_core_codecs_ts.parseGeometryTuple),
		normalizeParamArray: __cockroach_core_codecs_ts.makeGeometryArray
	},
	"geometry:xy": {
		normalize: __cockroach_core_codecs_ts.parseGeometryXY,
		normalizeArray: (0, __cockroach_core_codecs_ts.parseGeometryArrayAndNormalize)(__cockroach_core_codecs_ts.parseGeometryXY),
		normalizeParamArray: __cockroach_core_codecs_ts.makeGeometryArray
	},
	vector: {
		normalize: __cockroach_core_codecs_ts.parseCockroachVector,
		normalizeArray: (0, __cockroach_core_codecs_ts.parseArrayAndNormalize)(__cockroach_core_codecs_ts.parseCockroachVector)
	},
	bit: { normalizeArray: __cockroach_core_codecs_ts.parseArray },
	varbit: { normalizeArray: __cockroach_core_codecs_ts.parseArray },
	enum: { normalizeArray: __cockroach_core_codecs_ts.parseArray }
});
//#endregion
exports.nodeCockroachCodecs = nodeCockroachCodecs;

//# sourceMappingURL=codecs.cjs.map