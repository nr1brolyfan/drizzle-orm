Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __sqlite_core_codecs_ts = require("../sqlite-core/codecs.cjs");
//#region src/sql-js/codecs.ts
const driver = "sql-js";
const sqlJsCodecs = (0, __sqlite_core_codecs_ts.refineSqliteCodecs)({
	integer: { normalize: Number },
	"integer:boolean": { normalize: __sqlite_core_codecs_ts.booleanFromInteger },
	"integer:timestamp": { normalize: __sqlite_core_codecs_ts.dateFromStoredSeconds },
	"integer:timestamp_ms": { normalize: __sqlite_core_codecs_ts.dateFromStoredMilliseconds },
	"text:json": { normalize: JSON.parse },
	blob: { normalize: __sqlite_core_codecs_ts.bufferFromBytesIfAvailable },
	"blob:json": { normalize: __sqlite_core_codecs_ts.jsonFromBlob },
	"blob:bigint": { normalize: __sqlite_core_codecs_ts.bigintFromBlob },
	numeric: { normalize: (0, __sqlite_core_codecs_ts.numericTextFromValue)(driver) },
	"numeric:number": { normalize: Number },
	"numeric:bigint": { normalize: (0, __sqlite_core_codecs_ts.numericBigintFromValue)(driver) }
});
//#endregion
exports.sqlJsCodecs = sqlJsCodecs;

//# sourceMappingURL=codecs.cjs.map