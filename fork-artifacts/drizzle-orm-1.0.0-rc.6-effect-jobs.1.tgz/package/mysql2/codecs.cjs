Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/mysql2/codecs.ts
const mysql2Codecs = (0, require("../mysql-core/codecs.cjs").refineGenericMySqlCodecs)({
	serial: { normalize: Number },
	bigint: { normalize: BigInt },
	"bigint:number": { normalize: Number },
	"bigint:string": { normalize: String },
	boolean: { normalize: (value) => value === 1 },
	date: { normalize: (value) => new Date(value) },
	datetime: { normalize: (value) => /* @__PURE__ */ new Date(value.replace(" ", "T") + "Z") },
	timestamp: { normalize: (value) => /* @__PURE__ */ new Date(value + "+0000") },
	"decimal:number": { normalize: Number },
	"decimal:bigint": { normalize: BigInt },
	binary: { normalize: (value) => value.toString() },
	varbinary: { normalize: (value) => value.toString() },
	blob: { normalize: (value) => value.toString("utf8") },
	tinyblob: { normalize: (value) => value.toString("utf8") },
	mediumblob: { normalize: (value) => value.toString("utf8") },
	longblob: { normalize: (value) => value.toString("utf8") }
});
//#endregion
exports.mysql2Codecs = mysql2Codecs;

//# sourceMappingURL=codecs.cjs.map