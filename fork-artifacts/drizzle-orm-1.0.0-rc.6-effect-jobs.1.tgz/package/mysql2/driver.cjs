Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql2_codecs = require("./codecs.cjs");
const require_mysql2_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __mysql_core_async_db_ts = require("../mysql-core/async/db.cjs");
let __mysql_core_dialect_ts = require("../mysql-core/dialect.cjs");
let mysql2_promise = require("mysql2/promise");
//#region src/mysql2/driver.ts
var MySql2Database = class extends __mysql_core_async_db_ts.MySqlAsyncDatabase {
	static [__entity_ts.entityKind] = "MySql2Database";
};
function construct(client, config = {}) {
	const dialect = new __mysql_core_dialect_ts.MySqlDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_mysql2_codecs.mysql2Codecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const clientForInstance = isCallbackClient(client) ? client.promise() : client;
	const relations = config.relations ?? {};
	const db = new MySql2Database(dialect, new require_mysql2_session.MySql2Session(clientForInstance, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
function isCallbackClient(client) {
	return typeof client.promise === "function";
}
/**
* Driver quirks:
* - `float` values are rounded to 6 significant digits by MySQL's text protocol
*/
function drizzle(...params) {
	if (typeof params[0] === "string") {
		const connectionString = params[0];
		return construct((0, mysql2_promise.createPool)({ uri: connectionString }), params[1]);
	}
	const { connection, client, ...config } = params[0];
	if (client) return construct(client, config);
	return construct(typeof connection === "string" ? (0, mysql2_promise.createPool)({ uri: connection }) : (0, mysql2_promise.createPool)(connection), config);
}
(function(_drizzle) {
	function mock(config) {
		return construct({ config: {} }, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.MySql2Database = MySql2Database;
Object.defineProperty(exports, "MySqlDatabase", {
	enumerable: true,
	get: function() {
		return __mysql_core_async_db_ts.MySqlAsyncDatabase;
	}
});
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map