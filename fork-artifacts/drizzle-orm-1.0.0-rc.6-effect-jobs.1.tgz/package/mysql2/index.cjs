Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql2_codecs = require("./codecs.cjs");
const require_mysql2_type_cast = require("./type-cast.cjs");
const require_mysql2_session = require("./session.cjs");
const require_mysql2_driver = require("./driver.cjs");
let __mysql_core_async_db_ts = require("../mysql-core/async/db.cjs");
exports.MySql2Database = require_mysql2_driver.MySql2Database;
exports.MySql2Session = require_mysql2_session.MySql2Session;
exports.MySql2Transaction = require_mysql2_session.MySql2Transaction;
Object.defineProperty(exports, "MySqlDatabase", {
	enumerable: true,
	get: function() {
		return __mysql_core_async_db_ts.MySqlAsyncDatabase;
	}
});
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return require_mysql2_driver.drizzle;
	}
});
exports.makeMySql2RawTextTypeCast = require_mysql2_type_cast.makeMySql2RawTextTypeCast;
exports.mysql2Codecs = require_mysql2_codecs.mysql2Codecs;
