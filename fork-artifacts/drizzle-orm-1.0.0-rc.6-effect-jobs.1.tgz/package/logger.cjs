Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("./entity.cjs");
//#region src/logger.ts
var ConsoleLogWriter = class {
	static [__entity_ts.entityKind] = "ConsoleLogWriter";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	write(message) {
		console.log(message);
	}
};
var DefaultLogger = class {
	static [__entity_ts.entityKind] = "DefaultLogger";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	writer;
	constructor(config) {
		this.writer = config?.writer ?? new ConsoleLogWriter();
	}
	logQuery(query, params) {
		const stringifiedParams = params.map((p) => {
			try {
				return JSON.stringify(p);
			} catch {
				return String(p);
			}
		});
		const paramsStr = stringifiedParams.length ? ` -- params: [${stringifiedParams.join(", ")}]` : "";
		this.writer.write(`Query: ${query}${paramsStr}`);
	}
};
var NoopLogger = class {
	static [__entity_ts.entityKind] = "NoopLogger";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	logQuery() {}
};
//#endregion
exports.ConsoleLogWriter = ConsoleLogWriter;
exports.DefaultLogger = DefaultLogger;
exports.NoopLogger = NoopLogger;

//# sourceMappingURL=logger.cjs.map