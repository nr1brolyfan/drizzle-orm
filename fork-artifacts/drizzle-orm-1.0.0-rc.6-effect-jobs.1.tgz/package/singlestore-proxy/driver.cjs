Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_singlestore_proxy_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __singlestore_core_dialect_ts = require("../singlestore-core/dialect.cjs");
let __logger_ts = require("../logger.cjs");
let __singlestore_core_db_ts = require("../singlestore-core/db.cjs");
//#region src/singlestore-proxy/driver.ts
var SingleStoreRemoteDatabase = class extends __singlestore_core_db_ts.SingleStoreDatabase {
	static [__entity_ts.entityKind] = "SingleStoreRemoteDatabase";
};
function drizzle(callback, config = {}) {
	const dialect = new __singlestore_core_dialect_ts.SingleStoreDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	return new SingleStoreRemoteDatabase(dialect, new require_singlestore_proxy_session.SingleStoreRemoteSession(callback, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
}
//#endregion
exports.SingleStoreRemoteDatabase = SingleStoreRemoteDatabase;
exports.drizzle = drizzle;

//# sourceMappingURL=driver.cjs.map