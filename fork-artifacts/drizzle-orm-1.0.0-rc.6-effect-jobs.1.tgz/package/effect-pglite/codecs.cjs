Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __utils_ts = require("../utils.cjs");
let __codecs_ts = require("../codecs.cjs");
let __pg_core_array_ts = require("../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../pg-core/codecs.cjs");
//#region src/effect-pglite/codecs.ts
const driver = "@effect/sql-pglite";
const localTimeReason = "the driver decodes `timestamp` values in process-local time, and its `Effect` client accepts no per-query parsers";
const timeZoneReason = "the driver decodes `timestamptz` values to `Date`s, dropping the offset the server formats in the session's time zone, and its `Effect` client accepts no per-query parsers";
const effectPgliteCodecs = (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
	bigint: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	bigserial: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"bigint:string": {
		normalize: String,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(String)
	},
	"bigint:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	"bigserial:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	"date:string": {
		normalize: __pg_core_codecs_ts.pgDateTextFromUtcDate,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.pgDateTextFromUtcDate)
	},
	"geometry(point)": {
		normalize: __pg_core_codecs_ts.parseGeometryXY,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryXY),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	"geometry(point):tuple": {
		normalize: __pg_core_codecs_ts.parseGeometryTuple,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryTuple),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	line: {
		normalize: __pg_core_codecs_ts.parseLineABC,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineABC)
	},
	"line:tuple": {
		normalize: __pg_core_codecs_ts.parseLineTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineTuple)
	},
	point: {
		normalize: __pg_core_codecs_ts.parsePointXY,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointXY)
	},
	"point:tuple": {
		normalize: __pg_core_codecs_ts.parsePointTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointTuple)
	},
	timestamp: {
		normalize: (0, __codecs_ts.unsupportedCodec)("timestamp", driver, localTimeReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("timestamp", driver, localTimeReason)
	},
	"timestamp:string": {
		normalize: (0, __codecs_ts.unsupportedCodec)("timestamp", driver, localTimeReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("timestamp", driver, localTimeReason)
	},
	"timestamptz:string": {
		normalize: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timeZoneReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timeZoneReason)
	},
	json: {
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	jsonb: {
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	box: { normalizeParamArray: __pg_core_codecs_ts.makeBoxArray },
	box2d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	box3d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	circle: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	datemultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	daterange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"geography(point)": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	"geography(point):tuple": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	int4multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int4range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int8multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int8range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	lseg: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	money: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	nummultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	numrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	oid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	path: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	polygon: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	raster: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regclass: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regconfig: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regdictionary: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regnamespace: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regoper: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regoperator: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regproc: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regprocedure: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regrole: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regtype: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	timetz: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsquery: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tstzmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tstzrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsvector: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	varbit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	xml: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	bytea: {
		normalizeInJson: typeof Buffer === "undefined" ? __utils_ts.pgHexToUint8Array : __pg_core_codecs_ts.genericPgCodecs.bytea?.normalizeInJson,
		normalizeArrayInJson: typeof Buffer === "undefined" ? (0, __pg_core_codecs_ts.arrayCompatNormalize)(__utils_ts.pgHexToUint8Array) : __pg_core_codecs_ts.genericPgCodecs.bytea?.normalizeArrayInJson,
		normalize: typeof Buffer === "undefined" ? void 0 : (v) => Buffer.from(v),
		normalizeArray: typeof Buffer === "undefined" ? void 0 : (0, __pg_core_codecs_ts.arrayCompatNormalize)((v) => Buffer.from(v))
	},
	enum: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
	},
	"numeric:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	"numeric:bigint": {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	halfvec: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	vector: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	sparsevec: {
		normalizeArray: (v) => (0, __pg_core_array_ts.parsePgArray)(v),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	}
});
//#endregion
exports.effectPgliteCodecs = effectPgliteCodecs;

//# sourceMappingURL=codecs.cjs.map