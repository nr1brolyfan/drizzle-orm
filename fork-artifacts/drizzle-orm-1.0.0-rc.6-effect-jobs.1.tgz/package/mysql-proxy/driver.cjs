Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_mysql_proxy_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __mysql_core_async_db_ts = require("../mysql-core/async/db.cjs");
let __mysql_core_dialect_ts = require("../mysql-core/dialect.cjs");
//#region src/mysql-proxy/driver.ts
var MySqlRemoteDatabase = class extends __mysql_core_async_db_ts.MySqlAsyncDatabase {
	static [__entity_ts.entityKind] = "MySqlRemoteDatabase";
};
function drizzle(callback, config = {}, _dialect = (config) => new __mysql_core_dialect_ts.MySqlDialect(config)) {
	const dialect = _dialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	return new MySqlRemoteDatabase(dialect, new require_mysql_proxy_session.MySqlRemoteSession(callback, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
}
//#endregion
exports.MySqlRemoteDatabase = MySqlRemoteDatabase;
exports.drizzle = drizzle;

//# sourceMappingURL=driver.cjs.map