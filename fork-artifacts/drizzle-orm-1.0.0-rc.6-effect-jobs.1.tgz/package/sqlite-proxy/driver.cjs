Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_proxy_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __sqlite_core_async_db_ts = require("../sqlite-core/async/db.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
//#region src/sqlite-proxy/driver.ts
var SqliteRemoteDatabase = class extends __sqlite_core_async_db_ts.SQLiteAsyncDatabase {
	static [__entity_ts.entityKind] = "SqliteRemoteDatabase";
	async batch(batch) {
		return this.session.batch(batch);
	}
};
function drizzle(executors, config) {
	let logger;
	if (config?.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config?.logger !== false) logger = config?.logger;
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({
		codecs: config?.codecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config?.jit)
	});
	const relations = config?.relations ?? {};
	return new SqliteRemoteDatabase("async", dialect, new require_sqlite_proxy_session.SQLiteRemoteSession(executors, dialect, relations, {
		logger,
		paramsInErrors: config?.paramsInErrors
	}), relations);
}
//#endregion
exports.SqliteRemoteDatabase = SqliteRemoteDatabase;
exports.drizzle = drizzle;

//# sourceMappingURL=driver.cjs.map