Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __pg_core_array_ts = require("../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../pg-core/codecs.cjs");
//#region src/xata-http/codecs.ts
const xataHttpCodecs = (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
	bigint: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	bigserial: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	bit: {
		normalizeArray: (v) => (0, __pg_core_array_ts.parsePgArray)(v),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	json: {
		castParam: (name) => `${name}::json`,
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	jsonb: {
		castParam: (name) => `${name}::jsonb`,
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	interval: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	point: {
		normalize: __pg_core_codecs_ts.parsePointXY,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointXY),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"point:tuple": {
		normalize: __pg_core_codecs_ts.parsePointTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointTuple),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	line: {
		normalize: __pg_core_codecs_ts.parseLineABC,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineABC),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"line:tuple": {
		normalize: __pg_core_codecs_ts.parseLineTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineTuple),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	macaddr8: {
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	bool: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	box: { normalizeParamArray: __pg_core_codecs_ts.makeBoxArray },
	box2d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	box3d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	char: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	cidr: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	circle: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	datemultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	daterange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	float8: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"geography(point)": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	"geography(point):tuple": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
	inet: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int4multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int4range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int8multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int8range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	lseg: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	macaddr: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	money: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	nummultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	numrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	oid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	path: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	polygon: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	raster: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regclass: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regconfig: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regdictionary: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regnamespace: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regoper: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regoperator: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regproc: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regprocedure: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regrole: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	regtype: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	serial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	smallint: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	smallserial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	text: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	time: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	timetz: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsquery: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tstzmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tstzrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	tsvector: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	varbit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	varchar: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	xml: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	bytea: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	enum: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"geometry(point)": {
		normalize: __pg_core_codecs_ts.parseGeometryXY,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryXY),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	"geometry(point):tuple": {
		normalize: __pg_core_codecs_ts.parseGeometryTuple,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryTuple),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	numeric: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"numeric:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"numeric:bigint": {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"bigint:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"bigint:string": { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"bigserial:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	float4: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	int: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	uuid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	date: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: __pg_core_codecs_ts.textToDate,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.textToDate)
	},
	"date:string": { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	timestamp: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: __pg_core_codecs_ts.textToDateWithTz,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.textToDateWithTz)
	},
	timestamptz: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: __pg_core_codecs_ts.textToDate,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.textToDate)
	},
	"timestamp:string": { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	"timestamptz:string": { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
	halfvec: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	sparsevec: {
		normalizeArray: (v) => (0, __pg_core_array_ts.parsePgArray)(v),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	vector: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	}
});
//#endregion
exports.xataHttpCodecs = xataHttpCodecs;

//# sourceMappingURL=codecs.cjs.map