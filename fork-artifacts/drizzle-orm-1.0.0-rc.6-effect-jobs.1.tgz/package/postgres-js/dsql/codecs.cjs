Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_js_codecs = require("../codecs.cjs");
exports.postgresJsCodecs = require_postgres_js_codecs.postgresJsCodecs;
