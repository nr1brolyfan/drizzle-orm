Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_js_codecs = require("../codecs.cjs");
const require_postgres_js_dsql_session = require("./session.cjs");
const require_postgres_js_dsql_driver = require("./driver.cjs");
exports.PostgresJsDsqlDatabase = require_postgres_js_dsql_driver.PostgresJsDsqlDatabase;
exports.PostgresJsDsqlSession = require_postgres_js_dsql_session.PostgresJsDsqlSession;
exports.PostgresJsDsqlTransaction = require_postgres_js_dsql_session.PostgresJsDsqlTransaction;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return require_postgres_js_dsql_driver.drizzle;
	}
});
exports.postgresJsCodecs = require_postgres_js_codecs.postgresJsCodecs;
