Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_postgres_js_codecs = require("../codecs.cjs");
const require_postgres_js_dsql_session = require("./session.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __pg_core_dialect_ts = require("../../pg-core/dialect.cjs");
let __logger_ts = require("../../logger.cjs");
let __pg_core_async_dsql_db_ts = require("../../pg-core/async/dsql/db.cjs");
let _aws_aurora_dsql_postgresjs_connector = require("@aws/aurora-dsql-postgresjs-connector");
//#region src/postgres-js/dsql/driver.ts
var PostgresJsDsqlDatabase = class extends __pg_core_async_dsql_db_ts.DsqlAsyncDatabase {
	static [__entity_ts.entityKind] = "PostgresJsDsqlDatabase";
	transaction(transaction, config) {
		return super.transaction(transaction, config);
	}
};
function construct(client, config = {}) {
	const dateSerializer = (val) => val instanceof Date ? val.toISOString() : val;
	for (const type of [
		"1184",
		"1114",
		"1082",
		"1083"
	]) client.options.serializers[type] = dateSerializer;
	const dialect = new __pg_core_dialect_ts.PgDialect({
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit),
		codecs: config.codecs ?? require_postgres_js_codecs.postgresJsCodecs(client)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new PostgresJsDsqlDatabase(dialect, new require_postgres_js_dsql_session.PostgresJsDsqlSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
/**
* Requirements:
* - Sessions must use the ISO `DateStyle` (the default): temporal values of other `DateStyle`s throw
*
* Driver quirks:
* - Before `postgres` 4.0.0, `null` elements of arrays are decoded as `NaN` (numbers), `'NULL'` (text), `false`
*   (`boolean`) or throw (`json`, `jsonb`)
*/
function drizzle(...params) {
	if (typeof params[0] === "string") return construct((0, _aws_aurora_dsql_postgresjs_connector.auroraDSQLPostgres)(params[0]), params[1]);
	const { connection, client, ...DrizzlePgConfig } = params[0];
	if (client) return construct(client, DrizzlePgConfig);
	if (typeof connection === "object" && connection.url !== void 0) {
		const { url, ...config } = connection;
		return construct((0, _aws_aurora_dsql_postgresjs_connector.auroraDSQLPostgres)(url, config), DrizzlePgConfig);
	}
	return construct((0, _aws_aurora_dsql_postgresjs_connector.auroraDSQLPostgres)(connection), DrizzlePgConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({
			options: { serializers: {} },
			json: (value) => value
		}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.PostgresJsDsqlDatabase = PostgresJsDsqlDatabase;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map