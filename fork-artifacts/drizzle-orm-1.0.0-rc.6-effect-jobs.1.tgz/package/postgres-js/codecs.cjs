Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __pg_core_array_ts = require("../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../pg-core/codecs.cjs");
//#region src/postgres-js/codecs.ts
/**
* Arrays of extension types (and enums) come back parsed only if `postgres.js` fetched their types on connection - the
* type existed by then - others come back as array literals
*/
const fetchedTypeArray = (normalize, delim) => {
	const fromLiteral = (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(normalize, delim);
	const fromParsed = (0, __pg_core_codecs_ts.arrayCompatNormalize)(normalize);
	return (value, arrayDimensions) => typeof value === "string" ? fromLiteral(value, arrayDimensions) : fromParsed(value, arrayDimensions);
};
const fetchedTypeArrayOfStrings = (value) => typeof value === "string" ? (0, __pg_core_array_ts.parsePgArray)(value) : value;
/** JSON param marker exists only on client and isn't importable outside of it */
const postgresJsCodecs = (client) => {
	const isV4 = typeof client.batch === "function";
	const jsonParamArray = (param) => isV4 ? (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)(param) : (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true);
	const jsonParam = (value) => client.typed(value, 114);
	const jsonbParam = (value) => client.json(value);
	return (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
		interval: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
		},
		point: {
			normalize: __pg_core_codecs_ts.parsePointXY,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointXY),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		"point:tuple": {
			normalize: __pg_core_codecs_ts.parsePointTuple,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointTuple),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		line: {
			normalize: __pg_core_codecs_ts.parseLineABC,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineABC),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		"line:tuple": {
			normalize: __pg_core_codecs_ts.parseLineTuple,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineTuple),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		macaddr8: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		json: {
			normalizeParam: jsonParam,
			normalizeParamArray: jsonParamArray(jsonParam)
		},
		jsonb: {
			normalizeParam: jsonbParam,
			normalizeParamArray: jsonParamArray(jsonbParam)
		},
		bit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		bool: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		box: { normalizeParamArray: __pg_core_codecs_ts.makeBoxArray },
		box2d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		box3d: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		char: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		cidr: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		circle: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		datemultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		daterange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		float8: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		"geography(point)": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
		"geography(point):tuple": { normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray },
		halfvec: {
			normalize: __pg_core_codecs_ts.parsePgVector,
			normalizeArray: fetchedTypeArray(__pg_core_codecs_ts.parsePgVector),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		inet: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int4multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int4range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int8multirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int8range: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		lseg: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		macaddr: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		money: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		nummultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		numrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		oid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		path: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		polygon: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		raster: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regclass: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regconfig: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regdictionary: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regnamespace: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regoper: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regoperator: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regproc: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regprocedure: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regrole: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		regtype: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		serial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		smallint: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		smallserial: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		sparsevec: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: fetchedTypeArrayOfStrings
		},
		text: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		time: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		timetz: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsquery: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tstzmultirange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tstzrange: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		tsvector: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		varbit: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		varchar: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		vector: {
			normalize: __pg_core_codecs_ts.parsePgVector,
			normalizeArray: fetchedTypeArray(__pg_core_codecs_ts.parsePgVector),
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		xml: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		bytea: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		enum: {
			normalizeArray: fetchedTypeArrayOfStrings,
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
		},
		"geometry(point)": {
			normalize: __pg_core_codecs_ts.parseGeometryXY,
			normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray,
			normalizeArray: fetchedTypeArray(__pg_core_codecs_ts.parseGeometryXY, ":")
		},
		"geometry(point):tuple": {
			normalize: __pg_core_codecs_ts.parseGeometryTuple,
			normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray,
			normalizeArray: fetchedTypeArray(__pg_core_codecs_ts.parseGeometryTuple, ":")
		},
		numeric: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
		},
		"numeric:number": {
			normalize: Number,
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(Number)
		},
		"numeric:bigint": {
			normalize: BigInt,
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(BigInt)
		},
		bigint: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: BigInt,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
		},
		"bigint:number": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: Number,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
		},
		"bigint:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: String,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(String)
		},
		bigserial: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: BigInt,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
		},
		"bigserial:number": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: Number,
			normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
		},
		float4: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		int: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		uuid: { normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v) },
		date: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: __pg_core_codecs_ts.textToDate,
			normalizeArray: __pg_core_codecs_ts.textToDatePgArray
		},
		"date:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
		},
		timestamp: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: __pg_core_codecs_ts.textToDateWithTz,
			normalizeArray: __pg_core_codecs_ts.textToDateWithTzPgArray
		},
		timestamptz: {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalize: __pg_core_codecs_ts.textToDate,
			normalizeArray: __pg_core_codecs_ts.textToDatePgArray
		},
		"timestamp:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
		},
		"timestamptz:string": {
			normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
			normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
		}
	});
};
//#endregion
exports.postgresJsCodecs = postgresJsCodecs;

//# sourceMappingURL=codecs.cjs.map