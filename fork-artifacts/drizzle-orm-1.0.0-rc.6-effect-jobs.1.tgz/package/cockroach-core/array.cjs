Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/cockroach-core/array.ts
const DEFAULT_DELIM = ",";
function parseCockroachArrayValue(arrayString, startFrom, inQuotes, delim) {
	for (let i = startFrom; i < arrayString.length; i++) {
		const char = arrayString[i];
		if (char === "\\") {
			i++;
			continue;
		}
		if (char === "\"") return [arrayString.slice(startFrom, i).replace(/\\(.)/g, "$1"), i + 1];
		if (inQuotes) continue;
		if (char === delim || char === "}") return [arrayString.slice(startFrom, i).replace(/\\(.)/g, "$1"), i];
	}
	return [arrayString.slice(startFrom).replace(/\\(.)/g, "$1"), arrayString.length];
}
function parseCockroachNestedArray(arrayString, startFrom = 0, delim = DEFAULT_DELIM) {
	const result = [];
	let i = startFrom;
	let lastCharIsDelim = false;
	while (i < arrayString.length) {
		const char = arrayString[i];
		if (char === delim) {
			if (lastCharIsDelim || i === startFrom) result.push("");
			lastCharIsDelim = true;
			i++;
			continue;
		}
		lastCharIsDelim = false;
		if (char === "\\") {
			i += 2;
			continue;
		}
		if (char === "\"") {
			const [value, startFrom] = parseCockroachArrayValue(arrayString, i + 1, true, delim);
			result.push(value);
			i = startFrom;
			continue;
		}
		if (char === "}") return [result, i + 1];
		if (char === "{") {
			const [value, startFrom] = parseCockroachNestedArray(arrayString, i + 1, delim);
			result.push(value);
			i = startFrom;
			continue;
		}
		const [value, newStartFrom] = parseCockroachArrayValue(arrayString, i, false, delim);
		result.push(value === "NULL" ? null : value);
		i = newStartFrom;
	}
	return [result, i];
}
function parseCockroachArray(arrayString, delim = DEFAULT_DELIM) {
	const [result] = parseCockroachNestedArray(arrayString, 1, delim);
	return result;
}
function buildCockroachArray(array, delim) {
	return `{${array.map((item) => {
		if (Array.isArray(item)) return buildCockroachArray(item, delim);
		if (typeof item === "string") return `"${item.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"`;
		return `${item}`;
	}).join(delim)}}`;
}
function makeCockroachArray(array, delim = DEFAULT_DELIM) {
	return buildCockroachArray(array, delim);
}
//#endregion
exports.makeCockroachArray = makeCockroachArray;
exports.parseCockroachArray = parseCockroachArray;
exports.parseCockroachNestedArray = parseCockroachNestedArray;

//# sourceMappingURL=array.cjs.map