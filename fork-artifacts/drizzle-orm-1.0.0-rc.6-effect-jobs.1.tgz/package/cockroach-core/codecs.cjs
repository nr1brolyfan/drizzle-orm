Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_cockroach_core_array = require("./array.cjs");
const require_cockroach_core_columns_utils = require("./columns/utils.cjs");
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __temporal_text_ts = require("../temporal-text.cjs");
//#region src/cockroach-core/codecs.ts
const COCKROACH_ALIAS_TO_TYPE_MAP = {
	smallint: "int2",
	int2: "int2",
	integer: "int4",
	int: "int4",
	int4: "int4",
	bigint: "int8",
	int64: "int8",
	int8: "int8",
	numeric: "decimal",
	dec: "decimal",
	float8: "float",
	"double precision": "float",
	float4: "real",
	boolean: "bool",
	character: "char",
	"character varying": "varchar",
	text: "string",
	timestamptz: "timestamptz",
	timetz: "time",
	"bit varying": "varbit"
};
function resolveCockroachTypeAlias(type) {
	return COCKROACH_ALIAS_TO_TYPE_MAP[type] ?? type;
}
const castToText = (name) => __sql_sql_ts.sql`${name}::text`;
const castToTextArr = (name, arrayDimensions) => __sql_sql_ts.sql`${name}::text${__sql_sql_ts.sql.raw("[]".repeat(arrayDimensions))}`;
const arrayCompatNormalize = (normalize) => {
	const loop = (value, arrayDimensions) => {
		if (value === null) return value;
		const innerDimensions = arrayDimensions - 1;
		if (arrayDimensions > 1) for (let i = 0; i < value.length; ++i) loop(value[i], innerDimensions);
		else for (let i = 0; i < value.length; ++i) value[i] = value[i] === null ? null : normalize(value[i]);
		return value;
	};
	return loop;
};
const parseArrayAndNormalize = (normalize, delim) => {
	const codec = arrayCompatNormalize(normalize);
	return (value, arrayDimensions) => codec(require_cockroach_core_array.parseCockroachArray(value, delim), arrayDimensions);
};
const parseGeometryArrayAndNormalize = (normalize) => parseArrayAndNormalize(normalize, ":");
const makeGeometryArray = (value) => require_cockroach_core_array.makeCockroachArray(value, ":");
const parseArray = (value) => require_cockroach_core_array.parseCockroachArray(value);
const parseCockroachVector = (v) => {
	const body = v.slice(1, -1);
	if (!body.length) return [];
	return body.split(",").map(Number.parseFloat);
};
const parseGeometryTuple = (v) => require_cockroach_core_columns_utils.parseEWKB(v).point;
const parseGeometryXY = (v) => {
	const parsed = require_cockroach_core_columns_utils.parseEWKB(v);
	return {
		x: parsed.point[0],
		y: parsed.point[1]
	};
};
/** `date`, `timestamptz` array literal to `Date[]` */
const textToDateArray = parseArrayAndNormalize(__temporal_text_ts.textToDate);
/** `timestamp` array literal to `Date[]`, values read as UTC */
const textToDateWithTzArray = parseArrayAndNormalize(__temporal_text_ts.textToDateWithTz);
const genericCockroachCodecs = {
	int2: {
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	int4: {
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	real: {
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	float: {
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	int8: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: BigInt,
		normalizeArrayInJson: arrayCompatNormalize(BigInt)
	},
	"int8:number": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	decimal: {
		castInJson: castToText,
		castArrayInJson: castToTextArr
	},
	"decimal:number": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: Number,
		normalizeArrayInJson: arrayCompatNormalize(Number)
	},
	"decimal:bigint": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: BigInt,
		normalizeArrayInJson: arrayCompatNormalize(BigInt)
	},
	date: {
		normalizeInJson: __temporal_text_ts.textToDate,
		normalizeArrayInJson: arrayCompatNormalize(__temporal_text_ts.textToDate)
	},
	timestamp: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: __temporal_text_ts.textToDateWithTz,
		normalizeArrayInJson: arrayCompatNormalize(__temporal_text_ts.textToDateWithTz)
	},
	"timestamp:string": {
		castInJson: castToText,
		castArrayInJson: castToTextArr
	},
	timestamptz: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: __temporal_text_ts.textToDate,
		normalizeArrayInJson: arrayCompatNormalize(__temporal_text_ts.textToDate)
	},
	"timestamptz:string": {
		castInJson: castToText,
		castArrayInJson: castToTextArr
	},
	geometry: {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parseGeometryTuple,
		normalizeArrayInJson: arrayCompatNormalize(parseGeometryTuple)
	},
	"geometry:xy": {
		castInJson: castToText,
		castArrayInJson: castToTextArr,
		normalizeInJson: parseGeometryXY,
		normalizeArrayInJson: arrayCompatNormalize(parseGeometryXY)
	},
	vector: {
		normalizeInJson: parseCockroachVector,
		normalizeArrayInJson: arrayCompatNormalize(parseCockroachVector)
	}
};
const unionsTypeTable = {
	int2: {
		int2: "int2",
		int4: "int4",
		int8: "int8:number",
		"int8:number": "int8:number",
		decimal: "decimal:number",
		"decimal:number": "decimal:number",
		"decimal:bigint": "decimal:number",
		float: "float",
		real: "real"
	},
	int4: {
		int2: "int4",
		int4: "int4",
		int8: "int8:number",
		"int8:number": "int8:number",
		decimal: "decimal:number",
		"decimal:number": "decimal:number",
		"decimal:bigint": "decimal:number",
		float: "float",
		real: "real"
	},
	int8: {
		int2: "int8",
		int4: "int8",
		int8: "int8",
		"int8:number": "int8",
		decimal: "decimal:bigint",
		"decimal:number": "decimal:bigint",
		"decimal:bigint": "decimal:bigint",
		float: "float",
		real: "real"
	},
	"int8:number": {
		int2: "int8:number",
		int4: "int8:number",
		int8: "int8:number",
		"int8:number": "int8:number",
		decimal: "decimal:number",
		"decimal:number": "decimal:number",
		"decimal:bigint": "decimal:number",
		float: "float",
		real: "real"
	},
	decimal: {
		int2: "decimal",
		int4: "decimal",
		int8: "decimal",
		"int8:number": "decimal",
		decimal: "decimal",
		"decimal:number": "decimal",
		"decimal:bigint": "decimal",
		float: "decimal",
		real: "decimal"
	},
	"decimal:number": {
		int2: "decimal:number",
		int4: "decimal:number",
		int8: "decimal:number",
		"int8:number": "decimal:number",
		decimal: "decimal:number",
		"decimal:number": "decimal:number",
		"decimal:bigint": "decimal:number",
		float: "decimal:number",
		real: "decimal:number"
	},
	"decimal:bigint": {
		int2: "decimal:bigint",
		int4: "decimal:bigint",
		int8: "decimal:bigint",
		"int8:number": "decimal:bigint",
		decimal: "decimal:bigint",
		"decimal:number": "decimal:bigint",
		"decimal:bigint": "decimal:bigint",
		float: "decimal:bigint",
		real: "decimal:bigint"
	},
	float: {
		int2: "float",
		int4: "float",
		int8: "float",
		"int8:number": "float",
		decimal: "decimal:number",
		"decimal:number": "decimal:number",
		"decimal:bigint": "decimal:number",
		float: "float",
		real: "float"
	},
	real: {
		int2: "real",
		int4: "real",
		int8: "real",
		"int8:number": "real",
		decimal: "decimal:number",
		"decimal:number": "decimal:number",
		"decimal:bigint": "decimal:number",
		float: "float",
		real: "real"
	},
	bool: { bool: "bool" },
	char: {
		char: "char",
		varchar: "varchar",
		string: "char"
	},
	varchar: {
		char: "varchar",
		varchar: "varchar",
		string: "varchar"
	},
	string: {
		char: "char",
		varchar: "varchar",
		string: "string"
	},
	enum: { enum: "enum" },
	bit: {
		bit: "bit",
		varbit: "varbit"
	},
	varbit: {
		bit: "varbit",
		varbit: "varbit"
	},
	date: {
		date: "date",
		"date:string": "date"
	},
	"date:string": {
		date: "date:string",
		"date:string": "date:string"
	},
	time: { time: "time" },
	timestamp: {
		timestamp: "timestamp",
		"timestamp:string": "timestamp"
	},
	"timestamp:string": {
		timestamp: "timestamp:string",
		"timestamp:string": "timestamp:string"
	},
	timestamptz: {
		timestamptz: "timestamptz",
		"timestamptz:string": "timestamptz"
	},
	"timestamptz:string": {
		timestamptz: "timestamptz:string",
		"timestamptz:string": "timestamptz:string"
	},
	interval: { interval: "interval" },
	jsonb: { jsonb: "jsonb" },
	uuid: { uuid: "uuid" },
	inet: { inet: "inet" },
	vector: { vector: "vector" },
	geometry: {
		geometry: "geometry",
		"geometry:xy": "geometry"
	},
	"geometry:xy": {
		geometry: "geometry:xy",
		"geometry:xy": "geometry:xy"
	}
};
function resolveUnionType(left, right) {
	return unionsTypeTable[left]?.[right];
}
const refineGenericCockroachCodecs = (extension) => (0, __codecs_ts.refineCodecs)(genericCockroachCodecs, extension);
//#endregion
exports.arrayCompatNormalize = arrayCompatNormalize;
exports.castToText = castToText;
exports.castToTextArr = castToTextArr;
exports.genericCockroachCodecs = genericCockroachCodecs;
exports.makeGeometryArray = makeGeometryArray;
exports.parseArray = parseArray;
exports.parseArrayAndNormalize = parseArrayAndNormalize;
exports.parseCockroachVector = parseCockroachVector;
exports.parseGeometryArrayAndNormalize = parseGeometryArrayAndNormalize;
exports.parseGeometryTuple = parseGeometryTuple;
exports.parseGeometryXY = parseGeometryXY;
exports.refineGenericCockroachCodecs = refineGenericCockroachCodecs;
exports.resolveCockroachTypeAlias = resolveCockroachTypeAlias;
exports.resolveUnionType = resolveUnionType;
exports.textToDate = __temporal_text_ts.textToDate;
exports.textToDateArray = textToDateArray;
exports.textToDateWithTz = __temporal_text_ts.textToDateWithTz;
exports.textToDateWithTzArray = textToDateWithTzArray;
exports.unionsTypeTable = unionsTypeTable;

//# sourceMappingURL=codecs.cjs.map