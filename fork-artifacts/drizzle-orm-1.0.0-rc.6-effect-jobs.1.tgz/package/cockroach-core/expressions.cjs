Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __sql_sql_ts = require("../sql/sql.cjs");
//#region src/cockroach-core/expressions.ts
function concat(column, value) {
	return __sql_sql_ts.sql`${column} || ${value}`;
}
function substring(column, options) {
	if (options.fromPattern !== void 0) return options.escape === void 0 ? __sql_sql_ts.sql`substring(${column} from ${options.fromPattern})` : __sql_sql_ts.sql`substring(${column}, ${options.fromPattern}, ${options.escape})`;
	const chunks = [__sql_sql_ts.sql`substring(`, column];
	if (options.from !== void 0) chunks.push(__sql_sql_ts.sql` from (${options.from})::int8`);
	if (options.for !== void 0) chunks.push(__sql_sql_ts.sql` for ${options.for}`);
	chunks.push(__sql_sql_ts.sql`)`);
	return __sql_sql_ts.sql.join(chunks);
}
//#endregion
exports.concat = concat;
exports.substring = substring;
var __sql_expressions_index_ts = require("../sql/expressions/index.cjs");
Object.keys(__sql_expressions_index_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __sql_expressions_index_ts[k];
		}
	});
});

//# sourceMappingURL=expressions.cjs.map