Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __column_ts = require("../../column.cjs");
let __tracing_utils_ts = require("../../tracing-utils.cjs");
let __cockroach_core_foreign_keys_ts = require("../foreign-keys.cjs");
//#region src/cockroach-core/columns/common.ts
var CockroachColumnBuilder = class {
	static [__entity_ts.entityKind] = "CockroachColumnBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	foreignKeyConfigs = [];
	/** @internal */
	config;
	constructor(name, dataType, columnType) {
		this.config = {
			name,
			keyAsName: name === "",
			notNull: false,
			default: void 0,
			hasDefault: false,
			primaryKey: false,
			isUnique: false,
			uniqueName: void 0,
			uniqueType: void 0,
			dataType,
			columnType,
			generated: void 0,
			defaultFn: void 0,
			onUpdateFn: void 0,
			generatedIdentity: void 0
		};
	}
	/**
	* Changes the data type of the column. Commonly used with `jsonb` columns. Also, useful for branded types.
	*
	* @example
	* ```ts
	* const users = cockroachTable('users', {
	* 	id: int4('id').$type<UserId>().primaryKey(),
	* 	details: jsonb('details').$type<UserDetails>().notNull(),
	* });
	* ```
	*/
	$type() {
		return this;
	}
	/**
	* Adds a `not null` clause to the column definition.
	*
	* Affects the `select` model of the table - columns *without* `not null` will be nullable on select.
	*/
	notNull() {
		this.config.notNull = true;
		return this;
	}
	/**
	* Adds a `default <value>` clause to the column definition.
	*
	* Affects the `insert` model of the table - columns *with* `default` are optional on insert.
	*
	* If you need to set a dynamic default value, use {@link $defaultFn} instead.
	*/
	default(value) {
		this.config.default = value;
		this.config.hasDefault = true;
		return this;
	}
	/**
	* Adds a dynamic default value to the column.
	* The function will be called when the row is inserted, and the returned value will be used as the column value.
	*
	* **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
	*/
	$defaultFn(fn) {
		this.config.defaultFn = fn;
		this.config.hasDefault = true;
		return this;
	}
	/**
	* Alias for {@link $defaultFn}.
	*/
	$default(fn) {
		return this.$defaultFn(fn);
	}
	/**
	* Adds a dynamic update value to the column.
	* The function will be called when the row is updated, and the returned value will be used as the column value if none is provided.
	* If no `default` (or `$defaultFn`) value is provided, the function will be called when the row is inserted as well, and the returned value will be used as the column value.
	*
	* **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
	*/
	$onUpdateFn(fn) {
		this.config.onUpdateFn = fn;
		this.config.hasDefault = true;
		return this;
	}
	/**
	* Alias for {@link $onUpdateFn}.
	*/
	$onUpdate(fn) {
		return this.$onUpdateFn(fn);
	}
	/**
	* Adds a `primary key` clause to the column definition. This implicitly makes the column `not null`.
	*/
	primaryKey() {
		this.config.primaryKey = true;
		this.config.notNull = true;
		return this;
	}
	/** @internal Sets the name of the column to the key within the table definition if a name was not given. */
	setName(name, casingFn) {
		if (this.config.name !== "") return;
		this.config.name = casingFn(name);
	}
	array(dimensions) {
		const dim = dimensions ?? "[]";
		this.config.dimensions = dim.length / 2;
		return this;
	}
	references(ref, config = {}) {
		this.foreignKeyConfigs.push({
			ref,
			config
		});
		return this;
	}
	unique(name) {
		this.config.isUnique = true;
		this.config.uniqueName = name;
		return this;
	}
	generatedAlwaysAs(as) {
		this.config.generated = {
			as,
			type: "always",
			mode: "stored"
		};
		return this;
	}
	/** @internal */
	buildForeignKeys(column, table) {
		return this.foreignKeyConfigs.map(({ ref, config }) => {
			return (0, __tracing_utils_ts.iife)((ref, config) => {
				const builder = new __cockroach_core_foreign_keys_ts.ForeignKeyBuilder(() => {
					const foreignColumn = ref();
					return {
						name: config.name,
						columns: [column],
						foreignColumns: [foreignColumn]
					};
				});
				if (config.onUpdate) builder.onUpdate(config.onUpdate);
				if (config.onDelete) builder.onDelete(config.onDelete);
				return builder.build(table);
			}, ref, config);
		});
	}
	/** @internal */
	buildExtraConfigColumn(table) {
		const column = new ExtraConfigColumn(table, {
			...this.config,
			dimensions: this.config.dimensions ?? 0
		});
		column.sqlTypeResolver = () => this.build(table).getSQLType();
		return column;
	}
};
var CockroachColumn = class extends __column_ts.Column {
	static [__entity_ts.entityKind] = "CockroachColumn";
	/** @internal */
	table;
	dimensions;
	constructor(table, config) {
		super(table, config);
		this.table = table;
		this.dimensions = config.dimensions ?? 0;
	}
	/** @internal */
	postBuild() {
		if (this.dimensions) {
			const originalFromDriver = this.mapFromDriverValue.bind(this);
			const originalToDriver = this.mapToDriverValue.bind(this);
			this.mapFromDriverValue = this.mapFromDriverValue.isNoop ? this.mapFromDriverValue : (value) => {
				return this.mapArrayElements(value, originalFromDriver, this.dimensions);
			};
			this.mapToDriverValue = this.mapToDriverValue.isNoop ? this.mapToDriverValue : (value) => {
				return this.mapArrayElements(value, originalToDriver, this.dimensions);
			};
		}
		return this;
	}
	/** @internal */
	shouldDisableInsert() {
		return this.config.generatedIdentity !== void 0 && this.config.generatedIdentity.type !== "byDefault" || this.config.generated !== void 0 && this.config.generated.type !== "byDefault";
	}
	/** @internal */
	mapArrayElements(value, mapper, depth) {
		if (depth > 0 && Array.isArray(value)) return value.map((v) => v === null ? null : this.mapArrayElements(v, mapper, depth - 1));
		return mapper(value);
	}
};
var ExtraConfigColumn = class extends CockroachColumn {
	static [__entity_ts.entityKind] = "ExtraConfigColumn";
	/** @internal */
	codec = void 0;
	/** @internal */
	sqlTypeResolver;
	cachedSQLType;
	getSQLType() {
		if (this.cachedSQLType === void 0) {
			if (!this.sqlTypeResolver) throw new Error(`Column "${this.name}" was built without SQL type resolver`);
			this.cachedSQLType = this.sqlTypeResolver();
		}
		return this.cachedSQLType;
	}
	indexConfig = { order: this.config.order ?? "asc" };
	defaultConfig = { order: "asc" };
	asc() {
		this.indexConfig.order = "asc";
		return this;
	}
	desc() {
		this.indexConfig.order = "desc";
		return this;
	}
};
var IndexedColumn = class {
	static [__entity_ts.entityKind] = "IndexedColumn";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(name, keyAsName, type, indexConfig) {
		this.name = name;
		this.keyAsName = keyAsName;
		this.type = type;
		this.indexConfig = indexConfig;
	}
	name;
	keyAsName;
	type;
	indexConfig;
};
//#endregion
exports.CockroachColumn = CockroachColumn;
exports.CockroachColumnBuilder = CockroachColumnBuilder;
exports.ExtraConfigColumn = ExtraConfigColumn;
exports.IndexedColumn = IndexedColumn;

//# sourceMappingURL=common.cjs.map