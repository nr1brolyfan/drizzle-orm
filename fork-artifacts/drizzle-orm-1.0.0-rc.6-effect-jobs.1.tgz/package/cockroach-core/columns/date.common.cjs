Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_cockroach_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
//#region src/cockroach-core/columns/date.common.ts
var CockroachDateColumnBaseBuilder = class extends require_cockroach_core_columns_common.CockroachColumnBuilder {
	static [__entity_ts.entityKind] = "CockroachDateColumnBaseBuilder";
	defaultNow() {
		return this.default(__sql_sql_ts.sql`now()`);
	}
};
const dateToTimestampText = (value) => {
	const iso = value.toISOString();
	const first = iso.charCodeAt(0);
	if (first === 43) return iso.replace(/^\+0*/, "");
	if (first === 45 || iso.startsWith("0000")) return `${String(1 - value.getUTCFullYear()).padStart(4, "0")}${iso.slice(iso.indexOf("-", 1))} BC`;
	return iso;
};
//#endregion
exports.CockroachDateColumnBaseBuilder = CockroachDateColumnBaseBuilder;
exports.dateToTimestampText = dateToTimestampText;

//# sourceMappingURL=date.common.cjs.map