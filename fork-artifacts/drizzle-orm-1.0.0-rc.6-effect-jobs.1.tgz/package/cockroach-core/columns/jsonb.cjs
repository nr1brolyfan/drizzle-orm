Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_cockroach_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
//#region src/cockroach-core/columns/jsonb.ts
var CockroachJsonbBuilder = class extends require_cockroach_core_columns_common.CockroachColumnBuilder {
	static [__entity_ts.entityKind] = "CockroachJsonbBuilder";
	constructor(name) {
		super(name, "object json", "CockroachJsonb");
	}
	/**
	* @throws always - CockroachDB has no array type for `jsonb`
	*/
	array() {
		throw new Error("CockroachDB does not support arrays of jsonb columns");
	}
	/** @internal */
	build(table) {
		return new CockroachJsonb(table, this.config);
	}
};
var CockroachJsonb = class extends require_cockroach_core_columns_common.CockroachColumn {
	static [__entity_ts.entityKind] = "CockroachJsonb";
	/** @internal */
	codec = "jsonb";
	constructor(table, config) {
		super(table, config);
	}
	getSQLType() {
		return "jsonb";
	}
	mapToDriverValue = (value) => {
		return JSON.stringify(value);
	};
};
function jsonb(name) {
	return new CockroachJsonbBuilder(name ?? "");
}
//#endregion
exports.CockroachJsonb = CockroachJsonb;
exports.CockroachJsonbBuilder = CockroachJsonbBuilder;
exports.jsonb = jsonb;

//# sourceMappingURL=jsonb.cjs.map