Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_column_common = require("./column-common.cjs");
const require_entity = require("./entity.cjs");
const require_column = require("./column.cjs");
const require_table_utils = require("./table.utils.cjs");
const require_table = require("./table.cjs");
const require_sql_sql = require("./sql/sql.cjs");
const require_view_common = require("./view-common.cjs");
//#region src/alias.ts
var ColumnTableAliasProxyHandler = class {
	table;
	ignoreColumnAlias;
	static [require_entity.entityKind] = "ColumnTableAliasProxyHandler";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(table, ignoreColumnAlias) {
		this.table = table;
		this.ignoreColumnAlias = ignoreColumnAlias;
	}
	get(columnObj, prop) {
		if (prop === "table") return this.table;
		if (prop === "isAlias" && this.ignoreColumnAlias) return false;
		if (prop === require_column_common.OriginalColumn && !this.ignoreColumnAlias) return () => columnObj;
		return columnObj[prop];
	}
};
var ViewSelectionAliasProxyHandler = class {
	view;
	selection;
	ignoreColumnAlias;
	static [require_entity.entityKind] = "ViewSelectionAliasProxyHandler";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(view, selection, ignoreColumnAlias) {
		this.view = view;
		this.selection = selection;
		this.ignoreColumnAlias = ignoreColumnAlias;
	}
	memo;
	columnHandler;
	get(selection, prop) {
		const value = selection[prop];
		if (typeof value !== "object" || value === null) return value;
		const memo = this.memo ??= /* @__PURE__ */ new WeakMap();
		let result = memo.get(value);
		if (result !== void 0) return result;
		if (require_sql_sql.isChunk(value, require_sql_sql.chunkKindOf(value), require_sql_sql.chunkKinds.column)) result = new Proxy(value, this.columnHandler ??= new ColumnTableAliasProxyHandler(this.view, this.ignoreColumnAlias));
		else if (require_sql_sql.isSQLWrapper(value)) result = value;
		else result = new Proxy(value, this);
		memo.set(value, result);
		return result;
	}
};
var TableAliasProxyHandler = class {
	alias;
	replaceOriginalName;
	ignoreColumnAlias;
	static [require_entity.entityKind] = "TableAliasProxyHandler";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(alias, replaceOriginalName, ignoreColumnAlias) {
		this.alias = alias;
		this.replaceOriginalName = replaceOriginalName;
		this.ignoreColumnAlias = ignoreColumnAlias;
	}
	/** Alias as identifier, replaces `[Qualifier]` of tables */
	qualifier;
	/** Aliased columns by name, fast path for table columns */
	proxiedColumns;
	/** For other props, columns & qualifier are hot paths and defined in their own variables due to performance benefits */
	memo;
	columnHandler;
	get(target, prop, receiver) {
		if (prop === require_table_utils.Qualifier) return this.qualifier ??= require_sql_sql.sql.identifier(this.alias);
		if (prop === require_table.Table.Symbol.IsAlias) return true;
		if (prop === require_table.Table.Symbol.Name) return this.alias;
		if (this.replaceOriginalName && prop === require_table.Table.Symbol.OriginalName) return this.alias;
		if (prop === require_table.Table.Symbol.Columns) {
			const columns = target[require_table.Table.Symbol.Columns];
			if (!columns) return columns;
			return require_sql_sql.isChunk(target, require_sql_sql.chunkKindOf(target), require_sql_sql.chunkKinds.view) ? this.aliasSelection(columns, receiver) : this.getProxiedColumns(columns, receiver);
		}
		if (prop === require_view_common.ViewBaseConfig) {
			const config = target[require_view_common.ViewBaseConfig];
			const memo = this.memo ??= /* @__PURE__ */ new WeakMap();
			let result = memo.get(config);
			if (result === void 0) memo.set(config, result = {
				...config,
				name: this.alias,
				isAlias: true,
				selectedFields: this.aliasSelection(config.selectedFields, receiver)
			});
			return result;
		}
		const value = target[prop];
		if (require_sql_sql.isChunk(value, require_sql_sql.chunkKindOf(value), require_sql_sql.chunkKinds.column)) {
			const columns = target[require_table.Table.Symbol.Columns];
			if (typeof prop === "string" && columns?.[prop] === value) return this.getProxiedColumns(columns, receiver)[prop];
			const memo = this.memo ??= /* @__PURE__ */ new WeakMap();
			let result = memo.get(value);
			if (result === void 0) memo.set(value, result = this.aliasColumn(value, receiver));
			return result;
		}
		return value;
	}
	aliasColumn(column, receiver) {
		return new Proxy(column, this.columnHandler ??= new ColumnTableAliasProxyHandler(receiver, this.ignoreColumnAlias));
	}
	aliasSelection(selection, receiver) {
		const memo = this.memo ??= /* @__PURE__ */ new WeakMap();
		let result = memo.get(selection);
		if (result === void 0) memo.set(selection, result = new Proxy(selection, new ViewSelectionAliasProxyHandler(receiver, selection, this.ignoreColumnAlias)));
		return result;
	}
	getProxiedColumns(columns, receiver) {
		if (this.proxiedColumns) return this.proxiedColumns;
		const proxiedColumns = {};
		for (const key of Object.keys(columns)) proxiedColumns[key] = this.aliasColumn(columns[key], receiver);
		return this.proxiedColumns = proxiedColumns;
	}
};
var SubquerySelectionAliasProxyHandler = class {
	subquery;
	alias;
	static [require_entity.entityKind] = "SubquerySelectionAliasProxyHandler";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(subquery, alias) {
		this.subquery = subquery;
		this.alias = alias;
	}
	memo;
	columnHandler;
	get(selection, prop) {
		const value = selection[prop];
		if (typeof value !== "object" || value === null) return value;
		const memo = this.memo ??= /* @__PURE__ */ new WeakMap();
		let result = memo.get(value);
		if (result !== void 0) return result;
		const kind = require_sql_sql.chunkKindOf(value);
		if (require_sql_sql.isChunk(value, kind, require_sql_sql.chunkKinds.column)) result = new Proxy(value, this.columnHandler ??= new ColumnTableAliasProxyHandler(this.subquery, true));
		else if (require_sql_sql.isChunk(value, kind, require_sql_sql.chunkKinds.aliased)) {
			result = value.clone();
			result.isSelectionField = true;
			result.origin = this.alias;
		} else result = value;
		memo.set(value, result);
		return result;
	}
};
var SubqueryAliasProxyHandler = class {
	alias;
	static [require_entity.entityKind] = "SubqueryAliasProxyHandler";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(alias) {
		this.alias = alias;
	}
	/** Alias as identifier, replaces `[Qualifier]` of subqueries */
	qualifier;
	config;
	selection;
	get(target, prop, receiver) {
		if (prop === require_table_utils.Qualifier) return this.qualifier ??= require_sql_sql.sql.identifier(this.alias);
		if (prop === require_table.Table.Symbol.IsAlias) return true;
		if (prop === require_table.Table.Symbol.Name) return this.alias;
		if (prop === require_table.Table.Symbol.OriginalName) return target._.alias;
		if (prop === require_table.Table.Symbol.Schema) return;
		if (prop === "_") return this.config ??= {
			...target._,
			alias: this.alias,
			isWith: true,
			selectedFields: this.aliasSelection(target, receiver)
		};
		if (prop === require_table.Table.Symbol.Columns) return this.aliasSelection(target, receiver);
		return target[prop];
	}
	aliasSelection(target, receiver) {
		return this.selection ??= new Proxy(target._.selectedFields, new SubquerySelectionAliasProxyHandler(receiver, this.alias));
	}
};
var ColumnAliasProxyHandler = class {
	alias;
	static [require_entity.entityKind] = "ColumnAliasProxyHandler";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(alias) {
		this.alias = alias;
	}
	get(target, prop) {
		if (prop === "isAlias") return true;
		if (prop === "name") return this.alias;
		if (prop === "keyAsName") return false;
		if (prop === require_column_common.OriginalColumn) return () => target;
		return target[prop];
	}
};
var RelationTableAliasProxyHandler = class {
	alias;
	static [require_entity.entityKind] = "RelationTableAliasProxyHandler";
	static [Symbol.hasInstance](value) {
		return require_entity.is(value, this);
	}
	constructor(alias) {
		this.alias = alias;
	}
	get(target, prop) {
		if (prop === "sourceTable") return aliasedTable(target.sourceTable, this.alias);
		return target[prop];
	}
};
/**
* Does not apply type-level transformation
*
* For typed alias, use `import { alias } from 'drizzle-orm/dialect-core/alias'`
*/
function aliasedTable(table, tableAlias) {
	return require_sql_sql.isChunk(table, require_sql_sql.chunkKindOf(table), require_sql_sql.chunkKinds.subquery) ? new Proxy(table, new SubqueryAliasProxyHandler(tableAlias)) : new Proxy(table, new TableAliasProxyHandler(tableAlias, false, false));
}
function aliasedTableSQL(table) {
	const schema = table[require_table.Table.Symbol.Schema];
	const name = require_sql_sql.sql.identifier(table[require_table.Table.Symbol.OriginalName]);
	return schema ? require_sql_sql.sql`${require_sql_sql.sql.identifier(schema)}.${name} ${table}` : require_sql_sql.sql`${name} ${table}`;
}
function aliasedColumn(column, alias) {
	return new Proxy(column, new ColumnAliasProxyHandler(alias));
}
function aliasedRelation(relation, tableAlias) {
	return new Proxy(relation, new RelationTableAliasProxyHandler(tableAlias));
}
function aliasedTableColumn(column, tableAlias) {
	return new Proxy(column, new ColumnTableAliasProxyHandler(new Proxy(column.table, new TableAliasProxyHandler(tableAlias, false, false)), false));
}
function mapColumnsInAliasedSQLToAlias(query, alias) {
	return new require_sql_sql.SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
}
function mapColumnsInSQLToAlias(query, alias) {
	return require_sql_sql.sql.join(query.queryChunks.map((c) => {
		const kind = require_sql_sql.chunkKindOf(c);
		if (require_sql_sql.isChunk(c, kind, require_sql_sql.chunkKinds.column)) return aliasedTableColumn(c, alias);
		if (require_sql_sql.isChunk(c, kind, require_sql_sql.chunkKinds.sql)) return mapColumnsInSQLToAlias(c, alias);
		if (require_sql_sql.isChunk(c, kind, require_sql_sql.chunkKinds.aliased)) return mapColumnsInAliasedSQLToAlias(c, alias);
		return c;
	}));
}
require_column.Column.prototype.as = function(alias) {
	return aliasedColumn(this, alias);
};
function getOriginalColumnFromAlias(column) {
	return column[require_column_common.OriginalColumn]();
}
//#endregion
exports.ColumnAliasProxyHandler = ColumnAliasProxyHandler;
exports.ColumnTableAliasProxyHandler = ColumnTableAliasProxyHandler;
exports.RelationTableAliasProxyHandler = RelationTableAliasProxyHandler;
exports.SubqueryAliasProxyHandler = SubqueryAliasProxyHandler;
exports.SubquerySelectionAliasProxyHandler = SubquerySelectionAliasProxyHandler;
exports.TableAliasProxyHandler = TableAliasProxyHandler;
exports.ViewSelectionAliasProxyHandler = ViewSelectionAliasProxyHandler;
exports.aliasedColumn = aliasedColumn;
exports.aliasedRelation = aliasedRelation;
exports.aliasedTable = aliasedTable;
exports.aliasedTableColumn = aliasedTableColumn;
exports.aliasedTableSQL = aliasedTableSQL;
exports.getOriginalColumnFromAlias = getOriginalColumnFromAlias;
exports.mapColumnsInAliasedSQLToAlias = mapColumnsInAliasedSQLToAlias;
exports.mapColumnsInSQLToAlias = mapColumnsInSQLToAlias;

//# sourceMappingURL=alias.cjs.map