Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.cjs");
let __entity_ts = require("../entity.cjs");
let effect_Schema = require("effect/Schema");
effect_Schema = require_runtime.__toESM(effect_Schema, 1);
//#region src/effect-core/errors.ts
var EffectDrizzleError = class extends effect_Schema.TaggedError()("EffectDrizzleError", {
	message: effect_Schema.String,
	cause: effect_Schema.Unknown
}) {
	static [__entity_ts.entityKind] = "EffectDrizzleError";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
};
var EffectDrizzleQueryError = class EffectDrizzleQueryError extends effect_Schema.TaggedError()("EffectDrizzleQueryError", {
	query: effect_Schema.String,
	params: effect_Schema.UndefinedOr(effect_Schema.Array(effect_Schema.Any).pipe(effect_Schema.mutable)),
	cause: effect_Schema.Unknown
}) {
	static [__entity_ts.entityKind] = "EffectDrizzleQueryError";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	get message() {
		return this.params ? `Failed query: ${this.query}\nparams: ${this.params}` : `Failed query: ${this.query}`;
	}
	constructor(params) {
		super(params);
		Error.captureStackTrace(this, EffectDrizzleQueryError);
	}
};
var EffectTransactionRollbackError = class extends effect_Schema.TaggedError()("EffectTransactionRollbackError", {}) {
	static [__entity_ts.entityKind] = "EffectTransactionRollbackError";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	message = "Rollback";
};
var MigratorInitError = class extends effect_Schema.TaggedError()("MigratorInitError", { exitCode: effect_Schema.Literals(["databaseMigrations", "localMigrations"]) }) {
	static [__entity_ts.entityKind] = "MigratorInitError";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
};
//#endregion
exports.EffectDrizzleError = EffectDrizzleError;
exports.EffectDrizzleQueryError = EffectDrizzleQueryError;
exports.EffectTransactionRollbackError = EffectTransactionRollbackError;
exports.MigratorInitError = MigratorInitError;

//# sourceMappingURL=errors.cjs.map