Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/effect-core/defaults.ts
const DefaultServices = require("./logger.cjs").EffectLogger.Default;
//#endregion
exports.DefaultServices = DefaultServices;

//# sourceMappingURL=defaults.cjs.map