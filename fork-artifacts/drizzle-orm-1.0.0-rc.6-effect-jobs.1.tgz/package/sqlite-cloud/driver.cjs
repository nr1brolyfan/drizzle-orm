Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_cloud_codecs = require("./codecs.cjs");
const require_sqlite_cloud_session = require("./session.cjs");
let __entity_ts = require("../entity.cjs");
let __utils_ts = require("../utils.cjs");
let __logger_ts = require("../logger.cjs");
let __sqlite_core_async_db_ts = require("../sqlite-core/async/db.cjs");
let __sqlite_core_dialect_ts = require("../sqlite-core/dialect.cjs");
let _sqlitecloud_drivers = require("@sqlitecloud/drivers");
//#region src/sqlite-cloud/driver.ts
var SQLiteCloudDatabase = class extends __sqlite_core_async_db_ts.SQLiteAsyncDatabase {
	static [__entity_ts.entityKind] = "SQLiteCloudDatabase";
};
/** @internal */
function construct(client, config = {}) {
	const dialect = new __sqlite_core_dialect_ts.SQLiteDialect({
		codecs: config.codecs ?? require_sqlite_cloud_codecs.sqliteCloudCodecs,
		useJitMappers: (0, __utils_ts.jitCompatCheck)(config.jit)
	});
	let logger;
	if (config.logger === true) logger = new __logger_ts.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	const relations = config.relations ?? {};
	const db = new SQLiteCloudDatabase("async", dialect, new require_sqlite_cloud_session.SQLiteCloudSession(client, dialect, relations, {
		logger,
		paramsInErrors: config.paramsInErrors
	}), relations);
	db.$client = client;
	return db;
}
/**
* Driver quirks:
* - Integers past the safe integer range are read as numbers: `numeric` columns throw on them
*/
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(new _sqlitecloud_drivers.Database(params[0]), params[1]);
	const { connection, client, ...DrizzleSQLiteConfig } = params[0];
	if (client) return construct(client, DrizzleSQLiteConfig);
	return construct(typeof connection === "string" ? new _sqlitecloud_drivers.Database(connection) : new _sqlitecloud_drivers.Database(connection.path, connection), DrizzleSQLiteConfig);
}
(function(_drizzle) {
	function mock(config) {
		return construct({}, config);
	}
	_drizzle.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
exports.SQLiteCloudDatabase = SQLiteCloudDatabase;
exports.construct = construct;
Object.defineProperty(exports, "drizzle", {
	enumerable: true,
	get: function() {
		return drizzle;
	}
});

//# sourceMappingURL=driver.cjs.map