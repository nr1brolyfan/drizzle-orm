Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __utils_ts = require("../utils.cjs");
let __pg_core_array_ts = require("../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../pg-core/codecs.cjs");
//#region src/pglite/codecs.ts
const pgliteCodecs = (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
	bigint: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"bigint:string": {
		normalize: String,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(String)
	},
	"bigint:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	bigserial: {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"bigserial:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number)
	},
	bytea: {
		normalizeInJson: typeof Buffer === "undefined" ? __utils_ts.pgHexToUint8Array : __pg_core_codecs_ts.genericPgCodecs.bytea?.normalizeInJson,
		normalizeArrayInJson: typeof Buffer === "undefined" ? (0, __pg_core_codecs_ts.arrayCompatNormalize)(__utils_ts.pgHexToUint8Array) : __pg_core_codecs_ts.genericPgCodecs.bytea?.normalizeArrayInJson,
		normalize: typeof Buffer === "undefined" ? void 0 : (v) => Buffer.from(v),
		normalizeArray: typeof Buffer === "undefined" ? void 0 : (0, __pg_core_codecs_ts.arrayCompatNormalize)((v) => Buffer.from(v))
	},
	interval: { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	date: {
		normalize: __pg_core_codecs_ts.textToDate,
		normalizeArray: __pg_core_codecs_ts.textToDatePgArray
	},
	"date:string": { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	timestamp: {
		normalize: __pg_core_codecs_ts.textToDateWithTz,
		normalizeArray: __pg_core_codecs_ts.textToDateWithTzPgArray
	},
	timestamptz: {
		normalize: __pg_core_codecs_ts.textToDate,
		normalizeArray: __pg_core_codecs_ts.textToDatePgArray
	},
	"timestamp:string": { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	"timestamptz:string": { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	json: {
		normalizeParam: (v) => typeof v === "object" ? v : JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	jsonb: {
		normalizeParam: (v) => typeof v === "object" ? v : JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	enum: {
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings
	},
	numeric: { normalizeArray: __pg_core_codecs_ts.parsePgArrayOfStrings },
	"numeric:number": {
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(Number)
	},
	"numeric:bigint": {
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(BigInt)
	},
	line: {
		normalize: __pg_core_codecs_ts.parseLineABC,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineABC)
	},
	"line:tuple": {
		normalize: __pg_core_codecs_ts.parseLineTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineTuple)
	},
	point: {
		normalize: __pg_core_codecs_ts.parsePointXY,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointXY)
	},
	"point:tuple": {
		normalize: __pg_core_codecs_ts.parsePointTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointTuple)
	},
	"geometry(point)": {
		normalize: __pg_core_codecs_ts.parseGeometryXY,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryXY),
		castParam: (name) => `${name}::geometry`,
		castArrayParam: (name, _column, dimensions) => `${name}::geometry${"[]".repeat(dimensions)}`,
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	"geometry(point):tuple": {
		normalize: __pg_core_codecs_ts.parseGeometryTuple,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryTuple),
		castParam: (name) => `${name}::geometry`,
		castArrayParam: (name, _column, dimensions) => `${name}::geometry${"[]".repeat(dimensions)}`,
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	halfvec: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		castParam: (name) => `${name}::halfvec`,
		castArrayParam: (name, _column, dimensions) => `${name}::halfvec${"[]".repeat(dimensions)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	vector: {
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		castParam: (name) => `${name}::vector`,
		castArrayParam: (name, _column, dimensions) => `${name}::vector${"[]".repeat(dimensions)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	sparsevec: {
		normalizeArray: (v) => (0, __pg_core_array_ts.parsePgArray)(v),
		castParam: (name) => `${name}::sparsevec`,
		castArrayParam: (name, _column, dimensions) => `${name}::sparsevec${"[]".repeat(dimensions)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	}
});
//#endregion
exports.pgliteCodecs = pgliteCodecs;

//# sourceMappingURL=codecs.cjs.map