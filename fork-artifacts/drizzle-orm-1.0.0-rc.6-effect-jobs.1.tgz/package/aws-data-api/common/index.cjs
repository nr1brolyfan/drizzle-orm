Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __pg_core_array_ts = require("../../pg-core/array.cjs");
//#region src/aws-data-api/common/index.ts
function getValueFromDataApi(field) {
	if (field.stringValue !== void 0) return field.stringValue;
	if (field.booleanValue !== void 0) return field.booleanValue;
	if (field.doubleValue !== void 0) return field.doubleValue;
	if (field.isNull !== void 0) return null;
	if (field.longValue !== void 0) return field.longValue;
	if (field.blobValue !== void 0) return field.blobValue;
	if (field.arrayValue !== void 0) return getArrayFromDataApi(field.arrayValue);
	throw new Error("Unknown type");
}
function getArrayFromDataApi(value) {
	if (value.stringValues !== void 0) return value.stringValues;
	if (value.longValues !== void 0) return value.longValues;
	if (value.doubleValues !== void 0) return value.doubleValues;
	if (value.booleanValues !== void 0) return value.booleanValues;
	if (value.arrayValues !== void 0) return value.arrayValues.map(getArrayFromDataApi);
	throw new Error("Unknown array type");
}
function toValueParam(value) {
	if (value === null) return { isNull: true };
	const valueType = typeof value;
	if (valueType === "string") return { stringValue: value };
	if (valueType === "number") return Number.isInteger(value) ? { longValue: value } : { doubleValue: value };
	if (valueType === "boolean") return { booleanValue: value };
	if (valueType === "bigint") return { stringValue: value.toString() };
	if (value instanceof Date) return { stringValue: value.toISOString().replace("T", " ").replace("Z", "") };
	if (typeof Buffer !== "undefined" && Buffer.isBuffer(value) || value instanceof Uint8Array) return { blobValue: value };
	if (Array.isArray(value)) return { stringValue: (0, __pg_core_array_ts.makePgArray)(value) };
	if (valueType === "object") return { stringValue: JSON.stringify(value) };
	throw new Error(`Unknown type for ${value}`);
}
function toSqlParameter(name, value) {
	const field = toValueParam(value);
	if (value !== null && typeof value === "object" && !Array.isArray(value) && !(value instanceof Date) && field.stringValue !== void 0) return {
		name,
		value: field,
		typeHint: "JSON"
	};
	return {
		name,
		value: field
	};
}
//#endregion
exports.getValueFromDataApi = getValueFromDataApi;
exports.toSqlParameter = toSqlParameter;
exports.toValueParam = toValueParam;

//# sourceMappingURL=index.cjs.map