Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __migrator_ts = require("../../migrator.cjs");
let __pg_core_async_session_ts = require("../../pg-core/async/session.cjs");
//#region src/aws-data-api/pg/migrator.ts
async function migrate(db, config) {
	const migrations = (0, __migrator_ts.readMigrationFiles)(config);
	return await (0, __pg_core_async_session_ts.migrate)(migrations, db, config);
}
//#endregion
exports.migrate = migrate;

//# sourceMappingURL=migrator.cjs.map