Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __codecs_ts = require("../../codecs.cjs");
let __pg_core_array_ts = require("../../pg-core/array.cjs");
let __pg_core_codecs_ts = require("../../pg-core/codecs.cjs");
//#region src/aws-data-api/pg/codecs.ts
const byteaFromBlob = (v) => Buffer.from(v);
const inetFromText = (v) => v.endsWith(v.includes(":") ? "/128" : "/32") ? v.slice(0, v.lastIndexOf("/")) : v;
const driver = "aws-data-api";
const timestamptzTextReason = "Data API converts `timestamptz` values to UTC, dropping the offset the server formats in the session's time zone, and accepts no per-query result formats";
const timeTzReason = "Data API converts `timetz` values to UTC dropping their offset and accepts no per-query result formats";
const awsDataApiPgCodecs = (0, __pg_core_codecs_ts.refineGenericPgCodecs)({
	json: {
		castParam: (name) => `${name}::json`,
		castArrayParam: (name, _column, dim) => `${name}::json${"[]".repeat(dim)}`,
		normalize: (v) => JSON.parse(v),
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)((v) => JSON.parse(v)),
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	jsonb: {
		castParam: (name) => `${name}::jsonb`,
		castArrayParam: (name, _column, dim) => `${name}::jsonb${"[]".repeat(dim)}`,
		normalize: (v) => JSON.parse(v),
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)((v) => JSON.parse(v)),
		normalizeParam: (v) => JSON.stringify(v),
		normalizeParamArray: (0, __pg_core_codecs_ts.arrayCompatNormalizeInput)((v) => JSON.stringify(v), true)
	},
	bytea: {
		castParam: (name) => `${name}::bytea`,
		castArrayParam: (name, _column, dim) => `${name}::bytea${"[]".repeat(dim)}`,
		normalize: byteaFromBlob,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("bytea[]", driver, "Data API has no array type for binary values and returns `bytea[]` empty")
	},
	bit: {
		castParam: (name, column) => `${name}::bit(${column.length})`,
		castArrayParam: (name, column, dim) => `${name}::bit(${column.length})${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"geometry(point)": {
		castParam: (name) => `${name}::geometry`,
		castArrayParam: (name, _column, dim) => `${name}::geometry${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parseGeometryXY,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryXY),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	"geometry(point):tuple": {
		castParam: (name) => `${name}::geometry`,
		castArrayParam: (name, _column, dim) => `${name}::geometry${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parseGeometryTuple,
		normalizeArray: (0, __pg_core_codecs_ts.parseGeometryArrayAndNormalize)(__pg_core_codecs_ts.parseGeometryTuple),
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	interval: {
		castParam: (name) => `${name}::interval`,
		castArrayParam: (name, _column, dim) => `${name}::interval${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	line: {
		castParam: (name) => `${name}::line`,
		castArrayParam: (name, _column, dim) => `${name}::line${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parseLineABC,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineABC),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"line:tuple": {
		castParam: (name) => `${name}::line`,
		castArrayParam: (name, _column, dim) => `${name}::line${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parseLineTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parseLineTuple),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	macaddr: {
		castParam: (name) => `${name}::macaddr`,
		castArrayParam: (name, _column, dim) => `${name}::macaddr${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	macaddr8: {
		castArrayInJson: __pg_core_codecs_ts.castToTextArr,
		castParam: (name) => `${name}::macaddr8`,
		castArrayParam: (name, _column, dim) => `${name}::macaddr8${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	cidr: {
		castParam: (name) => `${name}::cidr`,
		castArrayParam: (name, _column, dim) => `${name}::cidr${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	inet: {
		castParam: (name) => `${name}::inet`,
		castArrayParam: (name, _column, dim) => `${name}::inet${"[]".repeat(dim)}`,
		normalize: inetFromText,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(inetFromText),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	point: {
		castParam: (name) => `${name}::point`,
		castArrayParam: (name, _column, dim) => `${name}::point${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parsePointXY,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointXY),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"point:tuple": {
		castParam: (name) => `${name}::point`,
		castArrayParam: (name, _column, dim) => `${name}::point${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parsePointTuple,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.parsePointTuple),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	halfvec: {
		castParam: (name) => `${name}::halfvec`,
		castArrayParam: (name, _column, dim) => `${name}::halfvec${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	sparsevec: {
		castParam: (name) => `${name}::sparsevec`,
		castArrayParam: (name, _column, dim) => `${name}::sparsevec${"[]".repeat(dim)}`,
		normalizeArray: (v) => (0, __pg_core_array_ts.parsePgArray)(v),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	vector: {
		castParam: (name) => `${name}::vector`,
		castArrayParam: (name, _column, dim) => `${name}::vector${"[]".repeat(dim)}`,
		normalize: __pg_core_codecs_ts.parsePgVector,
		normalizeArray: (0, __pg_core_codecs_ts.parsePgArrayAndNormalize)(__pg_core_codecs_ts.parsePgVector),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	bool: {
		castParam: (name) => `${name}::boolean`,
		castArrayParam: (name, _column, dim) => `${name}::boolean${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	box: {
		castParam: (name) => `${name}::box`,
		castArrayParam: (name, _column, dim) => `${name}::box${"[]".repeat(dim)}`,
		normalizeParamArray: __pg_core_codecs_ts.makeBoxArray
	},
	box2d: {
		castParam: (name) => `${name}::box2d`,
		castArrayParam: (name, _column, dim) => `${name}::box2d${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	box3d: {
		castParam: (name) => `${name}::box3d`,
		castArrayParam: (name, _column, dim) => `${name}::box3d${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	char: {
		castParam: (name, column) => `${name}::${column.getSQLType()}`,
		castArrayParam: (name, column, dim) => `${name}::${column.getSQLType()}${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	circle: {
		castParam: (name) => `${name}::circle`,
		castArrayParam: (name, _column, dim) => `${name}::circle${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	datemultirange: {
		castParam: (name) => `${name}::datemultirange`,
		castArrayParam: (name, _column, dim) => `${name}::datemultirange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	daterange: {
		castParam: (name) => `${name}::daterange`,
		castArrayParam: (name, _column, dim) => `${name}::daterange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	float8: {
		castParam: (name) => `${name}::double precision`,
		castArrayParam: (name, _column, dim) => `${name}::double precision${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"geography(point)": {
		castParam: (name) => `${name}::geography`,
		castArrayParam: (name, _column, dim) => `${name}::geography${"[]".repeat(dim)}`,
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	"geography(point):tuple": {
		castParam: (name) => `${name}::geography`,
		castArrayParam: (name, _column, dim) => `${name}::geography${"[]".repeat(dim)}`,
		normalizeParamArray: __pg_core_codecs_ts.makeGeometryArray
	},
	int4multirange: {
		castParam: (name) => `${name}::int4multirange`,
		castArrayParam: (name, _column, dim) => `${name}::int4multirange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	int4range: {
		castParam: (name) => `${name}::int4range`,
		castArrayParam: (name, _column, dim) => `${name}::int4range${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	int8multirange: {
		castParam: (name) => `${name}::int8multirange`,
		castArrayParam: (name, _column, dim) => `${name}::int8multirange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	int8range: {
		castParam: (name) => `${name}::int8range`,
		castArrayParam: (name, _column, dim) => `${name}::int8range${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	lseg: {
		castParam: (name) => `${name}::lseg`,
		castArrayParam: (name, _column, dim) => `${name}::lseg${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	money: {
		castParam: (name) => `${name}::money`,
		castArrayParam: (name, _column, dim) => `${name}::money${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	nummultirange: {
		castParam: (name) => `${name}::nummultirange`,
		castArrayParam: (name, _column, dim) => `${name}::nummultirange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	numrange: {
		castParam: (name) => `${name}::numrange`,
		castArrayParam: (name, _column, dim) => `${name}::numrange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	oid: {
		castParam: (name) => `${name}::oid`,
		castArrayParam: (name, _column, dim) => `${name}::oid${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	path: {
		castParam: (name) => `${name}::path`,
		castArrayParam: (name, _column, dim) => `${name}::path${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	polygon: {
		castParam: (name) => `${name}::polygon`,
		castArrayParam: (name, _column, dim) => `${name}::polygon${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	raster: {
		castParam: (name) => `${name}::raster`,
		castArrayParam: (name, _column, dim) => `${name}::raster${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regclass: {
		castParam: (name) => `${name}::regclass`,
		castArrayParam: (name, _column, dim) => `${name}::regclass${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regconfig: {
		castParam: (name) => `${name}::regconfig`,
		castArrayParam: (name, _column, dim) => `${name}::regconfig${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regdictionary: {
		castParam: (name) => `${name}::regdictionary`,
		castArrayParam: (name, _column, dim) => `${name}::regdictionary${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regnamespace: {
		castParam: (name) => `${name}::regnamespace`,
		castArrayParam: (name, _column, dim) => `${name}::regnamespace${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regoper: {
		castParam: (name) => `${name}::regoper`,
		castArrayParam: (name, _column, dim) => `${name}::regoper${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regoperator: {
		castParam: (name) => `${name}::regoperator`,
		castArrayParam: (name, _column, dim) => `${name}::regoperator${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regproc: {
		castParam: (name) => `${name}::regproc`,
		castArrayParam: (name, _column, dim) => `${name}::regproc${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regprocedure: {
		castParam: (name) => `${name}::regprocedure`,
		castArrayParam: (name, _column, dim) => `${name}::regprocedure${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regrole: {
		castParam: (name) => `${name}::regrole`,
		castArrayParam: (name, _column, dim) => `${name}::regrole${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	regtype: {
		castParam: (name) => `${name}::regtype`,
		castArrayParam: (name, _column, dim) => `${name}::regtype${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	serial: {
		castParam: (name) => `${name}::integer`,
		castArrayParam: (name, _column, dim) => `${name}::integer${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	smallint: {
		castParam: (name) => `${name}::smallint`,
		castArrayParam: (name, _column, dim) => `${name}::smallint${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	smallserial: {
		castParam: (name) => `${name}::smallint`,
		castArrayParam: (name, _column, dim) => `${name}::smallint${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	text: {
		castParam: (name) => `${name}::text`,
		castArrayParam: (name, _column, dim) => `${name}::text${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	time: {
		castParam: (name) => `${name}::time`,
		castArrayParam: (name, _column, dim) => `${name}::time${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	timetz: {
		castParam: (name) => `${name}::timetz`,
		castArrayParam: (name, _column, dim) => `${name}::timetz${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("time with time zone", driver, timeTzReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("time with time zone", driver, timeTzReason)
	},
	tsmultirange: {
		castParam: (name) => `${name}::tsmultirange`,
		castArrayParam: (name, _column, dim) => `${name}::tsmultirange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	tsquery: {
		castParam: (name) => `${name}::tsquery`,
		castArrayParam: (name, _column, dim) => `${name}::tsquery${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	tsrange: {
		castParam: (name) => `${name}::tsrange`,
		castArrayParam: (name, _column, dim) => `${name}::tsrange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	tstzmultirange: {
		castParam: (name) => `${name}::tstzmultirange`,
		castArrayParam: (name, _column, dim) => `${name}::tstzmultirange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	tstzrange: {
		castParam: (name) => `${name}::tstzrange`,
		castArrayParam: (name, _column, dim) => `${name}::tstzrange${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	tsvector: {
		castParam: (name) => `${name}::tsvector`,
		castArrayParam: (name, _column, dim) => `${name}::tsvector${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	varbit: {
		castParam: (name) => `${name}::varbit`,
		castArrayParam: (name, _column, dim) => `${name}::varbit${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	varchar: {
		castParam: (name) => `${name}::varchar`,
		castArrayParam: (name, _column, dim) => `${name}::varchar${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	xml: {
		castParam: (name) => `${name}::xml`,
		castArrayParam: (name, _column, dim) => `${name}::xml${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	enum: {
		castParam: (name, column) => `${name}::${column.getSQLType()}`,
		castArrayParam: (name, column, dimensions) => `${name}::${column.getSQLType()}${"[]".repeat(dimensions)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	numeric: {
		castParam: (name) => `${name}::numeric`,
		castArrayParam: (name, _column, dim) => `${name}::numeric${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"numeric:number": {
		castParam: (name) => `${name}::numeric`,
		castArrayParam: (name, _column, dim) => `${name}::numeric${"[]".repeat(dim)}`,
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"numeric:bigint": {
		castParam: (name) => `${name}::numeric`,
		castArrayParam: (name, _column, dim) => `${name}::numeric${"[]".repeat(dim)}`,
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	bigint: {
		castParam: (name) => `${name}::bigint`,
		castArrayParam: (name, _column, dim) => `${name}::bigint${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"bigint:number": {
		castParam: (name) => `${name}::bigint`,
		castArrayParam: (name, _column, dim) => `${name}::bigint${"[]".repeat(dim)}`,
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"bigint:string": {
		castParam: (name) => `${name}::bigint`,
		castArrayParam: (name, _column, dim) => `${name}::bigint${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: String,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(String)
	},
	bigserial: {
		castParam: (name) => `${name}::bigint`,
		castArrayParam: (name, _column, dim) => `${name}::bigint${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: BigInt,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(BigInt)
	},
	"bigserial:number": {
		castParam: (name) => `${name}::bigint`,
		castArrayParam: (name, _column, dim) => `${name}::bigint${"[]".repeat(dim)}`,
		normalize: Number,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(Number),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	date: {
		castParam: (name) => `${name}::date`,
		castArrayParam: (name, _column, dim) => `${name}::date${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: __pg_core_codecs_ts.textToDate,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.textToDate)
	},
	"date:string": {
		castParam: (name) => `${name}::date`,
		castArrayParam: (name, _column, dim) => `${name}::date${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	float4: {
		castParam: (name) => `${name}::real`,
		castArrayParam: (name, _column, dim) => `${name}::real${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	int: {
		castParam: (name) => `${name}::integer`,
		castArrayParam: (name, _column, dim) => `${name}::integer${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	timestamp: {
		castParam: (name) => `${name}::timestamp`,
		castArrayParam: (name, _column, dim) => `${name}::timestamp${"[]".repeat(dim)}`,
		normalizeParam: (value) => value.replace("T", " ").replace("Z", ""),
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: __pg_core_codecs_ts.textToDateWithTz,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.textToDateWithTz)
	},
	timestamptz: {
		castParam: (name) => `${name}::timestamptz`,
		castArrayParam: (name, _column, dim) => `${name}::timestamptz${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: __pg_core_codecs_ts.textToDateWithTz,
		normalizeArray: (0, __pg_core_codecs_ts.arrayCompatNormalize)(__pg_core_codecs_ts.textToDateWithTz)
	},
	"timestamp:string": {
		castParam: (name) => `${name}::timestamp`,
		castArrayParam: (name, _column, dim) => `${name}::timestamp${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	},
	"timestamptz:string": {
		castParam: (name) => `${name}::timestamptz`,
		castArrayParam: (name, _column, dim) => `${name}::timestamptz${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v),
		normalize: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timestamptzTextReason),
		normalizeArray: (0, __codecs_ts.unsupportedCodec)("timestamp with time zone", driver, timestamptzTextReason)
	},
	uuid: {
		castParam: (name) => `${name}::uuid`,
		castArrayParam: (name, _column, dim) => `${name}::uuid${"[]".repeat(dim)}`,
		normalizeParamArray: (v) => (0, __pg_core_array_ts.makePgArray)(v)
	}
});
//#endregion
exports.awsDataApiPgCodecs = awsDataApiPgCodecs;

//# sourceMappingURL=codecs.cjs.map