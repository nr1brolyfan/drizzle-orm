Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_query_builders_select = require("./query-builders/select.cjs");
const require_sqlite_core_query_builders_query_builder = require("./query-builders/query-builder.cjs");
const require_sqlite_core_query_builders_insert = require("./query-builders/insert.cjs");
const require_sqlite_core_query_builders_query = require("./query-builders/query.cjs");
const require_sqlite_core_query_builders_update = require("./query-builders/update.cjs");
let __entity_ts = require("../entity.cjs");
let __subquery_ts = require("../subquery.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __selection_proxy_ts = require("../selection-proxy.cjs");
//#region src/sqlite-core/db.ts
/**
* A database of every runtime. it's methods are written once, over the runtime's {@link SQLiteDatabaseBuilders}: each
* runtime's database narrows their types to it's own builders (`SQLiteAsyncDatabase`, `SQLiteEffectDatabase`)
*/
var SQLiteDatabase = class {
	builders;
	dialect;
	session;
	forbidJsonb;
	static [__entity_ts.entityKind] = "SQLiteBaseDatabase";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	query;
	constructor(builders, resultKind, dialect, session, relations, forbidJsonb) {
		this.builders = builders;
		this.dialect = dialect;
		this.session = session;
		this.forbidJsonb = forbidJsonb;
		this._ = {
			relations,
			session
		};
		const query = {};
		for (const [tableName, relation] of Object.entries(relations)) query[tableName] = new require_sqlite_core_query_builders_query.RelationalQueryBuilder(resultKind, relations, relations[relation.name].table, relation, dialect, session, forbidJsonb, builders.relationalQuery);
		this.query = query;
	}
	/**
	* Creates a subquery that defines a temporary named result set as a CTE.
	*
	* It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param alias The alias for the subquery.
	*
	* Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
	*
	* @example
	*
	* ```ts
	* // Create a subquery with alias 'sq' and use it in the select query
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* const result = await db.with(sq).select().from(sq);
	* ```
	*
	* To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
	*
	* ```ts
	* // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
	* const sq = db.$with('sq').as(db.select({
	*   name: sql<string>`upper(${users.name})`.as('name'),
	* })
	* .from(users));
	*
	* const result = await db.with(sq).select({ name: sq.name }).from(sq);
	* ```
	*/
	$with = (alias, selection) => {
		const as = (qb) => {
			if (typeof qb === "function") qb = qb(new require_sqlite_core_query_builders_query_builder.QueryBuilder(this.dialect));
			const sql = qb.getSQL();
			return new Proxy(new __subquery_ts.WithSubquery(sql, selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new __selection_proxy_ts.SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		};
		return { as };
	};
	$count(source, filters) {
		return new this.builders.count({
			source,
			filters,
			session: this.session,
			dialect: this.dialect
		});
	}
	with(...queries) {
		return {
			select: (fields) => this.buildSelect(fields, void 0, queries),
			selectDistinct: (fields) => this.buildSelect(fields, true, queries),
			update: (table) => this.buildUpdate(table, queries),
			insert: (table, ...columns) => this.buildInsert(table, columns, queries),
			delete: (table) => this.buildDelete(table, queries)
		};
	}
	select(fields) {
		return this.buildSelect(fields, void 0, void 0);
	}
	selectDistinct(fields) {
		return this.buildSelect(fields, true, void 0);
	}
	update(table) {
		return this.buildUpdate(table, void 0);
	}
	insert(into, ...columns) {
		return this.buildInsert(into, columns, void 0);
	}
	delete(from) {
		return this.buildDelete(from, void 0);
	}
	run(query) {
		return this.rawQuery(query, "raw", "run");
	}
	all(query, mode) {
		return this.rawQuery(query, mode ?? "objects", "all");
	}
	get(query, mode) {
		return this.rawQuery(query, mode ?? "objects", "get");
	}
	values(query) {
		return this.rawQuery(query, "arrays", "values");
	}
	/**
	* @internal
	* What a raw query (`run`, `all`, `get`, `values`) gives: the runtime's raw builder, which runs the prepared query
	* with it's `method` when awaited or yielded. Sync drivers' databases override it to run the query right away
	*/
	wrapRaw(prepared, sequel, builtQuery, _method) {
		return new this.builders.raw(prepared, sequel, builtQuery);
	}
	rawQuery(query, mode, method) {
		const sequel = typeof query === "string" ? __sql_sql_ts.sql.raw(query) : query.getSQL();
		const builtQuery = this.dialect.sqlToQuery(sequel);
		const prepared = this.session.prepareQuery(builtQuery, mode, false, method);
		return this.wrapRaw(prepared, sequel, builtQuery, method);
	}
	buildSelect(fields, distinct, withList) {
		return new require_sqlite_core_query_builders_select.SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect,
			withList,
			distinct
		}, this.builders.select);
	}
	buildUpdate(table, withList) {
		return new require_sqlite_core_query_builders_update.SQLiteUpdateBuilder(table, this.session, this.dialect, withList, this.builders.update);
	}
	buildInsert(into, columns, withList) {
		return new require_sqlite_core_query_builders_insert.SQLiteInsertBuilder(into, this.session, this.dialect, withList, columns.length ? columns : void 0, this.builders.insert);
	}
	buildDelete(from, withList) {
		return new this.builders.delete(from, this.session, this.dialect, withList);
	}
};
//#endregion
exports.SQLiteDatabase = SQLiteDatabase;

//# sourceMappingURL=db.cjs.map