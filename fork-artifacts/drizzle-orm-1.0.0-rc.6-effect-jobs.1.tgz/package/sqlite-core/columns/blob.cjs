Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __sqlite_core_codecs_ts = require("../codecs.cjs");
//#region src/sqlite-core/columns/blob.ts
var SQLiteBigIntBuilder = class extends require_sqlite_core_columns_common.SQLiteColumnBuilder {
	static [__entity_ts.entityKind] = "SQLiteBigIntBuilder";
	constructor(name) {
		super(name, "bigint int64", "SQLiteBigInt");
	}
	/** @internal */
	build(table) {
		return new SQLiteBigInt(table, this.config);
	}
};
var SQLiteBigInt = class extends require_sqlite_core_columns_common.SQLiteColumn {
	static [__entity_ts.entityKind] = "SQLiteBigInt";
	/** @internal */
	codec = "blob:bigint";
	getSQLType() {
		return "blob";
	}
	mapToDriverValue = (value) => {
		return (0, __sqlite_core_codecs_ts.bytesFromUtf8)(value.toString());
	};
};
var SQLiteBlobJsonBuilder = class extends require_sqlite_core_columns_common.SQLiteColumnBuilder {
	static [__entity_ts.entityKind] = "SQLiteBlobJsonBuilder";
	constructor(name) {
		super(name, "object json", "SQLiteBlobJson");
	}
	/** @internal */
	build(table) {
		return new SQLiteBlobJson(table, this.config);
	}
};
var SQLiteBlobJson = class extends require_sqlite_core_columns_common.SQLiteColumn {
	static [__entity_ts.entityKind] = "SQLiteBlobJson";
	/** @internal */
	codec = "blob:json";
	getSQLType() {
		return "blob";
	}
	mapToDriverValue = (value) => {
		return (0, __sqlite_core_codecs_ts.bytesFromUtf8)(JSON.stringify(value));
	};
};
var SQLiteBlobBufferBuilder = class extends require_sqlite_core_columns_common.SQLiteColumnBuilder {
	static [__entity_ts.entityKind] = "SQLiteBlobBufferBuilder";
	constructor(name) {
		super(name, "object buffer", "SQLiteBlobBuffer");
	}
	/** @internal */
	build(table) {
		return new SQLiteBlobBuffer(table, this.config);
	}
};
var SQLiteBlobBuffer = class extends require_sqlite_core_columns_common.SQLiteColumn {
	static [__entity_ts.entityKind] = "SQLiteBlobBuffer";
	/** @internal */
	codec = "blob";
	getSQLType() {
		return "blob";
	}
};
function blob(a, b) {
	const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
	if (config?.mode === "bigint") return new SQLiteBigIntBuilder(name);
	if (config?.mode === "buffer") return new SQLiteBlobBufferBuilder(name);
	return new SQLiteBlobJsonBuilder(name);
}
//#endregion
exports.SQLiteBigInt = SQLiteBigInt;
exports.SQLiteBigIntBuilder = SQLiteBigIntBuilder;
exports.SQLiteBlobBuffer = SQLiteBlobBuffer;
exports.SQLiteBlobBufferBuilder = SQLiteBlobBufferBuilder;
exports.SQLiteBlobJson = SQLiteBlobJson;
exports.SQLiteBlobJsonBuilder = SQLiteBlobJsonBuilder;
exports.blob = blob;

//# sourceMappingURL=blob.cjs.map