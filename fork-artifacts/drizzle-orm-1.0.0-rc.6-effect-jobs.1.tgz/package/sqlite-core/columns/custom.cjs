Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_columns_common = require("./common.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __sqlite_core_codecs_ts = require("../codecs.cjs");
//#region src/sqlite-core/columns/custom.ts
var SQLiteCustomColumnBuilder = class extends require_sqlite_core_columns_common.SQLiteColumnBuilder {
	static [__entity_ts.entityKind] = "SQLiteCustomColumnBuilder";
	constructor(name, fieldConfig, customTypeParams) {
		super(name, "custom", "SQLiteCustomColumn");
		this.config.fieldConfig = fieldConfig;
		this.config.customTypeParams = customTypeParams;
	}
	/** @internal */
	build(table) {
		return new SQLiteCustomColumn(table, this.config);
	}
};
var SQLiteCustomColumn = class extends require_sqlite_core_columns_common.SQLiteColumn {
	static [__entity_ts.entityKind] = "SQLiteCustomColumn";
	/** @internal */
	codec;
	sqlName;
	mapFromJsonValue;
	jsonSelectIdentifier;
	constructor(table, config) {
		super(table, config);
		this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
		this.mapToDriverValue = config.customTypeParams.toDriver ?? this.mapToDriverValue;
		this.mapFromDriverValue = config.customTypeParams.fromDriver ?? this.mapFromDriverValue;
		this.mapFromJsonValue = config.customTypeParams.fromJson;
		this.jsonSelectIdentifier = config.customTypeParams.forJsonSelect;
		const cfgCodec = typeof config.customTypeParams.codec === "string" || typeof config.customTypeParams.codec === "undefined" ? config.customTypeParams.codec : config.customTypeParams.codec(config.fieldConfig);
		this.codec = typeof cfgCodec === "string" ? (0, __sqlite_core_codecs_ts.resolveSQLiteTypeAlias)(cfgCodec) : void 0;
	}
	getSQLType() {
		return this.sqlName;
	}
};
/**
* Custom sqlite database data type generator
*/
function customType(customTypeParams) {
	return (a, b) => {
		const { name, config } = (0, __utils_ts.getColumnNameAndConfig)(a, b);
		return new SQLiteCustomColumnBuilder(name, config, customTypeParams);
	};
}
//#endregion
exports.SQLiteCustomColumn = SQLiteCustomColumn;
exports.SQLiteCustomColumnBuilder = SQLiteCustomColumnBuilder;
exports.customType = customType;

//# sourceMappingURL=custom.cjs.map