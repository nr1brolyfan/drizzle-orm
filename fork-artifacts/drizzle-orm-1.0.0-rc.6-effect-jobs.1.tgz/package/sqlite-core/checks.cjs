Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../entity.cjs");
//#region src/sqlite-core/checks.ts
var CheckBuilder = class {
	name;
	value;
	static [__entity_ts.entityKind] = "SQLiteCheckBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	brand;
	constructor(name, value) {
		this.name = name;
		this.value = value;
	}
	build(table) {
		return new Check(table, this);
	}
};
var Check = class {
	table;
	static [__entity_ts.entityKind] = "SQLiteCheck";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	name;
	value;
	constructor(table, builder) {
		this.table = table;
		this.name = builder.name;
		this.value = builder.value;
	}
};
function check(name, value) {
	return new CheckBuilder(name, value);
}
//#endregion
exports.Check = Check;
exports.CheckBuilder = CheckBuilder;
exports.check = check;

//# sourceMappingURL=checks.cjs.map