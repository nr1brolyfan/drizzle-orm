Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_async_count = require("./count.cjs");
const require_sqlite_core_async_query = require("./query.cjs");
const require_sqlite_core_db = require("../db.cjs");
let __entity_ts = require("../../entity.cjs");
let __sqlite_core_async_delete_ts = require("./delete.cjs");
let __sqlite_core_async_insert_ts = require("./insert.cjs");
let __sqlite_core_async_raw_ts = require("./raw.cjs");
let __sqlite_core_async_select_ts = require("./select.cjs");
let __sqlite_core_async_update_ts = require("./update.cjs");
//#region src/sqlite-core/async/db.ts
const sqliteAsyncBuilders = {
	select: __sqlite_core_async_select_ts.SQLiteAsyncSelectBase,
	insert: __sqlite_core_async_insert_ts.SQLiteAsyncInsertBase,
	update: __sqlite_core_async_update_ts.SQLiteAsyncUpdateBase,
	delete: __sqlite_core_async_delete_ts.SQLiteAsyncDeleteBase,
	count: require_sqlite_core_async_count.SQLiteAsyncCountBuilder,
	raw: __sqlite_core_async_raw_ts.SQLiteAsyncRaw,
	relationalQuery: require_sqlite_core_async_query.SQLiteAsyncRelationalQuery
};
/** Sync drivers' builders: their counts and relational queries also run with `.sync()` */
const sqliteSyncBuilders = {
	...sqliteAsyncBuilders,
	count: require_sqlite_core_async_count.SQLiteSyncCountBuilder,
	relationalQuery: require_sqlite_core_async_query.SQLiteSyncRelationalQuery
};
var SQLiteAsyncDatabase = class extends require_sqlite_core_db.SQLiteDatabase {
	resultKind;
	static [__entity_ts.entityKind] = "BaseSQLiteDatabase";
	constructor(resultKind, dialect, session, relations, forbidJsonb) {
		super(resultKind === "sync" ? sqliteSyncBuilders : sqliteAsyncBuilders, resultKind, dialect, session, relations, forbidJsonb);
		this.resultKind = resultKind;
		this._.resultKind = resultKind;
	}
	/** @internal Sync drivers run raw queries right away */
	wrapRaw(prepared, sequel, builtQuery, method) {
		return this.resultKind === "async" ? super.wrapRaw(prepared, sequel, builtQuery, method) : prepared[method]();
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.SQLiteAsyncDatabase = SQLiteAsyncDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map