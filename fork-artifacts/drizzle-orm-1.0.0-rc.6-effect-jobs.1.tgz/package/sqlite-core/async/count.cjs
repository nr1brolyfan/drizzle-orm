Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
let __sqlite_core_query_builders_count_ts = require("../query-builders/count.cjs");
//#region src/sqlite-core/async/count.ts
var SQLiteAsyncCountBuilder = class extends __sqlite_core_query_builders_count_ts.SQLiteCountBuilder {
	static [__entity_ts.entityKind] = "SQLiteAsyncCountBuilder";
	/** @internal The count as the driver gives it: a Promise from async drivers, an `ExecuteResultSync` from sync ones */
	executeRaw(placeholderValues) {
		return this._prepare().execute(placeholderValues);
	}
	async execute(placeholderValues) {
		return await this.executeRaw(placeholderValues);
	}
};
(0, __utils_ts.applyMixins)(SQLiteAsyncCountBuilder, [__query_promise_ts.QueryPromise]);
var SQLiteSyncCountBuilder = class extends SQLiteAsyncCountBuilder {
	static [__entity_ts.entityKind] = "SQLiteSyncCountBuilder";
	sync(placeholderValues) {
		return this.executeRaw(placeholderValues).sync();
	}
};
//#endregion
exports.SQLiteAsyncCountBuilder = SQLiteAsyncCountBuilder;
exports.SQLiteSyncCountBuilder = SQLiteSyncCountBuilder;

//# sourceMappingURL=count.cjs.map