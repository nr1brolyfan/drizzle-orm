Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_query_builders_runnable = require("../query-builders/runnable.cjs");
const require_sqlite_core_async_runnable = require("./runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
let __sqlite_core_query_builders_delete_ts = require("../query-builders/delete.cjs");
//#region src/sqlite-core/async/delete.ts
var SQLiteAsyncDeleteBase = class extends __sqlite_core_query_builders_delete_ts.SQLiteDeleteBase {
	static [__entity_ts.entityKind] = "SQLiteAsyncDelete";
};
(0, __utils_ts.applyMixins)(SQLiteAsyncDeleteBase, [
	__query_promise_ts.QueryPromise,
	require_sqlite_core_query_builders_runnable.SQLiteRunnableQuery,
	require_sqlite_core_async_runnable.SQLiteAsyncRunnableQuery
]);
//#endregion
exports.SQLiteAsyncDeleteBase = SQLiteAsyncDeleteBase;

//# sourceMappingURL=delete.cjs.map