Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_query_builders_runnable = require("../query-builders/runnable.cjs");
const require_sqlite_core_async_runnable = require("./runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __query_promise_ts = require("../../query-promise.cjs");
let __sqlite_core_query_builders_insert_ts = require("../query-builders/insert.cjs");
//#region src/sqlite-core/async/insert.ts
var SQLiteAsyncInsertBase = class extends __sqlite_core_query_builders_insert_ts.SQLiteInsertBase {
	static [__entity_ts.entityKind] = "SQLiteAsyncInsert";
};
(0, __utils_ts.applyMixins)(SQLiteAsyncInsertBase, [
	__query_promise_ts.QueryPromise,
	require_sqlite_core_query_builders_runnable.SQLiteRunnableQuery,
	require_sqlite_core_async_runnable.SQLiteAsyncRunnableQuery
]);
//#endregion
exports.SQLiteAsyncInsertBase = SQLiteAsyncInsertBase;

//# sourceMappingURL=insert.cjs.map