Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __alias_ts = require("../alias.cjs");
//#region src/sqlite-core/alias.ts
function alias(table, alias) {
	return new Proxy(table, new __alias_ts.TableAliasProxyHandler(alias, false));
}
//#endregion
exports.alias = alias;

//# sourceMappingURL=alias.cjs.map