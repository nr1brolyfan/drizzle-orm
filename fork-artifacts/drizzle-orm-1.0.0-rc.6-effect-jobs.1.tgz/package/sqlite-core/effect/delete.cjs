Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __sqlite_core_query_builders_delete_ts = require("../query-builders/delete.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
//#region src/sqlite-core/effect/delete.ts
var SQLiteEffectDeleteBase = class extends __sqlite_core_query_builders_delete_ts.SQLiteDeleteBase {
	static [__entity_ts.entityKind] = "SQLiteEffectDelete";
};
(0, __utils_ts.applyMixins)(SQLiteEffectDeleteBase, [require_sqlite_core_query_builders_runnable.SQLiteRunnableQuery]);
(0, __effect_core_query_effect_ts.applyEffectWrapper)(SQLiteEffectDeleteBase);
//#endregion
exports.SQLiteEffectDeleteBase = SQLiteEffectDeleteBase;

//# sourceMappingURL=delete.cjs.map