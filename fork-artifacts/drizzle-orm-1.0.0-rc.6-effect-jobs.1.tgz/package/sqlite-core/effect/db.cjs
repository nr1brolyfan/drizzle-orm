Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_db = require("../db.cjs");
let __entity_ts = require("../../entity.cjs");
let __sqlite_core_effect_count_ts = require("./count.cjs");
let __sqlite_core_effect_delete_ts = require("./delete.cjs");
let __sqlite_core_effect_insert_ts = require("./insert.cjs");
let __sqlite_core_effect_query_ts = require("./query.cjs");
let __sqlite_core_effect_raw_ts = require("./raw.cjs");
let __sqlite_core_effect_select_ts = require("./select.cjs");
let __sqlite_core_effect_update_ts = require("./update.cjs");
//#region src/sqlite-core/effect/db.ts
const sqliteEffectBuilders = {
	select: __sqlite_core_effect_select_ts.SQLiteEffectSelectBase,
	insert: __sqlite_core_effect_insert_ts.SQLiteEffectInsertBase,
	update: __sqlite_core_effect_update_ts.SQLiteEffectUpdateBase,
	delete: __sqlite_core_effect_delete_ts.SQLiteEffectDeleteBase,
	count: __sqlite_core_effect_count_ts.SQLiteEffectCountBuilder,
	raw: __sqlite_core_effect_raw_ts.SQLiteEffectRaw,
	relationalQuery: __sqlite_core_effect_query_ts.SQLiteEffectRelationalQuery
};
var SQLiteEffectDatabase = class extends require_sqlite_core_db.SQLiteDatabase {
	static [__entity_ts.entityKind] = "SQLiteEffectDatabase";
	constructor(dialect, session, relations, forbidJsonb) {
		super(sqliteEffectBuilders, void 0, dialect, session, relations, forbidJsonb);
	}
	transaction(transaction) {
		return this.session.transaction(transaction);
	}
};
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
	return Object.create(primary, {
		$replica: { get: () => getReplica(replicas) },
		$primary: { value: primary },
		$replicas: { value: replicas }
	});
};
//#endregion
exports.SQLiteEffectDatabase = SQLiteEffectDatabase;
exports.withReplicas = withReplicas;

//# sourceMappingURL=db.cjs.map