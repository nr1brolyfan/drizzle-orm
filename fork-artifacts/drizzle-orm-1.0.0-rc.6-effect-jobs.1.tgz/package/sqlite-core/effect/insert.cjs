Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_query_builders_runnable = require("../query-builders/runnable.cjs");
let __entity_ts = require("../../entity.cjs");
let __utils_ts = require("../../utils.cjs");
let __sqlite_core_query_builders_insert_ts = require("../query-builders/insert.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
//#region src/sqlite-core/effect/insert.ts
var SQLiteEffectInsertBase = class extends __sqlite_core_query_builders_insert_ts.SQLiteInsertBase {
	static [__entity_ts.entityKind] = "SQLiteEffectInsert";
};
(0, __utils_ts.applyMixins)(SQLiteEffectInsertBase, [require_sqlite_core_query_builders_runnable.SQLiteRunnableQuery]);
(0, __effect_core_query_effect_ts.applyEffectWrapper)(SQLiteEffectInsertBase);
//#endregion
exports.SQLiteEffectInsertBase = SQLiteEffectInsertBase;

//# sourceMappingURL=insert.cjs.map