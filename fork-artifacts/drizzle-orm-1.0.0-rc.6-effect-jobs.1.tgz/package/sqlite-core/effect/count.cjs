Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __sqlite_core_query_builders_count_ts = require("../query-builders/count.cjs");
let __effect_core_query_effect_ts = require("../../effect-core/query-effect.cjs");
//#region src/sqlite-core/effect/count.ts
var SQLiteEffectCountBuilder = class extends __sqlite_core_query_builders_count_ts.SQLiteCountBuilder {
	static [__entity_ts.entityKind] = "SQLiteEffectCountBuilder";
};
(0, __effect_core_query_effect_ts.applyEffectWrapper)(SQLiteEffectCountBuilder);
//#endregion
exports.SQLiteEffectCountBuilder = SQLiteEffectCountBuilder;

//# sourceMappingURL=count.cjs.map