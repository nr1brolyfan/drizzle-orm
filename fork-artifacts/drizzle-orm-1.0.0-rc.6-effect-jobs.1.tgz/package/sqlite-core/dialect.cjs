Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __view_ts = require("../view.cjs");
let __entity_ts = require("../entity.cjs");
let __view_common_ts = require("../view-common.cjs");
let __errors_ts = require("../errors.cjs");
let __table_ts = require("../table.cjs");
let __utils_ts = require("../utils.cjs");
let __column_ts = require("../column.cjs");
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
let __alias_ts = require("../alias.cjs");
let __relations_ts = require("../relations.cjs");
let __sql_common_chunks_ts = require("../sql/common-chunks.cjs");
let __sqlite_core_codecs_ts = require("./codecs.cjs");
let __sqlite_core_table_ts = require("./table.cjs");
let __sqlite_core_columns_index_ts = require("./columns/index.cjs");
//#region src/sqlite-core/dialect.ts
const escapeSQLiteName = (0, __utils_ts.memoizeEscape)((name) => `"${name.replace(/"/g, "\"\"")}"`);
const rqbChunks = {
	json: new __sql_common_chunks_ts.StringChunk("json"),
	object: new __sql_common_chunks_ts.StringChunk("_object("),
	groupArray: new __sql_common_chunks_ts.StringChunk("_group_array(json_object("),
	groupArrayClose: new __sql_common_chunks_ts.StringChunk("))"),
	relationFrom: new __sql_common_chunks_ts.StringChunk(" as \"r\" from ("),
	relationClose: new __sql_common_chunks_ts.StringChunk(") as \"t\") as ")
};
var SQLiteDialect = class {
	static [__entity_ts.entityKind] = "SQLiteDialect";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	codecs;
	mapperGenerators;
	constructor(config) {
		this.codecs = new __codecs_ts.CodecsCollection(__sqlite_core_codecs_ts.resolveSQLiteTypeAlias, config?.codecs);
		this.mapperGenerators = config?.useJitMappers ? {
			rows: __utils_ts.makeJitQueryMapper,
			relationalRows: __relations_ts.makeJitRqbMapper
		} : {
			rows: __utils_ts.makeDefaultQueryMapper,
			relationalRows: __relations_ts.makeDefaultRqbMapper
		};
	}
	escapeName(name) {
		return escapeSQLiteName(name);
	}
	escapeParam(_num) {
		return "?";
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const queriesLen = queries.length;
		const withSqlChunks = new Array(queriesLen + 1);
		let writeIdx = 0;
		withSqlChunks[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["with "];
		for (let i = 0; i < queriesLen; ++i) {
			const w = queries[i];
			withSqlChunks[writeIdx++] = i < queriesLen - 1 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql}), ` : __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(w._.alias)} as (${w._.sql}) `;
		}
		return new __sql_sql_ts.SQL(withSqlChunks);
	}
	buildDeleteQuery({ table, where, returning, withList, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: true,
			table
		})}` : void 0;
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const orderBySql = this.buildOrderBy(orderBy);
		const limitSql = this.buildLimit(limit);
		return __sql_sql_ts.sql`${withSql}delete from ${table}${whereSql}${returningSql}${orderBySql}${limitSql}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[__table_ts.Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setLength = columnNames.length;
		const setArr = new Array(setLength);
		for (let i = 0; i < columnNames.length; ++i) {
			const colName = columnNames[i];
			const col = tableColumns[colName];
			let value;
			if (set[colName] !== void 0) value = set[colName];
			else {
				const updateRes = col.onUpdateFn?.();
				value = (0, __entity_ts.is)(updateRes, __sql_sql_ts.SQL) ? updateRes : __sql_sql_ts.sql.param(updateRes, col);
			}
			setArr[i] = i < setLength - 1 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}, ` : __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(col.name)} = ${value}`;
		}
		return new __sql_sql_ts.SQL(setArr);
	}
	buildUpdateQuery({ table, set, where, returning, withList, joins, from, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const setSql = this.buildUpdateSet(table, set);
		const fromSql = from && new __sql_sql_ts.SQL([__sql_common_chunks_ts.commonStringChunks[" from "], this.buildFromTable(from)]);
		const joinsSql = this.buildJoins(joins);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: true,
			table
		})}` : void 0;
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const orderBySql = this.buildOrderBy(orderBy);
		const limitSql = this.buildLimit(limit);
		return __sql_sql_ts.sql`${withSql}update ${table} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}${orderBySql}${limitSql}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false, table } = {}) {
		const { length: columnsLen } = fields;
		const chunks = [];
		const tableKind = (0, __sql_sql_ts.chunkKindOf)(table);
		const tableName = table ? (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.sql) || (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.subquery) ? void 0 : table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}` : void 0;
		for (let i = 0; i < columnsLen; ++i) {
			const { field, fieldType } = fields[i];
			switch (fieldType) {
				case "Column": {
					let name;
					if (isSingleTable) name = field.isAlias ? __sql_sql_ts.sql.identifier((0, __alias_ts.getOriginalColumnFromAlias)(field).name) : __sql_sql_ts.sql.identifier(field.name);
					else name = field.isAlias ? (0, __alias_ts.getOriginalColumnFromAlias)(field) : field;
					chunks.push(field.isAlias ? __sql_sql_ts.sql`${name} as ${field}` : name);
					break;
				}
				case "SQL.Aliased":
					if (field.isSelectionField) {
						const query = !isSingleTable && field.origin !== void 0 ? __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(field.origin)}.${__sql_sql_ts.sql.identifier(field.fieldAlias)}` : __sql_sql_ts.sql.identifier(field.fieldAlias);
						chunks.push(query);
					} else {
						if (isSingleTable && tableName !== void 0) {
							const { queryChunks } = field.sql;
							const newChunks = new Array(queryChunks.length);
							let abort = false;
							for (let i = 0; i < queryChunks.length; ++i) {
								const c = queryChunks[i];
								if ((0, __entity_ts.is)(c, __column_ts.Column)) {
									const { table } = c;
									if ((table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}`) !== tableName) {
										abort = true;
										break;
									}
									newChunks[i] = __sql_sql_ts.sql.identifier(c.name);
								} else newChunks[i] = c;
							}
							if (abort) chunks.push(field.sql);
							else {
								const newSql = new __sql_sql_ts.SQL(newChunks);
								if (field.sql.shouldInlineParams) newSql.inlineParams();
								chunks.push(newSql);
							}
						} else chunks.push(field.sql);
						chunks.push(__sql_sql_ts.sql` as ${__sql_sql_ts.sql.identifier(field.fieldAlias)}`);
					}
					break;
				case "SQL":
					if (isSingleTable && tableName !== void 0) {
						const { queryChunks } = field;
						const newChunks = new Array(queryChunks.length);
						let abort = false;
						for (let i = 0; i < queryChunks.length; ++i) {
							const c = queryChunks[i];
							if ((0, __entity_ts.is)(c, __column_ts.Column)) {
								const { table } = c;
								if ((table[__table_ts.Table.Symbol.IsAlias] || table[__table_ts.Table.Symbol.Schema] === void 0 ? table[__table_ts.Table.Symbol.Name] : `${table[__table_ts.Table.Symbol.Schema]}.${table[__table_ts.Table.Symbol.Name]}`) !== tableName) {
									abort = true;
									break;
								}
								newChunks[i] = __sql_sql_ts.sql.identifier(c.name);
							} else newChunks[i] = c;
						}
						if (abort) chunks.push(field);
						else {
							const newSql = new __sql_sql_ts.SQL(newChunks);
							if (field.shouldInlineParams) newSql.inlineParams();
							chunks.push(newSql);
						}
					} else chunks.push(field);
					break;
				case "Subquery": if (!field._.isWith) {
					const inner = __sql_sql_ts.sql`(${field._.sql})`;
					chunks.push(__sql_sql_ts.sql`${inner} ${__sql_sql_ts.sql.identifier(field._.alias)}`);
				} else chunks.push(field);
			}
			if (i < columnsLen - 1) chunks.push(__sql_common_chunks_ts.commonStringChunks[", "]);
		}
		return new __sql_sql_ts.SQL(chunks);
	}
	buildJoins(joins) {
		if (!joins || joins.length === 0) return;
		const joinsArray = [];
		if (joins) for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(__sql_common_chunks_ts.commonStringChunks[" "]);
			const table = joinMeta.table;
			const onSql = joinMeta.on ? __sql_sql_ts.sql` on ${joinMeta.on}` : void 0;
			if ((0, __entity_ts.is)(table, __sqlite_core_table_ts.SQLiteTable)) joinsArray.push(__sql_sql_ts.sql`${new __sql_common_chunks_ts.StringChunk(joinMeta.joinType)} join ${table[__table_ts.Table.Symbol.IsAlias] ? (0, __alias_ts.aliasedTableSQL)(table) : table}${onSql}`);
			else joinsArray.push(__sql_sql_ts.sql`${new __sql_common_chunks_ts.StringChunk(joinMeta.joinType)} join ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(__sql_common_chunks_ts.commonStringChunks[" "]);
		}
		return new __sql_sql_ts.SQL(joinsArray);
	}
	buildLimit(limit) {
		return limit === void 0 ? void 0 : __sql_sql_ts.sql` limit ${limit}`;
	}
	buildOrderBy(orderBy) {
		const orderByList = [];
		if (orderBy) for (const [index, orderByValue] of orderBy.entries()) {
			orderByList.push(orderByValue);
			if (index < orderBy.length - 1) orderByList.push(__sql_common_chunks_ts.commonStringChunks[", "]);
		}
		return orderByList.length > 0 ? __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByList)}` : void 0;
	}
	buildFromTable(table) {
		if ((0, __entity_ts.is)(table, __table_ts.Table) && table[__table_ts.Table.Symbol.IsAlias]) return (0, __alias_ts.aliasedTableSQL)(table);
		if ((0, __entity_ts.is)(table, __view_ts.View) && table[__view_common_ts.ViewBaseConfig].isAlias) {
			let fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].originalName)}`;
			if (table[__view_common_ts.ViewBaseConfig].schema) fullName = __sql_sql_ts.sql`${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].schema)}.${fullName}`;
			return __sql_sql_ts.sql`${fullName} ${__sql_sql_ts.sql.identifier(table[__view_common_ts.ViewBaseConfig].name)}`;
		}
		return table;
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, limit, offset, distinct, setOperators }) {
		const fieldsList = fieldsFlat ?? (0, __utils_ts.orderSelectedFields)(fields, void 0, this.codecs);
		const tableKind = (0, __sql_sql_ts.chunkKindOf)(table);
		const ownTableName = (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.subquery) ? table._.alias : (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.view) ? table[__view_common_ts.ViewBaseConfig].name : (0, __sql_sql_ts.isChunk)(table, tableKind, __sql_sql_ts.chunkKinds.sql) ? void 0 : (0, __table_ts.getTableName)(table);
		for (const f of fieldsList) if ((0, __entity_ts.is)(f.field, __column_ts.Column) && (0, __table_ts.getTableName)(f.field.table) !== ownTableName && !((table) => joins?.some(({ alias }) => alias === (table[__table_ts.Table.Symbol.IsAlias] ? (0, __table_ts.getTableName)(table) : table[__table_ts.Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = (0, __table_ts.getTableName)(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		const distinctSql = distinct ? __sql_sql_ts.sql` distinct` : void 0;
		const selection = this.buildSelection(fieldsList, {
			isSingleTable,
			table
		});
		const tableSql = this.buildFromTable(table);
		const joinsSql = this.buildJoins(joins);
		const whereSql = where ? __sql_sql_ts.sql` where ${where}` : void 0;
		const havingSql = having ? __sql_sql_ts.sql` having ${having}` : void 0;
		const groupByList = [];
		if (groupBy) for (const [index, groupByValue] of groupBy.entries()) {
			groupByList.push(groupByValue);
			if (index < groupBy.length - 1) groupByList.push(__sql_common_chunks_ts.commonStringChunks[", "]);
		}
		const groupBySql = groupByList.length > 0 ? __sql_sql_ts.sql` group by ${__sql_sql_ts.sql.join(groupByList)}` : void 0;
		const orderBySql = this.buildOrderBy(orderBy);
		const limitSql = this.buildLimit(limit);
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset}`;
		const finalQuery = __sql_sql_ts.sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, fieldsList, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, outputSelection, setOperators) {
		const operandTypes = [];
		for (let i = 0; i < setOperators.length; ++i) {
			const setOperator = setOperators[i];
			leftSelect = this.buildSetOperationQuery({
				leftSelect,
				setOperator
			});
			const rightSelection = (0, __utils_ts.orderSelectedFields)(setOperator.rightSelect.getSelectedFields());
			for (let j = 0; j < outputSelection.length; ++j) {
				const l = outputSelection[j];
				const lPath = l.path.join(".");
				const r = rightSelection.find((e) => e.path.join(".") === lPath);
				const lc = l.codecOverride ?? l.column?.codec;
				const rc = r.codecOverride ?? r.column?.codec;
				if (i === 0 && lc) (operandTypes[j] = /* @__PURE__ */ new Set()).add(l.column?.codec ?? lc);
				if (rc) (operandTypes[j] ??= /* @__PURE__ */ new Set()).add(r.column?.codec ?? rc);
				l.codecOverride = lc && rc ? (0, __sqlite_core_codecs_ts.resolveUnionType)(lc, rc) : lc;
			}
		}
		for (let i = 0; i < outputSelection.length; ++i) {
			const out = outputSelection[i];
			if (!out.codecOverride) continue;
			const types = operandTypes[i];
			if (types?.has("blob:bigint") && types.has("numeric:bigint")) {
				const fromBlob = this.codecs.get(out.column, "normalize", "blob:bigint");
				const fromNumeric = this.codecs.get(out.column, "normalize", "numeric:bigint");
				if (fromBlob && fromNumeric) {
					out.codec = (value) => typeof value === "object" ? fromBlob(value) : fromNumeric(value);
					continue;
				}
			}
			out.codec = this.codecs.get(out.column, "normalize", out.codecOverride);
		}
		return leftSelect;
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, limit, orderBy, offset } }) {
		const leftChunk = __sql_sql_ts.sql`${leftSelect.getSQL()} `;
		const rightChunk = __sql_sql_ts.sql`${rightSelect.getSQL()}`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const singleOrderBy of orderBy) if ((0, __entity_ts.is)(singleOrderBy, __sqlite_core_columns_index_ts.SQLiteColumn)) orderByValues.push(__sql_sql_ts.sql.identifier(singleOrderBy.name));
			else if ((0, __entity_ts.is)(singleOrderBy, __sql_sql_ts.SQL)) orderByValues.push(__sql_sql_ts.sql`${(0, __sql_sql_ts.unqualifyColumns)(singleOrderBy)}`);
			else orderByValues.push(__sql_sql_ts.sql`${singleOrderBy}`);
			orderBySql = __sql_sql_ts.sql` order by ${__sql_sql_ts.sql.join(orderByValues, __sql_common_chunks_ts.commonStringChunks[", "])}`;
		}
		const limitSql = limit === void 0 ? void 0 : __sql_sql_ts.sql` limit ${limit}`;
		const operatorChunk = new __sql_common_chunks_ts.StringChunk(`${type} ${isAll ? "all " : ""}`);
		const offsetSql = offset === void 0 ? void 0 : __sql_sql_ts.sql` offset ${offset}`;
		return __sql_sql_ts.sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select, columnList }) {
		const columns = table[__table_ts.Table.Symbol.Columns];
		const colEntries = columnList ? columnList.map((name) => [name, columns[name]]) : Object.entries(columns);
		const colEntriesFiltered = select && !(0, __entity_ts.is)(valuesOrSelect, __sql_sql_ts.SQL) ? Object.keys(valuesOrSelect.getSelectedFields()).map((key) => [key, columns[key]]) : colEntries.filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrderArr = new Array(colEntriesFiltered.length * 2 + 1);
		let writeIdx = 0;
		insertOrderArr[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["("];
		for (let i = 0; i < colEntriesFiltered.length; ++i) {
			const [, { name }] = colEntriesFiltered[i];
			insertOrderArr[writeIdx++] = __sql_sql_ts.sql.identifier(name);
			if (i < colEntriesFiltered.length - 1) insertOrderArr[writeIdx++] = __sql_common_chunks_ts.commonStringChunks[", "];
		}
		insertOrderArr[writeIdx++] = __sql_common_chunks_ts.commonStringChunks[")"];
		const insertOrder = new __sql_sql_ts.SQL(insertOrderArr);
		let valuesSqlList;
		if (select) valuesSqlList = [valuesOrSelect.getSQL()];
		else {
			const values = valuesOrSelect;
			const cells = new Array(values.length * colEntriesFiltered.length);
			let writeIdx = 0;
			for (let valueIndex = 0; valueIndex < values.length; ++valueIndex) {
				const value = values[valueIndex];
				for (let i = 0; i < colEntriesFiltered.length; ++i) {
					const [fieldName, col] = colEntriesFiltered[i];
					const colValue = value[fieldName];
					if (colValue === void 0) {
						if (col.defaultFn !== void 0) cells[writeIdx++] = col.defaultFn();
						else if (col.default !== null && col.default !== void 0) cells[writeIdx++] = col.default;
						else if (col.onUpdateFn !== void 0) cells[writeIdx++] = col.onUpdateFn();
						else cells[writeIdx++] = __sql_common_chunks_ts.commonStringChunks["null"];
					} else cells[writeIdx++] = colValue;
				}
			}
			valuesSqlList = [__sql_common_chunks_ts.commonStringChunks["values "], new __sql_sql_ts.ValueRows(cells, colEntriesFiltered.map(([, col]) => col))];
		}
		const withSql = this.buildWithCTE(withList);
		const valuesSql = new __sql_sql_ts.SQL(valuesSqlList);
		const returningSql = returning ? __sql_sql_ts.sql` returning ${this.buildSelection(returning, {
			isSingleTable: true,
			table
		})}` : void 0;
		const onConflictSql = onConflict?.length ? __sql_sql_ts.sql.join(onConflict) : void 0;
		return __sql_sql_ts.sql`${withSql}insert into ${table} ${insertOrder} ${valuesSql}${onConflictSql}${returningSql}`;
	}
	sqlToQuery(sql, invokeSource) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			codecs: this.codecs,
			invokeSource
		});
	}
	buildRelationalQuery(config) {
		const chunks = [];
		const selection = this.collectRelationalQuery(config, chunks);
		return {
			sql: new __sql_sql_ts.SQL(chunks),
			selection
		};
	}
	collectRelationalQuery({ schema, table, tableConfig, queryConfig: config, relationWhere, mode, nested, errorPath, depth, through, jsonb, withSubqueries }, collectTo) {
		const selection = [];
		const isSingle = mode === "first";
		const params = config === true ? void 0 : config;
		const currentPath = errorPath ?? "";
		const currentDepth = depth ?? 0;
		const collector = withSubqueries ?? { subqueries: /* @__PURE__ */ new Map() };
		if (!currentDepth) {
			(0, __relations_ts.collectSubquery)(collector, table);
			table = (0, __alias_ts.aliasedTable)(table, `d${currentDepth}`);
		}
		const tableRef = table[__table_ts.Qualifier];
		const limit = isSingle ? 1 : params?.limit;
		const offset = params?.offset;
		const { sql: where } = (0, __relations_ts.relationalQueryWhereToSQL)(table, params, tableConfig.relations, schema, collector, relationWhere);
		const order = params?.orderBy ? (0, __relations_ts.relationsOrderToSQL)(table, params.orderBy, tableConfig.relations, schema, collector) : void 0;
		const withParam = params ? params.with : void 0;
		const withKeys = [];
		if (withParam) {
			for (const key of Object.keys(withParam)) if (withParam[key]) withKeys.push(key);
		}
		const withIdx = currentDepth ? -1 : collectTo.length;
		if (!currentDepth) collectTo.push(void 0);
		collectTo.push(__sql_common_chunks_ts.commonStringChunks["select "]);
		let selected = (0, __relations_ts.buildRqbColumns)(tableRef, tableConfig.table[__table_ts.TableColumns], selection, !!nested, tableConfig.name, this.codecs, collectTo, params?.columns) ? 1 : 0;
		if (params?.extras) {
			const mark = collectTo.length;
			if (selected) collectTo.push(__sql_common_chunks_ts.commonStringChunks[", "]);
			const extras = (0, __relations_ts.relationExtrasToSQL)(table, params.extras, this.codecs, !!nested, collectTo);
			selection.push(...extras.selection);
			if (extras.sql) ++selected;
			else collectTo.length = mark;
		}
		if (!selected && !withKeys.length) throw new __errors_ts.DrizzleError({ message: `No fields selected for table "${tableConfig.name}"${currentPath ? ` ("${currentPath}")` : ""}` });
		for (const k of withKeys) {
			const join = withParam[k];
			const relation = tableConfig.relations[k];
			if (!relation) throw new __errors_ts.DrizzleError({ message: `Unknown relation "${tableConfig.name}" -> "${k}"` });
			const isSingle = relation.relationType === "one";
			(0, __relations_ts.collectSubquery)(collector, relation.targetTable);
			(0, __relations_ts.collectSubquery)(collector, relation.throughTable);
			const targetTable = (0, __alias_ts.aliasedTable)(relation.targetTable, `d${currentDepth + 1}`);
			const throughTable = relation.throughTable ? (0, __alias_ts.aliasedTable)(relation.throughTable, `tr${currentDepth}`) : void 0;
			const { filter, joinCondition } = (0, __relations_ts.relationToSQL)(relation, table, targetTable, throughTable);
			if (selected++) collectTo.push(__sql_common_chunks_ts.commonStringChunks[", "]);
			const jsonIdx = collectTo.length;
			collectTo.push(void 0, rqbChunks.relationFrom);
			const innerSelection = this.collectRelationalQuery({
				table: targetTable,
				mode: isSingle ? "first" : "many",
				schema,
				queryConfig: join,
				tableConfig: schema[relation.targetTableName],
				relationWhere: filter,
				nested: true,
				errorPath: `${currentPath.length ? `${currentPath}.` : ""}${k}`,
				depth: currentDepth + 1,
				withSubqueries: collector,
				through: throughTable ? {
					table: throughTable,
					condition: joinCondition
				} : void 0,
				jsonb
			}, collectTo);
			collectTo.push(rqbChunks.relationClose, __sql_sql_ts.sql.identifier(k));
			const jsonChunks = [
				__sql_common_chunks_ts.commonStringChunks["(select "],
				nested ? jsonb : rqbChunks.json,
				isSingle ? rqbChunks.object : rqbChunks.groupArray
			];
			for (let i = 0; i < innerSelection.length; ++i) {
				const s = innerSelection[i];
				if (i) jsonChunks.push(__sql_common_chunks_ts.commonStringChunks[", "]);
				jsonChunks.push(new __sql_common_chunks_ts.StringChunk(this.escapeString(s.key)), __sql_common_chunks_ts.commonStringChunks[", "]);
				if (s.selection) jsonChunks.push(jsonb, __sql_common_chunks_ts.commonStringChunks["("], __sql_sql_ts.sql.identifier(s.key), __sql_common_chunks_ts.commonStringChunks[")"]);
				else jsonChunks.push(__sql_sql_ts.sql.identifier(s.key));
			}
			jsonChunks.push(isSingle ? __sql_common_chunks_ts.commonStringChunks[")"] : rqbChunks.groupArrayClose);
			collectTo[jsonIdx] = new __sql_sql_ts.SQL(jsonChunks);
			selection.push({
				field: targetTable,
				fieldType: "Nested",
				key: k,
				selection: innerSelection,
				isArray: !isSingle,
				isOptional: (relation.optional ?? false) || join !== true && !!join.where
			});
		}
		collectTo.push(__sql_common_chunks_ts.commonStringChunks[" from "]);
		(0, __relations_ts.getTableAsAliasSQL)(table, collectTo);
		if (through) {
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[" inner join "]);
			(0, __relations_ts.getTableAsAliasSQL)(through.table, collectTo);
			collectTo.push(__sql_common_chunks_ts.commonStringChunks[" on "], ...through.condition);
		}
		if (where) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" where "], ...where);
		if (order) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" order by "], ...order);
		if (limit !== void 0) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" limit "], limit);
		if (offset !== void 0) collectTo.push(__sql_common_chunks_ts.commonStringChunks[" offset "], offset);
		if (withIdx !== -1) collectTo[withIdx] = this.buildWithCTE([...collector.subqueries.values()]);
		return selection;
	}
};
//#endregion
exports.SQLiteDialect = SQLiteDialect;

//# sourceMappingURL=dialect.cjs.map