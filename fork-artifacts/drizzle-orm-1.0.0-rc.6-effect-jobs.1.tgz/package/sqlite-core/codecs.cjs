Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __utils_ts = require("../utils.cjs");
let __codecs_ts = require("../codecs.cjs");
let __sql_sql_ts = require("../sql/sql.cjs");
//#region src/sqlite-core/codecs.ts
const SQLITE_ALIAS_TO_TYPE_MAP = {
	int: "integer",
	int2: "integer",
	int8: "integer",
	tinyint: "integer",
	smallint: "integer",
	mediumint: "integer",
	bool: "integer:boolean",
	boolean: "integer:boolean",
	float: "real",
	double: "real",
	"double precision": "real",
	decimal: "numeric",
	character: "text",
	varchar: "text",
	"varying character": "text",
	nchar: "text",
	"native character": "text",
	nvarchar: "text",
	clob: "text",
	json: "text:json"
};
function resolveSQLiteTypeAlias(type) {
	return SQLITE_ALIAS_TO_TYPE_MAP[type] ?? type;
}
const castToText = (name) => __sql_sql_ts.sql`cast(${name} as text)`;
const castToHex = (name) => __sql_sql_ts.sql`hex(${name})`;
const uint8ArrayFromHex = (value) => {
	const bytes = new Uint8Array(value.length >> 1);
	for (let i = 0; i < bytes.length; ++i) bytes[i] = Number.parseInt(value.substring(i * 2, i * 2 + 2), 16);
	return bytes;
};
const bufferFromHex = typeof Buffer === "undefined" ? uint8ArrayFromHex : (value) => Buffer.from(value, "hex");
const bufferFromBytes = (value) => Buffer.from(value.buffer, value.byteOffset, value.byteLength);
const bufferFromBytesIfAvailable = typeof Buffer === "undefined" ? void 0 : bufferFromBytes;
const bufferFromBinary = (value) => Buffer.from(value);
const bufferFromBinaryIfAvailable = typeof Buffer === "undefined" ? (value) => new Uint8Array(value) : bufferFromBinary;
const bytesFromUtf8 = typeof Buffer === "undefined" ? (value) => (0, __utils_ts.encodeUtf8)(value) : (value) => Buffer.from(value);
const dateFromSeconds = (value) => /* @__PURE__ */ new Date(value * 1e3);
const dateFromMilliseconds = (value) => new Date(value);
const integerText = /^-?\d+$/;
const isStoredText = (value) => typeof value === "string" && !integerText.test(value);
const dateFromStoredSeconds = (value) => isStoredText(value) ? new Date(value.replaceAll("\"", "")) : /* @__PURE__ */ new Date(Number(value) * 1e3);
const dateFromStoredMilliseconds = (value) => isStoredText(value) ? new Date(value.replaceAll("\"", "")) : new Date(Number(value));
const booleanFromInteger = (value) => Number(value) === 1;
/**
* Text of a `blob` column value as clients hand it over (`Buffer`, `Uint8Array`, `ArrayBuffer`, an array of bytes),
* or of text stored in it
*/
const textFromBlob = (value) => typeof value === "string" ? value : value instanceof ArrayBuffer ? (0, __utils_ts.decodeUtf8)(new Uint8Array(value)) : ArrayBuffer.isView(value) ? (0, __utils_ts.decodeUtf8)(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)) : (0, __utils_ts.decodeUtf8)(Uint8Array.from(value));
const jsonFromBlob = (value) => JSON.parse(textFromBlob(value));
const bigintFromBlob = (value) => BigInt(textFromBlob(value));
const unsafeNumericReason = "the driver returned an integer outside of the safe integer range as a number, which has already lost precision; configure the client to return integers as bigints (`safeIntegers`, `intMode: 'bigint'`)";
/**
* Text of a `numeric` column value - `number`, `bigint` (safe integers modes) or text, depending on the storage class
* sqlite picked for the row and client options
*/
const numericTextFromValue = (driver) => (value) => {
	if (typeof value === "number" && Number.isInteger(value) && !Number.isSafeInteger(value)) throw (0, __codecs_ts.unsupportedColumnTypeError)("numeric", driver, unsafeNumericReason);
	return String(value);
};
const numericBigintFromValue = (driver) => (0, __codecs_ts.bigintFromIntegerValue)("numeric", driver);
const genericSQLiteCodecs = {
	integer: { normalizeInJson: Number },
	"integer:boolean": { normalizeInJson: booleanFromInteger },
	"integer:timestamp": { normalizeInJson: dateFromStoredSeconds },
	"integer:timestamp_ms": { normalizeInJson: dateFromStoredMilliseconds },
	"text:json": { normalizeInJson: JSON.parse },
	blob: {
		castInJson: castToHex,
		normalizeInJson: bufferFromHex
	},
	"blob:json": {
		castInJson: castToText,
		normalizeInJson: JSON.parse
	},
	"blob:bigint": {
		castInJson: castToText,
		normalizeInJson: BigInt
	},
	numeric: {
		castInJson: castToText,
		normalizeInJson: String
	},
	"numeric:number": {
		castInJson: castToText,
		normalizeInJson: Number
	},
	"numeric:bigint": {
		castInJson: castToText,
		normalizeInJson: BigInt
	}
};
const unionsTypeTable = {
	integer: {
		integer: "integer",
		"integer:boolean": "integer",
		"integer:timestamp": "integer",
		"integer:timestamp_ms": "integer",
		real: "integer",
		text: "integer",
		"text:json": "integer",
		blob: "integer",
		"blob:json": "integer",
		"blob:bigint": "integer",
		numeric: "integer",
		"numeric:number": "integer",
		"numeric:bigint": "integer"
	},
	"integer:boolean": {
		integer: "integer:boolean",
		"integer:boolean": "integer:boolean",
		"integer:timestamp": "integer:boolean",
		"integer:timestamp_ms": "integer:boolean",
		real: "integer:boolean",
		text: "integer:boolean",
		"text:json": "integer:boolean",
		blob: "integer:boolean",
		"blob:json": "integer:boolean",
		"blob:bigint": "integer:boolean",
		numeric: "integer:boolean",
		"numeric:number": "integer:boolean",
		"numeric:bigint": "integer:boolean"
	},
	"integer:timestamp": {
		integer: "integer:timestamp",
		"integer:boolean": "integer:timestamp",
		"integer:timestamp": "integer:timestamp",
		"integer:timestamp_ms": "integer:timestamp",
		real: "integer:timestamp",
		text: "integer:timestamp",
		"text:json": "integer:timestamp",
		blob: "integer:timestamp",
		"blob:json": "integer:timestamp",
		"blob:bigint": "integer:timestamp",
		numeric: "integer:timestamp",
		"numeric:number": "integer:timestamp",
		"numeric:bigint": "integer:timestamp"
	},
	"integer:timestamp_ms": {
		integer: "integer:timestamp_ms",
		"integer:boolean": "integer:timestamp_ms",
		"integer:timestamp": "integer:timestamp_ms",
		"integer:timestamp_ms": "integer:timestamp_ms",
		real: "integer:timestamp_ms",
		text: "integer:timestamp_ms",
		"text:json": "integer:timestamp_ms",
		blob: "integer:timestamp_ms",
		"blob:json": "integer:timestamp_ms",
		"blob:bigint": "integer:timestamp_ms",
		numeric: "integer:timestamp_ms",
		"numeric:number": "integer:timestamp_ms",
		"numeric:bigint": "integer:timestamp_ms"
	},
	real: {
		integer: "real",
		"integer:boolean": "real",
		"integer:timestamp": "real",
		"integer:timestamp_ms": "real",
		real: "real",
		text: "real",
		"text:json": "real",
		blob: "real",
		"blob:json": "real",
		"blob:bigint": "real",
		numeric: "real",
		"numeric:number": "real",
		"numeric:bigint": "real"
	},
	text: {
		integer: "text",
		"integer:boolean": "text",
		"integer:timestamp": "text",
		"integer:timestamp_ms": "text",
		real: "text",
		text: "text",
		"text:json": "text",
		blob: "text",
		"blob:json": "text",
		"blob:bigint": "text",
		numeric: "numeric",
		"numeric:number": "text",
		"numeric:bigint": "text"
	},
	"text:json": {
		integer: "text:json",
		"integer:boolean": "text:json",
		"integer:timestamp": "text:json",
		"integer:timestamp_ms": "text:json",
		real: "text:json",
		text: "text:json",
		"text:json": "text:json",
		blob: "text:json",
		"blob:json": "blob:json",
		"blob:bigint": "text:json",
		numeric: "text:json",
		"numeric:number": "text:json",
		"numeric:bigint": "text:json"
	},
	blob: {
		integer: "blob",
		"integer:boolean": "blob",
		"integer:timestamp": "blob",
		"integer:timestamp_ms": "blob",
		real: "blob",
		text: "blob",
		"text:json": "blob",
		blob: "blob",
		"blob:json": "blob",
		"blob:bigint": "blob",
		numeric: "blob",
		"numeric:number": "blob",
		"numeric:bigint": "blob"
	},
	"blob:json": {
		integer: "blob:json",
		"integer:boolean": "blob:json",
		"integer:timestamp": "blob:json",
		"integer:timestamp_ms": "blob:json",
		real: "blob:json",
		text: "blob:json",
		"text:json": "blob:json",
		blob: "blob:json",
		"blob:json": "blob:json",
		"blob:bigint": "blob:json",
		numeric: "blob:json",
		"numeric:number": "blob:json",
		"numeric:bigint": "blob:json"
	},
	"blob:bigint": {
		integer: "blob:bigint",
		"integer:boolean": "blob:bigint",
		"integer:timestamp": "blob:bigint",
		"integer:timestamp_ms": "blob:bigint",
		real: "blob:bigint",
		text: "blob:bigint",
		"text:json": "blob:bigint",
		blob: "blob:bigint",
		"blob:json": "blob:bigint",
		"blob:bigint": "blob:bigint",
		numeric: "blob:bigint",
		"numeric:number": "blob:bigint",
		"numeric:bigint": "blob:bigint"
	},
	numeric: {
		integer: "numeric",
		"integer:boolean": "numeric",
		"integer:timestamp": "numeric",
		"integer:timestamp_ms": "numeric",
		real: "numeric",
		text: "numeric",
		"text:json": "numeric",
		blob: "numeric",
		"blob:json": "numeric",
		"blob:bigint": "numeric",
		numeric: "numeric",
		"numeric:number": "numeric",
		"numeric:bigint": "numeric"
	},
	"numeric:number": {
		integer: "numeric:number",
		"integer:boolean": "numeric:number",
		"integer:timestamp": "numeric:number",
		"integer:timestamp_ms": "numeric:number",
		real: "numeric:number",
		text: "numeric:number",
		"text:json": "numeric:number",
		blob: "numeric:number",
		"blob:json": "numeric:number",
		"blob:bigint": "numeric:number",
		numeric: "numeric:number",
		"numeric:number": "numeric:number",
		"numeric:bigint": "numeric:number"
	},
	"numeric:bigint": {
		integer: "numeric:bigint",
		"integer:boolean": "numeric:bigint",
		"integer:timestamp": "numeric:bigint",
		"integer:timestamp_ms": "numeric:bigint",
		real: "numeric:bigint",
		text: "numeric:bigint",
		"text:json": "numeric:bigint",
		blob: "numeric:bigint",
		"blob:json": "numeric:bigint",
		"blob:bigint": "numeric:bigint",
		numeric: "numeric:bigint",
		"numeric:number": "numeric:bigint",
		"numeric:bigint": "numeric:bigint"
	}
};
function resolveUnionType(left, right) {
	return unionsTypeTable[left]?.[right];
}
const refineSqliteCodecs = (extension) => (0, __codecs_ts.refineCodecs)(genericSQLiteCodecs, extension);
//#endregion
exports.bigintFromBlob = bigintFromBlob;
exports.booleanFromInteger = booleanFromInteger;
exports.bufferFromBinary = bufferFromBinary;
exports.bufferFromBinaryIfAvailable = bufferFromBinaryIfAvailable;
exports.bufferFromBytes = bufferFromBytes;
exports.bufferFromBytesIfAvailable = bufferFromBytesIfAvailable;
exports.bufferFromHex = bufferFromHex;
exports.bytesFromUtf8 = bytesFromUtf8;
exports.castToHex = castToHex;
exports.castToText = castToText;
exports.dateFromMilliseconds = dateFromMilliseconds;
exports.dateFromSeconds = dateFromSeconds;
exports.dateFromStoredMilliseconds = dateFromStoredMilliseconds;
exports.dateFromStoredSeconds = dateFromStoredSeconds;
exports.genericSQLiteCodecs = genericSQLiteCodecs;
exports.jsonFromBlob = jsonFromBlob;
exports.numericBigintFromValue = numericBigintFromValue;
exports.numericTextFromValue = numericTextFromValue;
exports.refineSqliteCodecs = refineSqliteCodecs;
exports.resolveSQLiteTypeAlias = resolveSQLiteTypeAlias;
exports.resolveUnionType = resolveUnionType;
exports.unionsTypeTable = unionsTypeTable;

//# sourceMappingURL=codecs.cjs.map