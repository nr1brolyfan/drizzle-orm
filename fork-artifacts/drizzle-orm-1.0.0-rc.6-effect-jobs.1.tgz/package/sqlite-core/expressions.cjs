Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __sql_sql_ts = require("../sql/sql.cjs");
//#region src/sqlite-core/expressions.ts
function concat(column, value) {
	return __sql_sql_ts.sql`${column} || ${value}`;
}
function substring(column, start, length) {
	return length === void 0 ? __sql_sql_ts.sql`substr(${column}, ${start})` : __sql_sql_ts.sql`substr(${column}, ${start}, ${length})`;
}
/**
* The `rowid` of a row, as a `number`
*
* A row id above `Number.MAX_SAFE_INTEGER` does not fit a `number`: use `rowId.big()` for tables that have them
*/
function rowId() {
	return __sql_sql_ts.sql`rowid`.mapWith(Number);
}
/**
* The `rowid` of a row, as a `bigint`
*
* Exact for every row id on the drivers that read integers as `bigint` (`better-sqlite3`, `bun:sqlite`, Turso
* Database). The other drivers give the row id as a `number`, so there it is exact only up to
* `Number.MAX_SAFE_INTEGER`
*/
rowId.big = () => __sql_sql_ts.sql`rowid`.mapWith(BigInt);
//#endregion
exports.concat = concat;
exports.rowId = rowId;
exports.substring = substring;
var __sql_expressions_index_ts = require("../sql/expressions/index.cjs");
Object.keys(__sql_expressions_index_ts).forEach(function(k) {
	if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) Object.defineProperty(exports, k, {
		enumerable: true,
		get: function() {
			return __sql_expressions_index_ts[k];
		}
	});
});

//# sourceMappingURL=expressions.cjs.map