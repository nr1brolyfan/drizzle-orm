Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let __entity_ts = require("../../entity.cjs");
let __table_ts = require("../../table.cjs");
let __utils_ts = require("../../utils.cjs");
let __selection_proxy_ts = require("../../selection-proxy.cjs");
let __sqlite_core_table_ts = require("../table.cjs");
//#region src/sqlite-core/query-builders/delete.ts
var SQLiteDeleteBase = class {
	table;
	session;
	dialect;
	static [__entity_ts.entityKind] = "SQLiteDelete";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	/** @internal */
	config;
	constructor(table, session, dialect, withList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			withList
		};
	}
	/**
	* Adds a `where` clause to the query.
	*
	* Calling this method will delete only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param where the `where` clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be deleted.
	*
	* ```ts
	* // Delete all cars with green color
	* db.delete(cars).where(eq(cars.color, 'green'));
	* // or
	* db.delete(cars).where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Delete all BMW cars with a green color
	* db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Delete all cars with the green or blue color
	* db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		this.config.where = where;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.table[__table_ts.Table.Symbol.Columns], new __selection_proxy_ts.SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			this.config.orderBy = orderByArray;
		}
		return this;
	}
	limit(limit) {
		this.config.limit = limit;
		return this;
	}
	returning(fields = this.table[__sqlite_core_table_ts.SQLiteTable.Symbol.Columns]) {
		this.config.returning = (0, __utils_ts.orderSelectedFields)(fields, void 0, this.dialect.codecs);
		return this;
	}
	getSQL() {
		return this.dialect.buildDeleteQuery(this.config);
	}
	toSQL() {
		return this.dialect.sqlToQuery(this.getSQL());
	}
	$dynamic() {
		return this;
	}
	/**
	* Prepares the query on the session, for every runtime. The runtime's builder narrows the return type.
	*
	* @internal
	*/
	_prepare(prepare = false) {
		return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), "arrays", prepare, this.config.returning ? "all" : "run", this.config.returning ? this.dialect.mapperGenerators.rows(this.config.returning, void 0) : void 0);
	}
};
//#endregion
exports.SQLiteDeleteBase = SQLiteDeleteBase;

//# sourceMappingURL=delete.cjs.map