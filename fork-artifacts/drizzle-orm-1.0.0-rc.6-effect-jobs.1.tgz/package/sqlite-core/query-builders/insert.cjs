Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_sqlite_core_query_builders_query_builder = require("./query-builder.cjs");
let __entity_ts = require("../../entity.cjs");
let __table_ts = require("../../table.cjs");
let __utils_ts = require("../../utils.cjs");
let __sql_sql_ts = require("../../sql/sql.cjs");
let __sqlite_core_table_ts = require("../table.cjs");
//#region src/sqlite-core/query-builders/insert.ts
var SQLiteInsertBuilder = class {
	table;
	session;
	dialect;
	withList;
	columnList;
	builder;
	static [__entity_ts.entityKind] = "SQLiteInsertBuilder";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	constructor(table, session, dialect, withList, columnList, builder = SQLiteInsertBase) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
		this.columnList = columnList;
		this.builder = builder;
	}
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		return new this.builder(this.table, values, this.session, this.dialect, this.withList, false, this.columnList);
	}
	select(selectQuery) {
		const select = typeof selectQuery === "function" ? selectQuery(new require_sqlite_core_query_builders_query_builder.QueryBuilder()) : selectQuery;
		if (!(0, __entity_ts.is)(select, __sql_sql_ts.SQL)) {
			const insertCols = Object.keys(this.table[__table_ts.Table.Symbol.Columns]);
			const selected = Object.keys(select._.selectedFields);
			for (const col of selected) if (!insertCols.includes(col)) throw new Error(`Insert select error: column "${col}" does not exist in table "${this.table[__table_ts.Table.Symbol.Name]}"`);
		}
		return new this.builder(this.table, select, this.session, this.dialect, this.withList, true, this.columnList);
	}
};
var SQLiteInsertBase = class {
	session;
	dialect;
	static [__entity_ts.entityKind] = "SQLiteInsert";
	static [Symbol.hasInstance](value) {
		return (0, __entity_ts.is)(value, this);
	}
	/** @internal */
	config;
	constructor(table, values, session, dialect, withList, select, columnList) {
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			withList,
			select,
			columnList
		};
	}
	returning(fields = this.config.table[__sqlite_core_table_ts.SQLiteTable.Symbol.Columns]) {
		this.config.returning = (0, __utils_ts.orderSelectedFields)(fields, void 0, this.dialect.codecs);
		return this;
	}
	/**
	* Adds an `on conflict do nothing` clause to the query.
	*
	* Calling this method simply avoids inserting a row as it's alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
	*
	* @param config The `target` and `where` clauses.
	*
	* @example
	* ```ts
	* // Insert one row and cancel the insert if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing();
	*
	* // Explicitly specify conflict target
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing({ target: cars.id });
	* ```
	*/
	onConflictDoNothing(config = {}) {
		if (!this.config.onConflict) this.config.onConflict = [];
		if (config.target === void 0) this.config.onConflict.push(__sql_sql_ts.sql` on conflict do nothing`);
		else {
			const targetSql = Array.isArray(config.target) ? __sql_sql_ts.sql`${config.target}` : __sql_sql_ts.sql`${[config.target]}`;
			const whereSql = config.where ? __sql_sql_ts.sql` where ${config.where}` : __sql_sql_ts.sql``;
			this.config.onConflict.push(__sql_sql_ts.sql` on conflict ${targetSql}${whereSql} do nothing`);
		}
		return this;
	}
	onConflictDoUpdate(config) {
		if (config.where && (config.targetWhere || config.setWhere)) throw new Error("You cannot use both \"where\" and \"targetWhere\"/\"setWhere\" at the same time - \"where\" is deprecated, use \"targetWhere\" or \"setWhere\" instead.");
		if (!this.config.onConflict) this.config.onConflict = [];
		const whereSql = config.where ? __sql_sql_ts.sql` where ${config.where}` : void 0;
		const targetWhereSql = config.targetWhere ? __sql_sql_ts.sql` where ${config.targetWhere}` : void 0;
		const setWhereSql = config.setWhere ? __sql_sql_ts.sql` where ${config.setWhere}` : void 0;
		const targetSql = Array.isArray(config.target) ? __sql_sql_ts.sql`${config.target}` : __sql_sql_ts.sql`${[config.target]}`;
		const setSql = this.dialect.buildUpdateSet(this.config.table, (0, __utils_ts.mapUpdateSet)(this.config.table, config.set));
		this.config.onConflict.push(__sql_sql_ts.sql` on conflict ${targetSql}${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`);
		return this;
	}
	getSQL() {
		return this.dialect.buildInsertQuery(this.config);
	}
	toSQL() {
		return this.dialect.sqlToQuery(this.getSQL());
	}
	$dynamic() {
		return this;
	}
	/**
	* Prepares the query on the session, for every runtime. The runtime's builder narrows the return type.
	*
	* @internal
	*/
	_prepare(prepare = false) {
		return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), "arrays", prepare, this.config.returning ? "all" : "run", this.config.returning ? this.dialect.mapperGenerators.rows(this.config.returning, void 0) : void 0);
	}
};
//#endregion
exports.SQLiteInsertBase = SQLiteInsertBase;
exports.SQLiteInsertBuilder = SQLiteInsertBuilder;

//# sourceMappingURL=insert.cjs.map